/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Durée : 4 heures
 * 
 * CONSIGNE : Ce programme contient de NOMBREUSES vulnérabilités.
 * Vous devez les identifier, les corriger et documenter chaque correction.
 * 
 * Système de gestion de comptes utilisateurs avec authentification
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

typedef struct {
    char username[16];
    char password[16];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

void remove_newline(char *s) {
    s[strcspn(s, "\n")] = '\0';
}

void clear_input_line() {
    int c;
    while((c = getchar()) != '\n' && c != EOF) {
    }
}

int read_line(char *buffer, size_t size) {
    if(fgets(buffer, size, stdin) == NULL) {
        return 0;
    }
    if(strchr(buffer, '\n') == NULL) {
        clear_input_line();
    }
    remove_newline(buffer);
    return buffer[0] != '\0';
}

void safe_copy(char *dst, const char *src, size_t size) {
    if(size == 0) {
        return;
    }
    strncpy(dst, src, size - 1);
    dst[size - 1] = '\0';
}

int is_valid_user_id(int user_id) {
    return user_id >= 0 && user_id < user_count && user_id < MAX_USERS;
}

int is_valid_identifier(const char *value) {
    size_t len = strlen(value);
    if(len == 0 || len >= sizeof(users[0].username)) {
        return 0;
    }
    for(size_t i = 0; i < len; i++) {
        if(!isalnum((unsigned char)value[i]) && value[i] != '_') {
            return 0;
        }
    }
    return 1;
}

int is_valid_password(const char *value) {
    size_t len = strlen(value);
    return len > 0 && len < sizeof(users[0].password);
}

int username_exists(const char *username) {
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, username) == 0) {
            return 1;
        }
    }
    return 0;
}

void free_users() {
    for(int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

int is_valid_filename(const char *filename) {
    size_t len = strlen(filename);
    if(len == 0 || len >= 100 || strstr(filename, "..") != NULL) {
        return 0;
    }
    for(size_t i = 0; i < len; i++) {
        char c = filename[i];
        if(c == '/' || c == '\\' || c == ':' || c == '*' ||
           c == '?' || c == '"' || c == '<' || c == '>' || c == '|') {
            return 0;
        }
    }
    return 1;
}

// Fonction de hashage personnalisée
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;
    while ((c = *pass++))
        h = h * 33 + c;
    return h;
}

// Enregistrement d'un nouvel utilisateur
void register_user(int creator_id) {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    
    char username[16];
    char password[16];
    char confirm[16];
    int admin = 0;
    int creator_is_admin = is_valid_user_id(creator_id) && users[creator_id].admin_flag;
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    if(!read_line(username, sizeof(username)) || !is_valid_identifier(username)) {
        printf("Username invalide\n");
        return;
    }
    if(username_exists(username)) {
        printf("Username deja utilise\n");
        return;
    }
    
    printf("Password: ");
    if(!read_line(password, sizeof(password)) || !is_valid_password(password)) {
        printf("Password invalide\n");
        return;
    }
    
    printf("Confirmer password: ");
    if(!read_line(confirm, sizeof(confirm)) || strcmp(password, confirm) != 0) {
        printf("Confirmation invalide\n");
        return;
    }

    if(creator_is_admin) {
        printf("Droits admin (1=oui, 0=non): ");
        if(scanf("%d", &admin) != 1) {
            printf("Valeur admin invalide\n");
            clear_input_line();
            return;
        }
        clear_input_line();
        if(admin != 0 && admin != 1) {
            printf("Valeur admin invalide\n");
            return;
        }
    }
    
    safe_copy(users[user_count].username, username, sizeof(users[user_count].username));
    safe_copy(users[user_count].password, password, sizeof(users[user_count].password));
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;
    
    users[user_count].token = malloc(32);
    if(users[user_count].token == NULL) {
        printf("Erreur allocation token\n");
        return;
    }
    snprintf(users[user_count].token, 32, "TOK_%d_%s", user_count, username);
    
    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, username) == 0 && 
           strcmp(users[i].password, password) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];
    if(!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    
    printf("Format d'affichage personnalisé: ");
    if(!read_line(format, sizeof(format))) {
        return;
    }
    printf("%s", format);
    printf("\n");
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;
    if(!is_valid_user_id(from_user)) {
        printf("Utilisateur invalide\n");
        return;
    }
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    if(!read_line(to_username, sizeof(to_username)) || !is_valid_identifier(to_username)) {
        printf("Utilisateur destinataire invalide\n");
        return;
    }
    
    printf("Montant: ");
    if(scanf("%d", &amount) != 1) {
        printf("Montant invalide\n");
        clear_input_line();
        return;
    }
    clear_input_line();
    if(amount <= 0 || amount > users[from_user].balance) {
        printf("Montant invalide\n");
        return;
    }
    
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;
    if(!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }
    
    printf("Nom du fichier de backup: ");
    if(!read_line(filename, sizeof(filename)) || !is_valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }
    
    fp = fopen(filename, "w");
    if(fp) {
        fprintf(fp, "%s:%s:%d:%d\n", 
                users[user_id].username,
                users[user_id].password,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    if(!read_line(filename, sizeof(filename)) || !is_valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }
    
    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    char full_cmd[200];
    
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    if(!read_line(cmd, sizeof(cmd))) {
        return;
    }
    
    snprintf(full_cmd, sizeof(full_cmd), "Commande refusee: %s", cmd);
    printf("%s\n", full_cmd);
}

// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[16];
    if(!is_valid_user_id(source_id)) {
        printf("Utilisateur invalide\n");
        return;
    }
    
    printf("Nom du clone: ");
    if(!read_line(target_username, sizeof(target_username)) || !is_valid_identifier(target_username)) {
        printf("Nom du clone invalide\n");
        return;
    }
    if(username_exists(target_username)) {
        printf("Nom du clone deja utilise\n");
        return;
    }
    
    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    
    safe_copy(users[user_count].username, target_username, sizeof(users[user_count].username));
    safe_copy(users[user_count].password, users[source_id].password, sizeof(users[user_count].password));
    users[user_count].admin_flag = 0;
    users[user_count].balance = users[source_id].balance;
    users[user_count].token = malloc(32);
    if(users[user_count].token == NULL) {
        printf("Erreur allocation token\n");
        return;
    }
    snprintf(users[user_count].token, 32, "TOK_%d_%s", user_count, target_username);
    
    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[80];
    char new_pass[80];
    if(!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }
    
    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    if(!read_line(old_pass, sizeof(old_pass))) {
        return;
    }
    
    if(strcmp(users[user_id].password, old_pass) == 0) {
        printf("Nouveau mot de passe: ");
        if(!read_line(new_pass, sizeof(new_pass))) {
            return;
        }
        if(!is_valid_password(new_pass)) {
            printf("Nouveau mot de passe invalide\n");
            return;
        }
        safe_copy(users[user_id].password, new_pass, sizeof(users[user_id].password));
        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];
    if(user_count <= 0) {
        printf("Aucun utilisateur\n");
        return;
    }
    
    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];
    
    printf("Rechercher: ");
    if(!read_line(query, sizeof(query)) || !is_valid_identifier(query)) {
        printf("Recherche invalide\n");
        return;
    }
    
    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    int count = session_count;
    if(count < 0) {
        count = 0;
    }
    if(count > MAX_SESSIONS) {
        count = MAX_SESSIONS;
    }
    for(int i = 0; i < count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE     ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                   ║\n");
    printf("║ 2. Se connecter                   ║\n");
    printf("║ 3. Voir profil                    ║\n");
    printf("║ 4. Transférer argent              ║\n");
    printf("║ 5. Backup données                 ║\n");
    printf("║ 6. Restaurer données              ║\n");
    printf("║ 7. Commande système               ║\n");
    printf("║ 8. Cloner utilisateur             ║\n");
    printf("║ 9. Liste utilisateurs             ║\n");
    printf("║ 10. Changer mot de passe          ║\n");
    printf("║ 11. Statistiques                  ║\n");
    printf("║ 12. Rechercher utilisateur        ║\n");
    printf("║ 0. Quitter                        ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE SÉCURISÉ            ║\n");
    printf("║  Durée: 4 heures                          ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    // Compte admin par défaut
    safe_copy(users[0].username, "admin", sizeof(users[0].username));
    safe_copy(users[0].password, "admin123", sizeof(users[0].password));
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(32);
    if(users[0].token == NULL) {
        printf("Erreur allocation token admin\n");
        return 1;
    }
    safe_copy(users[0].token, "ADMIN_TOKEN", 32);
    user_count = 1;
    
    while(1) {
        display_menu();
        if(scanf("%d", &choice) != 1) {
            printf("Choix invalide\n");
            clear_input_line();
            continue;
        }
        clear_input_line();
        
        switch(choice) {
            case 1:
                register_user(logged_user);
                break;
            case 2:
                printf("Username: ");
                if(!read_line(username, sizeof(username)) || !is_valid_identifier(username)) {
                    printf("Username invalide\n");
                    break;
                }
                printf("Password: ");
                if(!read_line(password, sizeof(password)) || !is_valid_password(password)) {
                    printf("Password invalide\n");
                    break;
                }
                logged_user = login_user(username, password);
                if(is_valid_user_id(logged_user)) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(is_valid_user_id(logged_user)) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(is_valid_user_id(logged_user)) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(is_valid_user_id(logged_user)) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(is_valid_user_id(logged_user) && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(is_valid_user_id(logged_user)) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(is_valid_user_id(logged_user)) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                free_users();
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }
    
    free_users();
    return 0;
}
