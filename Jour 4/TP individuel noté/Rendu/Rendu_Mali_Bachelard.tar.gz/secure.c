/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Version sécurisée : secure.c
 *
 * Compilation : gcc -o secure secure.c -lcrypto -Wall -Wextra -O2 -fstack-protector-all -D_FORTIFY_SOURCE=2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>
#include <openssl/rand.h>

#define MAX_USERS        20
#define MAX_SESSIONS     10
#define MAX_LOGIN_ATTEMPTS 5
#define SALT_LEN         8
#define SALT_HEX_LEN     (SALT_LEN * 2 + 1)              /* 17  */
#define HASH_HEX_LEN     (SHA256_DIGEST_LENGTH * 2 + 1)  /* 65  */

typedef struct {
    char username[16];
    char password_hash[HASH_HEX_LEN];  /* SHA-256 salé en hex, jamais en clair */
    char salt[SALT_HEX_LEN];
    int  admin_flag;
    int  balance;
    char *token;
    int  login_attempts;
} User;

typedef struct {
    int    user_id;
    char   session_data[64];
    time_t created;
} Session;

User    users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int     user_count   = 0;
int     session_count = 0;

/* ── Utilitaires ──────────────────────────────────────────────────────────── */

static void bytes_to_hex(const unsigned char *b, size_t len, char *out) {
    for (size_t i = 0; i < len; i++)
        snprintf(out + i * 2, 3, "%02x", b[i]);
    out[len * 2] = '\0';
}

static void generate_salt(char *salt_hex) {
    unsigned char buf[SALT_LEN];
    RAND_bytes(buf, SALT_LEN);
    bytes_to_hex(buf, SALT_LEN, salt_hex);
}

/* FIX #9 : remplace DJB2 → SHA-256 salé via OpenSSL */
static void hash_password(const char *password, const char *salt, char *hash_hex) {
    char input[SALT_HEX_LEN + 16];
    snprintf(input, sizeof(input), "%s%s", salt, password);
    unsigned char digest[SHA256_DIGEST_LENGTH];
    SHA256((unsigned char *)input, strlen(input), digest);
    bytes_to_hex(digest, SHA256_DIGEST_LENGTH, hash_hex);
    memset(input, 0, sizeof(input));
}

/* FIX #1 : remplace gets() et scanf("%s") */
static void read_line(char *buf, size_t size) {
    if (!fgets(buf, (int)size, stdin)) { buf[0] = '\0'; return; }
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
    }
}

static int validate_username(const char *u) {
    size_t len = strlen(u);
    if (len < 1 || len > 15) return 0;
    for (size_t i = 0; i < len; i++)
        if (!isalnum((unsigned char)u[i]) && u[i] != '_') return 0;
    return 1;
}

/* FIX #7/#8 : bloque path traversal */
static int validate_filename(const char *f) {
    if (!f || f[0] == '\0' || f[0] == '/') return 0;
    if (strstr(f, "..") != NULL || strchr(f, '/') != NULL) return 0;
    for (size_t i = 0; f[i]; i++) {
        char c = f[i];
        if (!isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.') return 0;
    }
    return 1;
}

/* FIX #13 : libération des tokens à la sortie */
static void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

/* ── Enregistrement ───────────────────────────────────────────────────────── */

void register_user(void) {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[16], password[16], confirm[16];

    printf("=== ENREGISTREMENT ===\n");
    printf("Username (max 15 chars, [a-zA-Z0-9_]) : ");
    read_line(username, sizeof(username));

    if (!validate_username(username)) {
        printf("Nom d'utilisateur invalide (alphanumérique, 1-15 chars)\n");
        return;
    }

    printf("Password (max 15 chars) : ");
    read_line(password, sizeof(password));
    if (strlen(password) < 1) {
        printf("Mot de passe vide non autorisé\n");
        return;
    }

    printf("Confirmer password : ");
    read_line(confirm, sizeof(confirm));

    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        memset(password, 0, sizeof(password));
        memset(confirm,  0, sizeof(confirm));
        return;
    }

    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", username);

    /* FIX #9 : sel aléatoire + SHA-256, jamais le mot de passe en clair */
    generate_salt(users[user_count].salt);
    hash_password(password, users[user_count].salt, users[user_count].password_hash);

    /* FIX #6 : admin_flag toujours 0, pas demandé à l'utilisateur */
    users[user_count].admin_flag     = 0;
    users[user_count].balance        = 100;
    users[user_count].login_attempts = 0;

    /* FIX #12 : NULL check sur malloc */
    users[user_count].token = malloc(64);
    if (!users[user_count].token) {
        printf("Erreur d'allocation mémoire\n");
        memset(password, 0, sizeof(password));
        return;
    }
    snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, username);

    memset(password, 0, sizeof(password));
    memset(confirm,  0, sizeof(confirm));

    user_count++;
    printf("Utilisateur enregistré!\n");
}

/* ── Connexion ────────────────────────────────────────────────────────────── */

int login_user(char *username, char *password) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {

            /* BONUS : verrouillage après trop d'échecs */
            if (users[i].login_attempts >= MAX_LOGIN_ATTEMPTS) {
                printf("Compte verrouillé (trop de tentatives échouées)\n");
                return -1;
            }

            char computed[HASH_HEX_LEN];
            hash_password(password, users[i].salt, computed);

            if (strcmp(computed, users[i].password_hash) == 0) {
                users[i].login_attempts = 0;
                return i;
            }

            users[i].login_attempts++;
            return -1;
        }
    }
    return -1;
}

/* ── Profil ───────────────────────────────────────────────────────────────── */

void show_profile(int user_id) {
    char custom[80];

    printf("\n=== PROFIL ===\n");
    printf("User    : %s\n", users[user_id].username);
    printf("Balance : %d€\n", users[user_id].balance);
    printf("Admin   : %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Texte personnalisé : ");
    read_line(custom, sizeof(custom));      /* FIX #1 : gets() → read_line */
    printf("%s\n", custom);                 /* FIX #3 : printf(format) → printf("%s", ...) */
}

/* ── Transfert ────────────────────────────────────────────────────────────── */

void transfer_money(int from_user) {
    char to_username[16];
    int  amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur : ");
    read_line(to_username, sizeof(to_username));

    printf("Montant : ");
    if (scanf("%d", &amount) != 1) {
        printf("Montant invalide\n");
        while (getchar() != '\n');
        return;
    }
    getchar();

    /* FIX #4 : montant positif + solde suffisant */
    if (amount <= 0) {
        printf("Le montant doit être positif\n");
        return;
    }
    if (users[from_user].balance < amount) {
        printf("Solde insuffisant (%d€ disponibles)\n", users[from_user].balance);
        return;
    }
    if (strcmp(to_username, users[from_user].username) == 0) {
        printf("Impossible de se transférer à soi-même\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance         += amount;
            printf("Transfert de %d€ effectué vers %s\n", amount, to_username);
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

/* ── Backup ───────────────────────────────────────────────────────────────── */

void backup_user_data(int user_id) {
    char filename[64];
    FILE *fp;

    printf("Nom du fichier de backup : ");
    read_line(filename, sizeof(filename));

    /* FIX #7 : validation → bloque path traversal */
    if (!validate_filename(filename)) {
        printf("Nom de fichier invalide (pas de '..', '/', ni caractères spéciaux)\n");
        return;
    }

    fp = fopen(filename, "w");
    if (fp) {
        /* FIX #10 : hash au lieu du mot de passe en clair */
        fprintf(fp, "%s:%s:%d:%d\n",
                users[user_id].username,
                users[user_id].password_hash,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    } else {
        printf("Impossible de créer le fichier\n");
    }
}

/* ── Restauration ─────────────────────────────────────────────────────────── */

void restore_user_data(void) {
    char filename[64];
    char buffer[256];
    FILE *fp;

    printf("Fichier à restaurer : ");
    read_line(filename, sizeof(filename));

    /* FIX #8 : validation → bloque LFI */
    if (!validate_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    fp = fopen(filename, "r");
    if (!fp) { printf("Fichier introuvable\n"); return; }
    while (fgets(buffer, sizeof(buffer), fp))
        printf("%s", buffer);
    fclose(fp);
}

/* ── Commande système (whitelist stricte) ─────────────────────────────────── */

static const char *ALLOWED_CMDS[] = { "date", "uptime", "whoami", NULL };

void system_command(void) {
    char cmd[32];

    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commandes autorisées : date, uptime, whoami\n");
    printf("Commande : ");
    read_line(cmd, sizeof(cmd));

    /* FIX #5 : whitelist stricte, aucune interpolation shell */
    for (int i = 0; ALLOWED_CMDS[i] != NULL; i++) {
        if (strcmp(cmd, ALLOWED_CMDS[i]) == 0) {
            if (system(cmd) < 0)
                printf("Erreur d'exécution\n");
            return;
        }
    }

    printf("Commande non autorisée\n");
}

/* ── Clone utilisateur ────────────────────────────────────────────────────── */

void clone_user(int source_id) {
    char target_username[16];

    printf("Nom du clone : ");
    read_line(target_username, sizeof(target_username));

    if (!validate_username(target_username)) {
        printf("Nom d'utilisateur invalide\n");
        return;
    }

    if (user_count >= MAX_USERS) { printf("Limite atteinte\n"); return; }

    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", target_username);

    /* buffers temporaires pour éviter les alias sur users[] */
    char tmp_hash[HASH_HEX_LEN];
    char tmp_salt[SALT_HEX_LEN];
    memcpy(tmp_hash, users[source_id].password_hash, HASH_HEX_LEN);
    memcpy(tmp_salt, users[source_id].salt, SALT_HEX_LEN);
    memcpy(users[user_count].password_hash, tmp_hash, HASH_HEX_LEN);
    memcpy(users[user_count].salt, tmp_salt, SALT_HEX_LEN);

    users[user_count].admin_flag     = 0;
    users[user_count].balance        = users[source_id].balance;
    users[user_count].login_attempts = 0;

    /* FIX #11/#12 : token alloué et initialisé (pointeur non initialisé dans l'original) */
    users[user_count].token = malloc(64);
    if (!users[user_count].token) { printf("Erreur d'allocation mémoire\n"); return; }
    snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, target_username);

    user_count++;
    printf("Clone créé\n");
}

/* ── Liste utilisateurs ───────────────────────────────────────────────────── */

void list_users(void) {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

/* ── Changement de mot de passe ───────────────────────────────────────────── */

void change_password(int user_id) {
    char old_pass[16], new_pass[16], confirm[16];
    char old_hash[HASH_HEX_LEN];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe : ");
    read_line(old_pass, sizeof(old_pass));

    hash_password(old_pass, users[user_id].salt, old_hash);

    /* FIX #15 : comparaison sur le hash, backdoor supprimée */
    if (strcmp(old_hash, users[user_id].password_hash) != 0) {
        printf("Ancien mot de passe incorrect\n");
        memset(old_pass, 0, sizeof(old_pass));
        memset(old_hash, 0, sizeof(old_hash));
        return;
    }

    printf("Nouveau mot de passe : ");
    read_line(new_pass, sizeof(new_pass));
    if (strlen(new_pass) < 1) {
        printf("Mot de passe vide non autorisé\n");
        memset(old_pass, 0, sizeof(old_pass));
        return;
    }

    printf("Confirmer nouveau mot de passe : ");
    read_line(confirm, sizeof(confirm));

    if (strcmp(new_pass, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        memset(old_pass, 0, sizeof(old_pass));
        memset(new_pass, 0, sizeof(new_pass));
        return;
    }

    generate_salt(users[user_id].salt);
    hash_password(new_pass, users[user_id].salt, users[user_id].password_hash);

    memset(old_pass, 0, sizeof(old_pass));
    memset(new_pass, 0, sizeof(new_pass));
    memset(confirm,  0, sizeof(confirm));
    memset(old_hash, 0, sizeof(old_hash));

    printf("Mot de passe changé\n");
}

/* ── Statistiques ─────────────────────────────────────────────────────────── */

void compute_stats(void) {
    if (user_count == 0) { printf("Aucun utilisateur\n"); return; }

    int  total = 0;
    char buffer[128];

    for (int i = 0; i < user_count; i++)
        total += users[i].balance;

    double avg = (double)total / user_count;
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

/* ── Recherche utilisateur ────────────────────────────────────────────────── */

void search_user(void) {
    char query[16];

    printf("Rechercher : ");
    read_line(query, sizeof(query));

    for (int i = 0; i < user_count; i++)
        if (strstr(users[i].username, query))
            printf("Trouvé : %s\n", users[i].username);
}

/* ── Menu ─────────────────────────────────────────────────────────────────── */

void display_menu(void) {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système (admin)      ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe        ║\n");
    printf("║ 11. Statistiques                ║\n");
    printf("║ 12. Rechercher utilisateur      ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix : ");
}

/* ── Main ─────────────────────────────────────────────────────────────────── */

int main(void) {
    int  choice;
    int  logged_user = -1;
    char username[16], password[16];

    /* FIX #13 : cleanup enregistré → tokens libérés à la sortie */
    atexit(cleanup);

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE SÉCURISÉ           ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    /* compte admin par défaut — MDP hashé */
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    users[0].username[sizeof(users[0].username) - 1] = '\0';
    generate_salt(users[0].salt);
    hash_password("admin123", users[0].salt, users[0].password_hash);
    users[0].admin_flag     = 1;
    users[0].balance        = 10000;
    users[0].login_attempts = 0;
    users[0].token = malloc(64);
    if (!users[0].token) {
        fprintf(stderr, "Erreur fatale: malloc\n");
        return 1;
    }
    snprintf(users[0].token, 64, "TOK_0_admin");
    user_count = 1;

    while (1) {
        display_menu();
        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n');
            printf("Choix invalide\n");
            continue;
        }
        getchar();

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username : ");
                read_line(username, sizeof(username));
                printf("Password : ");
                read_line(password, sizeof(password));
                logged_user = login_user(username, password);
                if (logged_user >= 0)
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                else
                    printf("✗ Échec de connexion\n");
                memset(password, 0, sizeof(password));
                break;
            case 3:
                if (logged_user >= 0) show_profile(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 4:
                if (logged_user >= 0) transfer_money(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 5:
                if (logged_user >= 0) backup_user_data(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 6:
                /* FIX #20 : restore nécessite une auth */
                if (logged_user >= 0) restore_user_data();
                else printf("Veuillez vous connecter\n");
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag)
                    system_command();
                else printf("Accès refusé\n");
                break;
            case 8:
                if (logged_user >= 0) clone_user(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 9:
                if (logged_user >= 0) list_users();
                else printf("Veuillez vous connecter\n");
                break;
            case 10:
                if (logged_user >= 0) change_password(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 11:
                if (logged_user >= 0) compute_stats();
                else printf("Veuillez vous connecter\n");
                break;
            case 12:
                if (logged_user >= 0) search_user();
                else printf("Veuillez vous connecter\n");
                break;
            case 0:
                printf("Au revoir!\n");
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    return 0;
}
