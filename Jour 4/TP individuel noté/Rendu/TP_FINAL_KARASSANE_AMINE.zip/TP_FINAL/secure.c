#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10
#define USERNAME_LEN 16
#define SHA256_HEX_LEN 65

typedef struct {
    char username[USERNAME_LEN];
    char password_hash[SHA256_HEX_LEN];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// Purge sécurisée du flux d'entrée standard (stdin)
static void clear_stdin(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Fonction utilitaire : Calcul de l'empreinte SHA-256
static void hash_password_sha256(const char *pass, char output_hex[SHA256_HEX_LEN]) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char *)pass, strlen(pass), hash);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(output_hex + (i * 2), "%02x", hash[i]);
    }
    output_hex[SHA256_HEX_LEN - 1] = '\0';
}

// Validation des noms d'utilisateurs (caractères alphanumériques et '_' uniquement)
static int is_valid_username(const char *name) {
    size_t len = strlen(name);
    if (len == 0 || len >= USERNAME_LEN) return 0;
    for (size_t i = 0; i < len; i++) {
        if (!isalnum((unsigned char)name[i]) && name[i] != '_') return 0;
    }
    return 1;
}

// Protection contre le Path Traversal (interdit '..', '/', et '\')
static int is_safe_filename(const char *filename) {
    if (strlen(filename) == 0 || strstr(filename, "..") || strchr(filename, '/') || strchr(filename, '\\')) {
        return 0;
    }
    return 1;
}

// Nettoyage global de la mémoire allouée sur le Tas (0 fuite mémoire)
void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        if (users[i].token) {
            free(users[i].token);
            users[i].token = NULL;
        }
    }
}

// Enregistrement sécurisé d'un nouvel utilisateur
void register_user(void) {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[USERNAME_LEN];
    char password[128];
    char confirm[128];
    int admin;

    printf("=== ENREGISTREMENT ===\n");
    printf("Username (alphanumerique, max 15 car.): ");
    if (scanf("%15s", username) != 1 || !is_valid_username(username)) {
        printf("Nom d'utilisateur invalide.\n");
        clear_stdin();
        return;
    }

    // Vérification des doublons
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            printf("Nom d'utilisateur déjà pris.\n");
            clear_stdin();
            return;
        }
    }

    printf("Password: ");
    if (scanf("%127s", password) != 1) {
        clear_stdin();
        return;
    }

    printf("Confirmer password: ");
    if (scanf("%127s", confirm) != 1) {
        clear_stdin();
        return;
    }

    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas.\n");
        clear_stdin();
        return;
    }

    printf("Droits admin (1=oui, 0=non): ");
    if (scanf("%d", &admin) != 1 || (admin != 0 && admin != 1)) {
        printf("Saisie invalide.\n");
        clear_stdin();
        return;
    }

    strncpy(users[user_count].username, username, USERNAME_LEN - 1);
    users[user_count].username[USERNAME_LEN - 1] = '\0';

    hash_password_sha256(password, users[user_count].password_hash);
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;

    users[user_count].token = malloc(64);
    if (!users[user_count].token) {
        printf("Erreur d'allocation mémoire.\n");
        exit(EXIT_FAILURE);
    }
    snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, users[user_count].username);

    user_count++;
    printf("Utilisateur enregistré!\n");
    clear_stdin();
}

// Connexion d'un utilisateur
int login_user(const char *username, const char *password) {
    char hash[SHA256_HEX_LEN];
    hash_password_sha256(password, hash);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 &&
            strcmp(users[i].password_hash, hash) == 0) {
            return i;
        }
    }
    return -1;
}

// Affichage du profil utilisateur
void show_profile(int user_id) {
    if (user_id < 0 || user_id >= user_count) {
        printf("ID utilisateur invalide.\n");
        return;
    }

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
}

// Transfert d'argent sécurisé
void transfer_money(int from_user) {
    if (from_user < 0 || from_user >= user_count) {
        printf("Session invalide.\n");
        return;
    }

    char to_username[USERNAME_LEN];
    int amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    if (scanf("%15s", to_username) != 1) {
        clear_stdin();
        return;
    }

    printf("Montant: ");
    if (scanf("%d", &amount) != 1 || amount <= 0) {
        printf("Montant invalide.\n");
        clear_stdin();
        return;
    }

    if (users[from_user].balance < amount) {
        printf("Solde insuffisant.\n");
        clear_stdin();
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            if (i == from_user) {
                printf("Impossible de transférer vers votre propre compte.\n");
                clear_stdin();
                return;
            }
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            clear_stdin();
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
    clear_stdin();
}

// Sauvegarde des données utilisateur
void backup_user_data(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;

    char filename[100];
    FILE *fp;

    printf("Nom du fichier de backup: ");
    if (scanf("%99s", filename) != 1 || !is_safe_filename(filename)) {
        printf("Nom de fichier non autorisé.\n");
        clear_stdin();
        return;
    }

    fp = fopen(filename, "w");
    if (fp) {
        // Exclusion explicite des secrets / mots de passe du backup
        fprintf(fp, "%s:%d:%d\n",
                users[user_id].username,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    } else {
        printf("Erreur lors de la création du fichier.\n");
    }
    clear_stdin();
}

// Restauration des données
void restore_user_data(void) {
    char filename[100];
    char buffer[256];
    FILE *fp;

    printf("Fichier à restaurer: ");
    if (scanf("%99s", filename) != 1 || !is_safe_filename(filename)) {
        printf("Nom de fichier non autorisé.\n");
        clear_stdin();
        return;
    }

    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        clear_stdin();
        return;
    }

    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
    clear_stdin();
}

// Commande système sécurisée (neutralisée pour éviter toute injection shell)
void system_command(void) {
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Option désactivée par mesure de sécurité.\n");
}

// Clonage d'un profil utilisateur
void clone_user(int source_id) {
    if (source_id < 0 || source_id >= user_count) return;

    char target_username[USERNAME_LEN];

    printf("Nom du clone: ");
    if (scanf("%15s", target_username) != 1 || !is_valid_username(target_username)) {
        printf("Nom invalide.\n");
        clear_stdin();
        return;
    }

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        clear_stdin();
        return;
    }

    strncpy(users[user_count].username, target_username, USERNAME_LEN - 1);
    users[user_count].username[USERNAME_LEN - 1] = '\0';

    strncpy(users[user_count].password_hash, users[source_id].password_hash, SHA256_HEX_LEN);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;

    users[user_count].token = malloc(64);
    if (!users[user_count].token) {
        printf("Erreur mémoire.\n");
        exit(EXIT_FAILURE);
    }
    snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, users[user_count].username);

    user_count++;
    printf("Clone créé\n");
    clear_stdin();
}

// Affichage de la liste des utilisateurs
void list_users(void) {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modification sécurisée du mot de passe (suppression de la backdoor master reset)
void change_password(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;

    char old_pass[128];
    char new_pass[128];
    char old_hash[SHA256_HEX_LEN];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    if (scanf("%127s", old_pass) != 1) {
        clear_stdin();
        return;
    }

    hash_password_sha256(old_pass, old_hash);

    if (strcmp(users[user_id].password_hash, old_hash) == 0) {
        printf("Nouveau mot de passe: ");
        if (scanf("%127s", new_pass) != 1) {
            clear_stdin();
            return;
        }
        hash_password_sha256(new_pass, users[user_id].password_hash);
        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
    clear_stdin();
}

// Calcul des statistiques sécurisé contre la division par zéro
void compute_stats(void) {
    if (user_count == 0) {
        printf("Aucun utilisateur dans la base.\n");
        return;
    }

    int total = 0;
    double avg;
    char buffer[120];

    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }

    avg = (double)total / user_count;

    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Recherche d'un utilisateur
void search_user(void) {
    char query[USERNAME_LEN];

    printf("Rechercher: ");
    if (scanf("%15s", query) != 1) {
        clear_stdin();
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
    clear_stdin();
}

// Menu principal
void display_menu(void) {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main(void) {
    int choice;
    int logged_user = -1;
    char username[USERNAME_LEN], password[128];

    // Initialisation sécurisée du compte administrateur
    strncpy(users[0].username, "admin", USERNAME_LEN - 1);
    users[0].username[USERNAME_LEN - 1] = '\0';

    hash_password_sha256("admin123", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;

    users[0].token = malloc(64);
    if (!users[0].token) {
        fprintf(stderr, "Échec d'allocation mémoire.\n");
        return EXIT_FAILURE;
    }
    strncpy(users[0].token, "ADMIN_TOKEN", 63);
    users[0].token[63] = '\0';
    user_count = 1;

    while (1) {
        display_menu();
        if (scanf("%d", &choice) != 1) {
            clear_stdin();
            continue;
        }
        clear_stdin();

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                if (scanf("%15s", username) != 1) { clear_stdin(); break; }
                printf("Password: ");
                if (scanf("%127s", password) != 1) { clear_stdin(); break; }
                clear_stdin();
                logged_user = login_user(username, password);
                if (logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) show_profile(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 4:
                if (logged_user >= 0) transfer_money(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 5:
                if (logged_user >= 0) backup_user_data(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) system_command();
                else printf("Accès refusé\n");
                break;
            case 8:
                if (logged_user >= 0) clone_user(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) change_password(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                cleanup();
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    cleanup();
    return 0;
}