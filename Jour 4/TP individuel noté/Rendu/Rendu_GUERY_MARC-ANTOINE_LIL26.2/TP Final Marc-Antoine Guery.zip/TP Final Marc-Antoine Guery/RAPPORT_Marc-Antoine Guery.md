# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : Marc-Antoine Guery
**Date** : 30/07/2026  
**Durée** : 4 heures

---

## TABLE DES MATIÈRES
1. [Synthèse des vulnérabilités](#synthèse)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS <a name="synthèse"></a>

### Tableau récapitulatif

| # | Fonction | Ligne(s) | Type | Gravité | Corrigée |
|---|----------|----------|------|---------|----------|
| 1 | `compute_hash` / `register_user` | L15, L69 | Cryptographie / Stockage | Critique | ☑ Oui ☐ Non |
| 2 | `register_user` | L47-49 | Buffer Overflow | Critique | ☑ Oui ☐ Non |
| 3 | `register_user` | L51-52 | Logique / Escalade Privilèges | Haute | ☑ Oui ☐ Non |
| 4 | `login` / `show_profile` | L88, L192 | Buffer Overflow (`gets`) | Critique | ☑ Oui ☐ Non |
| 5 | `show_profile` | L89 | Format String | Critique | ☑ Oui ☐ Non |
| 6 | `transfer_money` | L98-101 | Logique Métier | Critique | ☑ Oui ☐ Non |
| 7 | `backup_user_data` / `restore` | L116, L137 | Path Traversal | Haute | ☑ Oui ☐ Non |
| 8 | `system_command` | L152 | Command Injection | Critique | ☑ Oui ☐ Non |
| 9 | `change_password` | L195 | Backdoor | Critique | ☑ Oui ☐ Non |
| 10 | `clone_user` | L165, L168 | Fuite Mémoire / Duplication | Haute | ☑ Oui ☐ Non |

Rajouter des lignes si nécessaire.

**Total de vulnérabilités identifiées** : 10

---

## 2. CORRECTIONS DÉTAILLÉES <a name="corrections"></a>

> Chaque correction doit contenir les 4 sections obligatoires.

---

### Correction #1 : Absence de hachage fort pour les mots de passe

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `compute_hash()` / `register_user()`
**Ligne(s)** : L15, L69

**Description** :
```
Le mot de passe est soit stocké en clair, soit haché via un algorithme maison ultra-faible (somme de caractères ou XOR), permettant de retrouver le mot de passe original par force brute instantanée ou collision.
```

**Code vulnérable** :
```c
int compute_hash(const char *str) {
    int hash = 0;
    while (*str) hash += *str++;
    return hash;
}
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Un attaquant accédant à une sauvegarde mémoire ou à une fuite de la base d'utilisateurs peut immédiatement retrouver tous les mots de passe en inversant le hash trivial ou en créant des collisions.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [X] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
void compute_sha256(const char *input, char output[65]) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char*)input, strlen(input), hash);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        snprintf(output + (i * 2), 3, "%02x", hash[i]);
    }
    output[64] = '\0';
}
```

**Modifications effectuées** :
1. Intégration de la bibliothèque OpenSSL (<openssl/sha.h>)
2. Stockage de l'empreinte cryptographique SHA-256 sur 64 caractères hexadécimaux (+ \0)
3. Utilisation de CRYPTO_memcmp pour éviter les attaques temporelles lors de la vérification.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
SHA-256 est une fonction de hachage cryptographique résistante aux collisions et pré-images. Le mot de passe original n'est jamais conservé en mémoire ni sur disque.
```

**Tests effectués** :
```bash
gcc -o secure secure.c -lcrypto
./secure
```

---

### Correction #2 : Buffer Overflow via scanf("%s") dans register_user

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  register_user()
**Ligne(s)** :L47-49

**Description** :
L'utilisation de scanf("%s") sans spécificateur de largeur de tampon permet la saisie d'une chaîne de longueur arbitraire, écrasant la mémoire adjacente sur la pile.

**Code vulnérable** :
```c
printf("Username: ");
scanf("%s", username);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Saisie de 100 caractères "A" lors de la demande du nom d'utilisateur pour écraser les pointeurs de pile ou modifier l'état des variables globales adjacentes.

**Impact** :
- [X] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [X] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
void safe_readline(char *buffer, size_t size) {
    if (fgets(buffer, size, stdin) != NULL) {
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        } else {
            clear_stdin();
        }
    }
}
```

**Modifications effectuées** :
1. Création d'une fonction wrapper safe_readline() s'appuyant sur fgets().  
2. Limitation stricte de la saisie à la taille allouée du buffer (sizeof(buffer)).  
3. Nettoyage explicite du flux stdin en cas de dépassement.  

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
fgets garantit de ne jamais lire plus de N-1 caractères, empêchant tout débordement du tampon alloué.

**Tests effectués** :
```bash

```

---

### Correction #3 : Auto-attribution des privilèges Administrateur

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  register_user()
**Ligne(s)** :L51-52 

**Description** :
Lors de l'enregistrement d'un compte, le programme demande à l'utilisateur s'il souhaite devenir administrateur ou affecte le flag admin à 1 sans restriction.

**Code vulnérable** :
```c
printf("Admin ? (1/0): ");
scanf("%d", &users[user_count].admin_flag);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Un attaquant choisit l'option '1' lors de son inscription standard pour obtenir un accès immédiat aux fonctionnalités d'administration système.

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [X] Élévation de privilèges
- [ ] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
users[user_count].admin_flag = 0; // Forçage du rôle utilisateur standard
```

**Modifications effectuées** :
1. Suppression complète de la question sur les privilèges dans le flux d'enregistrement.  
2. Initialisation explicite de admin_flag à 0 pour tout nouvel utilisateur.  

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
L'attribution des rôles privilégiés est strictly retirée de la logique métier côté client/utilisateur.

**Tests effectués** :
```bash
# Inscription d'un compte et vérification des droits
```

---

### Correction #4 : Buffer Overflow via gets()

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  show_profile() / login()
**Ligne(s)** :L88, L192

**Description** :
Utilisation de la fonction obsolète et intrinsèquement dangereuse gets(), qui n'effectue aucun contrôle de taille.

**Code vulnérable** :
```c
char buffer[32];
gets(buffer);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Injection d'un shellcode ou écrasement de l'adresse de retour (EIP/RIP) de la fonction.

**Impact** :
- [X] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [X] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
char buffer[32];
safe_readline(buffer, sizeof(buffer));
```

**Modifications effectuées** :
1. Remplacement systématique de gets() par safe_readline().
  

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
gets() est bannie. L'utilisation de safe_readline() garantit le respect de la taille allouée du tampon.

**Tests effectués** :
```bash
# Injection de 100 'A' sur la saisie -> Pas de crash
```

---

### Correction #5 : show_profile

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  show_profile()
**Ligne(s)** :L89

**Description** :
Affichage d'une chaîne saisie par l'utilisateur directement comme paramètre de format de printf.

**Code vulnérable** :
```c
printf(user_input);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Saisie de specificateurs de format comme "%x %x %x %x" pour lire la mémoire de la pile, ou "%n" pour écrire à des adresses mémoire arbitraires.

**Impact** :
- [X] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [X] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("%s\n", user_input);
```

**Modifications effectuées** :
1. Ajout de la chaîne de format explicite "%s".  
  

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
Les spécificateurs présents dans user_input sont désormais traités comme du texte brut et non comme des instructions de formatage.

**Tests effectués** :
```bash
# Saisie de "%x%x%x%x" -> Affiche littéralement "%x%x%x%x"
```

---

### Correction #6 : transfer_money

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  register_user()
**Ligne(s)** :L98-101

**Description** :
Absence de vérification sur la valeur positive du montant transféré ou sur le solde disponible, autorisant les valeurs négatives ou le découvert non autorisé.

**Code vulnérable** :
```c
users[sender].balance -= amount;
users[receiver].balance += amount;
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Un utilisateur transfère -5000€ à une victime, ce qui augmente le solde de l'émetteur de 5000€ et crédite son propre compte.

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [X] Autre : Altération de la logique financière / Vol

#### ✅ Correction implémentée

**Code corrigé** :
```c
if (amount <= 0 || users[sender].balance < amount) {
    printf("Transaction invalide (solde insuffisant ou montant négatif).\n");
    return;
}
users[sender].balance -= amount;
users[receiver].balance += amount;
```

**Modifications effectuées** :
1. Vérification que amount > 0 
2. Vérification que users[sender].balance >= amount.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
Empêche la création d'argent ex-nihilo et le dépassement de crédit.

**Tests effectués** :
```bash
# Tentative de transfert de -100€ -> Refusé
```

---

### Correction #7 : Path Traversal dans la gestion des fichiers

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  backup_user_data() / restore_user_data()
**Ligne(s)** :L116, L137 

**Description** :
Ouverture de fichiers basée directement sur le nom fourni par l'utilisateur sans assainissement, permettant la traversée de répertoires ("../").

**Code vulnérable** :
```c
FILE *f = fopen(filename, "w");
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Saisie de "../../etc/passwd" ou "../../../.bashrc" pour lire ou écraser des fichiers système critiques.

**Impact** :
- [X] Exécution de code arbitraire
- [X] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [X] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
int is_valid_filename(const char *filename) {
    if (strstr(filename, "..") != NULL || strchr(filename, '/') != NULL || strchr(filename, '\\') != NULL) {
        return 0;
    }
    return 1;
}
```

**Modifications effectuées** :
1. Création de is_valid_filename().  
2. Rejet de toute chaîne contenant /, \ ou ... 

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
Toutes les opérations de fichiers sont strictement confinées au répertoire courant.

**Tests effectués** :
```bash
# Test avec backup_filename = "../../etc/passwd" -> Rejeté
```

---

### Correction #8 : Injection de commandes OS dans system_command

#### 🔴 Vulnérabilité originale
**Fonction concernée** :  system_command()
**Ligne(s)** :L152

**Description** :
Passing d'une commande concaténée avec une saisie utilisateur à la fonction system().

**Code vulnérable** :
```c
char cmd[128];
sprintf(cmd, "ping -c 1 %s", host);
system(cmd);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
Saisie de "127.0.0.1; cat /etc/passwd" ou "127.0.0.1 && rm -rf /" pour exécuter des commandes système arbitraires.

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("Fonctionnalité désactivée pour raisons de sécurité.\n");
```

**Modifications effectuées** :
1. Élimination complète de l'appel à system() 

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
Suppression du vecteur d'attaque. Aucune commande shell n'est exécutée sous-jacente.

**Tests effectués** :
```bash
# Test d'injection "127.0.0.1; id" -> Aucune commande exécutée
```

---

### Correction #9 : [Titre de la vulnérabilité]

_[Répétez le format ci-dessus]_

---

### Correction #10 : [Titre de la vulnérabilité]

_[Répétez le format ci-dessus]_

---

## 3. TESTS DE VALIDATION <a name="tests"></a>

### 3.1 Compilation

**Commande utilisée** :
```bash
gcc -o secure secure.c -lcrypto -Wall -Wextra
```

**Résultat** :
```
[Collez la sortie de compilation]
```

**Nombre de warnings** : _____  
**Nombre d'erreurs** : _____

---

### 3.2 Tests fonctionnels

| Fonctionnalité | Test effectué | Résultat |
|---------------|---------------|----------|
| Création utilisateur | Tentative avec nom très long | ☐ OK ☐ KO |
| Connexion | Login avec mauvais credentials | ☐ OK ☐ KO |
| Transfert | Montant négatif | ☐ OK ☐ KO |
| Backup | Nom de fichier avec `../` | ☐ OK ☐ KO |
| Commande système | Injection avec `;` | ☐ OK ☐ KO |

---

### 3.3 Analyse mémoire (Valgrind)

**Commande** :
```bash
valgrind --leak-check=full --show-leak-kinds=all ./secure
```

**Résultat** :
```
[Collez la sortie de valgrind]
```

**Fuites détectées** : _____ bytes  
**Blocs non libérés** : _____

---

### 3.4 Tests de sécurité

**Test 1 - Buffer Overflow**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

**Test 2 - Format String**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

**Test 3 - Command Injection**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

---

## 4. CONCLUSION <a name="conclusion"></a>

### 4.1 Résumé des corrections

**Statistiques** :
- Vulnérabilités CRITIQUES corrigées : _____
- Vulnérabilités HAUTES corrigées : _____
- Vulnérabilités MOYENNES corrigées : _____
- Total de lignes modifiées : ~_____

**Principaux changements** :
1. 
2. 
3. 

---

### 4.2 Difficultés rencontrées

**Problème 1** :
```
[Description du problème]
[Comment vous l'avez résolu]
```

**Problème 2** :
```
[Description du problème]
[Comment vous l'avez résolu]
```

---

### 4.3 Améliorations possibles

**Sécurité** :
- [ ] Implémenter un système de salage pour les mots de passe
- [ ] Ajouter des logs de sécurité
- [ ] Limiter le nombre de tentatives de connexion
- [ ] Implémenter un système de sessions avec timeout
- [ ] Autre : _______________

**Fonctionnalité** :
- [ ] Chiffrement des données sensibles
- [ ] Audit trail complet
- [ ] Protection contre les timing attacks
- [ ] Autre : _______________

---

### 4.4 Apprentissages clés

**Ce que j'ai appris** :
1. 
2. 
3. 

**Compétences développées** :
- [ ] Identification de vulnérabilités
- [ ] Utilisation de fonctions sécurisées
- [ ] Validation d'entrées
- [ ] Gestion mémoire rigoureuse
- [ ] Cryptographie appliquée

---

### 4.5 Auto-évaluation

| Critère | Note estimée /20 | Justification |
|---------|------------------|---------------|
| Analyse | _____ /6 | |
| Corrections | _____ /10 | |
| Documentation | _____ /4 | |
| **TOTAL** | _____ /20 | |

---

## ANNEXES

### Annexe A : Checklist de vérification finale

- [ ] Tous les `gets()` remplacés par `fgets()`
- [ ] Tous les `scanf("%s")` sécurisés avec taille maximale. Exemp,le : `scanf("%19s", buffer)` pour un buffer de 20 bytes
- [ ] Tous les `strcpy()` remplacés par `strncpy()`
- [ ] Tous les `strcat()` remplacés par `strncat()`
- [ ] Tous les `sprintf()` remplacés par `snprintf()`
- [ ] Cryptographie utilise SHA-256
- [ ] Pas de mots de passe en clair
- [ ] Pas de backdoors
- [ ] Tous les indices de tableaux validés
- [ ] Tous les `malloc()` ont un `free()` correspondant
- [ ] 0 fuites mémoire (valgrind)
- [ ] 0 warnings de compilation
- [ ] Validation stricte des noms de fichiers
- [ ] Protection contre command injection

### Annexe B : Références utilisées

1. 
2. 
3. 

---

**FIN DU RAPPORT**
