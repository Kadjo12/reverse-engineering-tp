/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Code corrigé et sécurisé : secure.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha256.h>
#include <openssl/crypto.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

// --- V02 : Augmentation des tailles de buffer pour éviter les tronquages accidentels ---
// VULNÉRABLE (V01, V02) :
// typedef struct {
//     char username[16];
//     char password[16];
//     int admin_flag;
//     int balance;
//     char *token;
// } User;

typedef struct {
    char username[32];
    char password_hash[65]; // Stockage du hash SHA-256 en hexadécimal (64 car + '\0')
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// ==========================================
// FONCTIONS UTILITAIRES DE SÉCURITÉ
// ==========================================

// Vidage du buffer d'entrée stdin
void clear_stdin() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Lecture sécurisée d'une chaîne depuis stdin (remplace gets et scanf)
void safe_readline(char *buffer, size_t size) {
    if (fgets(buffer, (int)size, stdin) != NULL) {
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        } else {
            clear_stdin();
        }
    } else {
        buffer[0] = '\0';
    }
}

// Validation des noms d'utilisateurs (caractères alphanumériques uniquement)
int is_valid_username(const char *str) {
    if (strlen(str) < 3 || strlen(str) >= 32) return 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isalnum((unsigned char)str[i]) && str[i] != '_') return 0;
    }
    return 1;
}

// Validation des noms de fichiers (Anti Path-Traversal)
int is_valid_filename(const char *filename) {
    if (strlen(filename) == 0 || strlen(filename) > 64) return 0;
    if (strstr(filename, "..") != NULL || strchr(filename, '/') != NULL || strchr(filename, '\\') != NULL) {
        return 0; // Refuser la traversée de répertoire et les chemins absolus/relatifs
    }
    return 1;
}

// Hachage SHA-256 d'un mot de passe
void compute_sha256(const char *input, char output[65]) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char*)input, strlen(input), hash);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(output + (i * 2), "%02x", hash[i]);
    }
    output[64] = '\0';
}

// VULNÉRABLE (V26) : Pas de nettoyage mémoire global
void cleanup_memory() {
    for (int i = 0; i < user_count; i++) {
        if (users[i].token != NULL) {
            free(users[i].token);
            users[i].token = NULL;
        }
    }
}

// VULNÉRABLE (V01) : Fonction de hashage personnalisée faible (DJB2)
// unsigned int hash_password(char *pass) {
//     unsigned int h = 5381;
//     int c;
//     while ((c = *pass++))
//         h = h * 33 + c;
//     return h;
// }

// REMPLACEMENT (V01) : SHA-256 d'OpenSSL est utilisé via compute_sha256()

// Enregistrement d'un nouvel utilisateur
void register_user() {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    
    char username[100];
    char password[100];
    char confirm[100];
    int admin;
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    
    // VULNÉRABLE (V04) :
    // scanf("%s", username);
    safe_readline(username, sizeof(username));
    
    if (!is_valid_username(username)) {
        printf("Nom d'utilisateur invalide (3-31 caractères alphanumériques/underscores uniquement).\n");
        return;
    }
    
    printf("Password: ");
    // VULNÉRABLE (V04) :
    // scanf("%s", password);
    safe_readline(password, sizeof(password));
    
    printf("Confirmer password: ");
    // VULNÉRABLE (V04) :
    // scanf("%s", confirm);
    safe_readline(confirm, sizeof(confirm));
    
    // VULNÉRABLE (V08) : Absence de vérification du mot de passe de confirmation
    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas!\n");
        return;
    }
    
    printf("Droits admin (1=oui, 0=non): ");
    // VULNÉRABLE (V06) : Auto-attribution arbitraire des droits admin par un utilisateur
    // scanf("%d", &admin);
    // REMPLACEMENT (V06) : Seul un admin existant pourrait créer un admin, sinon forcé à 0 lors du register public
    admin = 0;
    printf("0 (Attribution automatique de privilèges désactivée par sécurité)\n");
    
    // VULNÉRABLE (V05) :
    // strcpy(users[user_count].username, username);
    // strcpy(users[user_count].password, password);
    strncpy(users[user_count].username, username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    
    compute_sha256(password, users[user_count].password_hash);
    
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;
    
    // VULNÉRABLE (V07, V23) :
    // users[user_count].token = malloc(32);
    // sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
    users[user_count].token = malloc(64);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, 64, "TOK_%d_%s_%ld", user_count, username, time(NULL));
    }
    
    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    char hash[65];
    compute_sha256(password, hash);
    
    for (int i = 0; i < user_count; i++) {
        // VULNÉRABLE (V09) : Timing attack avec strcmp classique sur mot de passe en clair
        // if(strcmp(users[i].username, username) == 0 && 
        //    strcmp(users[i].password, password) == 0) {
        
        // REMPLACEMENT (V09) : Comparaison à temps constant sur les hashs
        if (strcmp(users[i].username, username) == 0) {
            if (CRYPTO_memcmp(users[i].password_hash, hash, 64) == 0) {
                return i;
            }
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    // VULNÉRABLE (V12) : Validation manquante des bornes de l'indice
    if (user_id < 0 || user_id >= user_count) {
        printf("ID utilisateur invalide\n");
        return;
    }

    char format[80];
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    
    printf("Remarque / Note de profil: ");
    // VULNÉRABLE (V10, V11) :
    // gets(format);
    // printf(format);
    safe_readline(format, sizeof(format));
    printf("%s", format); // REMPLACEMENT (V11) : printf("%s", format) empêche les vulnérabilités Format String
    printf("\n");
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    if (from_user < 0 || from_user >= user_count) return;

    char to_username[50];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    
    // VULNÉRABLE (V14) :
    // scanf("%s", to_username);
    safe_readline(to_username, sizeof(to_username));
    
    printf("Montant: ");
    // VULNÉRABLE (V13) :
    // scanf("%d", &amount);
    if (scanf("%d", &amount) != 1) {
        clear_stdin();
        printf("Montant invalide\n");
        return;
    }
    clear_stdin();
    
    // REMPLACEMENT (V13) : Vérification d'un montant positif et du solde disponible
    if (amount <= 0) {
        printf("Le montant doit être strictement positif!\n");
        return;
    }
    if (users[from_user].balance < amount) {
        printf("Solde insuffisant!\n");
        return;
    }
    
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;

    char filename[100];
    FILE *fp;
    
    printf("Nom du fichier de backup: ");
    // VULNÉRABLE (V15) :
    // scanf("%s", filename);
    safe_readline(filename, sizeof(filename));
    
    // REMPLACEMENT (V15) : Validation anti-path traversal
    if (!is_valid_filename(filename)) {
        printf("Nom de fichier invalide ou chemin non autorisé!\n");
        return;
    }
    
    fp = fopen(filename, "w");
    if (fp) {
        // VULNÉRABLE (V16) : Écriture du mot de passe en clair dans un fichier
        // fprintf(fp, "%s:%s:%d:%d\n", 
        //         users[user_id].username,
        //         users[user_id].password,
        //         users[user_id].admin_flag,
        //         users[user_id].balance);
        
        // REMPLACEMENT (V16) : Sauvegarde uniquement de l'empreinte cryptographique
        fprintf(fp, "%s:%s:%d:%d\n", 
                users[user_id].username,
                users[user_id].password_hash,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé avec succès.\n");
    } else {
        printf("Erreur lors de la création du fichier\n");
    }
}

// Restauration des données
void restore_user_data(int logged_user) {
    // VULNÉRABLE (V18) : Restauration accessible sans être connecté/admin
    if (logged_user < 0 || !users[logged_user].admin_flag) {
        printf("Accès refusé : privilèges administrateur requis.\n");
        return;
    }

    char filename[200];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    // VULNÉRABLE (V17) :
    // scanf("%s", filename);
    safe_readline(filename, sizeof(filename));
    
    // REMPLACEMENT (V17) : Validation du nom de fichier
    if (!is_valid_filename(filename)) {
        printf("Nom de fichier invalide!\n");
        return;
    }
    
    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    // VULNÉRABLE (V19, V20, V21) : Exécution directe de commandes arbitraires transmises à system()
    // char cmd[150];
    // char full_cmd[200];
    // printf("=== COMMANDE SYSTÈME ===\n");
    // printf("Commande: ");
    // gets(cmd);
    // sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
    // system(full_cmd);

    // REMPLACEMENT (V19) : Suppression complète du shell dynamique system() au profit de fonctions sûres prédéfinies
    printf("=== STATUT SYSTÈME ===\n");
    printf("Nom de la machine : localhost\n");
    printf("Heure système : %ld\n", time(NULL));
}
// Copie de données utilisateur
void clone_user(int source_id) {
    if (source_id < 0 || source_id >= user_count) return;

    char target_username[30];
    
    printf("Nom du clone: ");
    // VULNÉRABLE (V22) :
    // scanf("%s", target_username);
    safe_readline(target_username, sizeof(target_username));
    
    if (!is_valid_username(target_username)) {
        printf("Nom de clone invalide!\n");
        return;
    }

    if (user_count >= MAX_USERS) {
        printf("Limite d'utilisateurs atteinte.\n");
        return;
    }
    
    // VULNÉRABLE (V22) :
    // strcpy(users[user_count].username, target_username);
    // strcpy(users[user_count].password, users[source_id].password);
    strncpy(users[user_count].username, target_username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    
    strncpy(users[user_count].password_hash, users[source_id].password_hash, sizeof(users[user_count].password_hash));
    
    // VULNÉRABLE (Logique Métier) : Duplication illimitée de solde bancaire
    // users[user_count].admin_flag = users[source_id].admin_flag;
    // users[user_count].balance = users[source_id].balance;

    // REMPLACEMENT : Seul le profil de connexion est dupliqué, l'admin_flag reste à 0 
    // et le solde est réinitialisé à la valeur par défaut (100€) pour éviter la création d'argent.
    users[user_count].admin_flag = 0;
    users[user_count].balance = 100;
    
    // VULNÉRABLE (V23) : Pointeur token non alloué/réinitialisé
    users[user_count].token = malloc(64);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, 64, "TOK_%d_%s_%ld", user_count, target_username, time(NULL));
    }

    user_count++;
    printf("Clone créé avec succès (Solde réinitialisé à 100€ par sécurité).\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;

    char old_pass[80];
    char new_pass[80];
    char old_hash[65];
    char new_hash[65];
    
    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    // VULNÉRABLE (V25) :
    // gets(old_pass);
    safe_readline(old_pass, sizeof(old_pass));
    
    compute_sha256(old_pass, old_hash);

    // VULNÉRABLE (V24) : Backdoor master_reset_2024
    // if(strcmp(users[user_id].password, old_pass) == 0 || 
    //    strcmp(old_pass, "master_reset_2024") == 0) {

    // REMPLACEMENT (V24) : suppression de la backdoor et vérification du hash uniquement
    if (CRYPTO_memcmp(users[user_id].password_hash, old_hash, 64) == 0) {
        printf("Nouveau mot de passe: ");
        // VULNÉRABLE (V25) :
        // gets(new_pass);
        safe_readline(new_pass, sizeof(new_pass));

        compute_sha256(new_pass, new_hash);
        
        // VULNÉRABLE (V25) :
        // strcpy(users[user_id].password, new_pass);
        strncpy(users[user_id].password_hash, new_hash, sizeof(users[user_id].password_hash));
        printf("Mot de passe changé avec succès.\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    // VULNÉRABLE (V26) : Division par zéro si user_count == 0
    if (user_count == 0) {
        printf("Aucun utilisateur dans le système.\n");
        return;
    }

    int total = 0;
    double avg;
    char buffer[120];
    
    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];
    
    printf("Rechercher: ");
    // VULNÉRABLE (V14) :
    // scanf("%s", query);
    safe_readline(query, sizeof(query));
    
    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE SÉCURISÉ (secure)  ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    // Compte admin par défaut
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    compute_sha256("admin123", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(64);
    if (users[0].token != NULL) {
        strcpy(users[0].token, "ADMIN_TOKEN");
    }
    user_count = 1;
    
    while (1) {
        display_menu();
        if (scanf("%d", &choice) != 1) {
            clear_stdin();
            printf("Choix invalide\n");
            continue;
        }
        clear_stdin();
        
        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                safe_readline(username, sizeof(username));
                printf("Password: ");
                safe_readline(password, sizeof(password));
                logged_user = login_user(username, password);
                if (logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if (logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if (logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data(logged_user);
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if (logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                cleanup_memory(); // Libération globale de la mémoire allouée
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }
    
    cleanup_memory();
    return 0;
}