/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Version Securisée (secure.c)
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>

#define MAX_USERS 10
#define USERNAME_LEN 32
#define PASSWORD_LEN 64
#define HASH_LEN 65 // 64 char hex + null terminator
#define SALT_LEN 16
#define LOG_BUFFER_SIZE 256

typedef struct {
    int id;
    char username[USERNAME_LEN];
    char password_hash[HASH_LEN];
    char salt[SALT_LEN * 2 + 1];
    int is_admin;
    int login_attempts;
    int is_locked;
} User;

static User users[MAX_USERS];
static int user_count = 0;
static int current_user_index = -1;

/* Vidage du tampon d'entrée de manière sécurisée */
static void clear_stdin_buffer(void) {
    int c;
    while ((c = getchar()) != '\0' && c != '\n' && c != EOF);
}

/* Génération d'un sel aléatoire sécurisé */
static void generate_salt(char *salt_hex, size_t len) {
    unsigned char salt_bytes[SALT_LEN];
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f) {
        perror("Erreur d'ouverture de /dev/urandom");
        exit(EXIT_FAILURE);
    }
    if (fread(salt_bytes, 1, SALT_LEN, f) != SALT_LEN) {
        perror("Erreur de lecture du sel");
        fclose(f);
        exit(EXIT_FAILURE);
    }
    fclose(f);

    for (size_t i = 0; i < SALT_LEN && (i * 2 + 1) < len; i++) {
        snprintf(&salt_hex[i * 2], 3, "%02x", salt_bytes[i]);
    }
}

/* Hachage SHA-256 avec OpenSSL */
static void hash_password(const char *password, const char *salt, char *output) {
    char combined[PASSWORD_LEN + SALT_LEN * 2 + 1];
    snprintf(combined, sizeof(combined), "%s%s", password, salt);

    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char *)combined, strlen(combined), hash);

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        snprintf(&output[i * 2], 3, "%02x", hash[i]);
    }
    output[HASH_LEN - 1] = '\0';
}

/* Nettoyage des chaînes saisies (suppression du \n) */
static void strip_newline(char *str) {
    size_t len = strlen(str);
    if (len > 0 && str[len - 1] == '\n') {
        str[len - 1] = '\0';
    } else if (len == sizeof(str) - 1) {
        clear_stdin_buffer();
    }
}

/* Validation du nom d'utilisateur (alphanumérique uniquement) */
static int is_valid_username(const char *username) {
    if (strlen(username) == 0 || strlen(username) >= USERNAME_LEN) return 0;
    for (int i = 0; username[i] != '\0'; i++) {
        if (!isalnum((unsigned char)username[i]) && username[i] != '_') {
            return 0;
        }
    }
    return 1;
}

/* Journalisation sécurisée sans injection de format */
static void log_action(const char *username, const char *action) {
    FILE *f = fopen("app.log", "a");
    if (!f) return;

    time_t now = time(NULL);
    char date_buf[26];
    ctime_r(&now, date_buf);
    date_buf[24] = '\0';

    fprintf(f, "[%s] User: %s - Action: %s\n", date_buf, username, action);
    fclose(f);
}

static void register_user(void) {
    if (user_count >= MAX_USERS) {
        printf("Nombre maximum d'utilisateurs atteint.\n");
        return;
    }

    char username[USERNAME_LEN];
    char password[PASSWORD_LEN];

    printf("Nom d'utilisateur : ");
    if (!fgets(username, sizeof(username), stdin)) return;
    strip_newline(username);

    if (!is_valid_username(username)) {
        printf("Nom d'utilisateur invalide (caracteres alphanumeriques uniquement).\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            printf("Cet utilisateur existe deja.\n");
            return;
        }
    }

    printf("Mot de passe : ");
    if (!fgets(password, sizeof(password), stdin)) return;
    strip_newline(password);

    if (strlen(password) < 8) {
        printf("Le mot de passe doit contenir au moins 8 caracteres.\n");
        return;
    }

    User new_user;
    new_user.id = user_count + 1;
    snprintf(new_user.username, sizeof(new_user.username), "%s", username);
    
    generate_salt(new_user.salt, sizeof(new_user.salt));
    hash_password(password, new_user.salt, new_user.password_hash);

    new_user.is_admin = (user_count == 0) ? 1 : 0;
    new_user.login_attempts = 0;
    new_user.is_locked = 0;

    users[user_count++] = new_user;
    printf("Utilisateur cree avec succes !\n");
    log_action(username, "REGISTER");

    // Nettoyage de la mémoire sensible
    memset(password, 0, sizeof(password));
}

static void login(void) {
    char username[USERNAME_LEN];
    char password[PASSWORD_LEN];

    printf("Nom d'utilisateur : ");
    if (!fgets(username, sizeof(username), stdin)) return;
    strip_newline(username);

    printf("Mot de passe : ");
    if (!fgets(password, sizeof(password), stdin)) return;
    strip_newline(password);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            if (users[i].is_locked) {
                printf("Compte verrouille suite a de trop nombreuses tentatives.\n");
                memset(password, 0, sizeof(password));
                return;
            }

            char computed_hash[HASH_LEN];
            hash_password(password, users[i].salt, computed_hash);

            if (strcmp(users[i].password_hash, computed_hash) == 0) {
                current_user_index = i;
                users[i].login_attempts = 0;
                printf("Connexion reussie ! Bienvenue %s.\n", users[i].username);
                log_action(username, "LOGIN_SUCCESS");
                memset(password, 0, sizeof(password));
                return;
            } else {
                users[i].login_attempts++;
                if (users[i].login_attempts >= 3) {
                    users[i].is_locked = 1;
                    printf("Mot de passe incorrect. Compte verrouille !\n");
                } else {
                    printf("Mot de passe incorrect (%d/3).\n", users[i].login_attempts);
                }
                log_action(username, "LOGIN_FAILURE");
                memset(password, 0, sizeof(password));
                return;
            }
        }
    }
    printf("Nom d'utilisateur ou mot de passe incorrect.\n");
    memset(password, 0, sizeof(password));
}

static void show_profile(void) {
    if (current_user_index < 0 || current_user_index >= user_count) {
        printf("Vous devez etre connecte.\n");
        return;
    }
    User *u = &users[current_user_index];
    printf("\n--- PROFIL ---\n");
    printf("ID: %d\n", u->id);
    printf("Username: %s\n", u->username);
    printf("Role: %s\n", u->is_admin ? "Admin" : "Utilisateur");
}

int main(void) {
    char input[10];
    int choice = -1;

    while (choice != 0) {
        printf("\n=== MENU ===\n");
        printf("1. S'inscrire\n");
        printf("2. Se connecter\n");
        printf("3. Voir mon profil\n");
        printf("0. Quitter\n");
        printf("Choix : ");

        if (!fgets(input, sizeof(input), stdin)) break;
        choice = atoi(input);

        switch (choice) {
            case 1: register_user(); break;
            case 2: login(); break;
            case 3: show_profile(); break;
            case 0: printf("Au revoir !\n"); break;
            default: printf("Choix invalide.\n"); break;
        }
    }
    return 0;
}