# 🔐 RAPPORT DE SÉCURITÉ — TP FINAL

### Sécurisation de code C vulnérable

|                |                                      |
| :------------- | :----------------------------------- |
| **Étudiant**   | **FATHI Naim**                       |
| **Date**       | **30/07/2026**                       |
| **Durée**      | 4 heures                             |
| **Livrables**  | `secure.c` · `RAPPORT.md` · `Makefile` |

---

> ### 📊 Résultats en un coup d'œil
>
> | Indicateur | Résultat |
> | :--- | :--- |
> | Vulnérabilités identifiées | **36** |
> | Vulnérabilités **corrigées** | **24 / 36** — soit **67 %** |
> | Vulnérabilités **reportées** (pistes documentées) | **12 / 36** |
> | Couverture des failles Critiques | **16 / 16 — 100 %** |
> | Couverture des failles Hautes | **6 / 8 — 75 %** |
> | Warnings de compilation | **0** (y compris `-Wpedantic`) |
> | Fuites mémoire (Valgrind) | **0 octet** — 0 erreur |
> | ASan + UBSan | **0 erreur** |
> | Analyse statique `cppcheck` / `clang` | **0** sur `secure.c` — *20 / 10 sur `vulnerable.c`* |
> | Fonctions dangereuses restantes | **0** (`gets`/`scanf`/`strcpy`/`strcat`/`sprintf`/`system`) |
> | Tests de sécurité | **19 / 19 réussis** |
>
> **Stratégie retenue** : traiter d'abord l'intégralité des failles exploitables à distance
> (corruption mémoire, injections, contournement d'authentification), puis documenter
> honnêtement les faiblesses résiduelles de conception dans la section
> [Pistes à explorer](#5-pistes-à-explorer) plutôt que de les corriger à la hâte.

---

## 📑 TABLE DES MATIÈRES

1. [Synthèse des vulnérabilités](#1-synthèse-des-vulnérabilités)
2. [Corrections détaillées](#2-corrections-détaillées) — *les 24 failles traitées*
3. [Tests de validation](#3-tests-de-validation)
4. [Conclusion](#4-conclusion)
5. [Pistes à explorer](#5-pistes-à-explorer) — *les 12 faiblesses assumées*
6. [Annexes](#6-annexes)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS

### 1.1 Méthode d'analyse

J'ai procédé à une lecture **séquentielle et exhaustive** de `vulnerable.c` (402 lignes), fonction par fonction, en m'appuyant sur la checklist des consignes (buffer overflows, validation, mémoire, cryptographie, injections, format string, logique métier).

Trois portions du programme se sont révélées **saines** et n'ont donc pas nécessité de correction — les mentionner fait partie de l'analyse :

- `list_users()` (L209-215) : parcours borné par `user_count`, aucun risque.
- `cleanup_sessions()` (L268-275) : lecture seule sur un tableau borné.
- `restore_user_data()` L168 : le `fgets(buffer, sizeof(buffer), fp)` était **déjà correct** (la faille de cette fonction est ailleurs : le chemin du fichier).

### 1.2 Tableau récapitulatif

Le tableau regroupe les vulnérabilités par **cause racine** plutôt que par ligne : les 4 appels à `gets()` relèvent du même défaut et comptent pour une entrée, avec le détail des sites concernés.

**Légende du statut** : ✅ corrigée dans `secure.c` · ⏳ reportée, documentée en [section 5](#5-pistes-à-explorer).

| #  | Fonction / portée | Ligne(s) | Type de vulnérabilité | Gravité | Statut |
|:--:|:------------------|:--------:|:----------------------|:-------:|:------:|
| 1  | `show_profile`, `system_command`, `change_password` | 105, 181, 224, 229 | Buffer overflow — `gets()` (4 sites) | 🔴 Critique | ✅ |
| 2  | `register`, `transfer`, `backup`, `restore`, `clone`, `search`, `main` | 61, 64, 67, 117, 139, 160, 192, 258, 329, 331 | Buffer overflow — `scanf("%s")` (10 sites) | 🟠 Haute | ✅ |
| 3  | `register`, `clone`, `change_password`, `main` | 72-73, 199-200, 230, 310-311, 315 | Buffer overflow — `strcpy` vers champ de 16 o | 🔴 Critique | ✅ |
| 4  | `register`, `system_command`, `compute_stats` | 78, 183, 249 | Buffer overflow — `sprintf` non borné | 🟠 Haute | ✅ |
| 5  | `show_profile` | 106 | **Format string** — `printf(format)` | 🔴 Critique | ✅ |
| 6  | `system_command` | 183-184 | **Injection de commande** — `system()` | 🔴 Critique | ✅ |
| 7  | `change_password` | 227 | **Backdoor** `master_reset_2024` | 🔴 Critique | ✅ |
| 8  | `struct User` | 21 | Mot de passe stocké **en clair** en mémoire | 🔴 Critique | ✅ |
| 9  | `hash_password` | 39-45 | Hash non cryptographique (DJB2, 32 bits) | 🔴 Critique | ✅ |
| 10 | `login_user` | 87-88 | Comparaison du mot de passe en clair | 🔴 Critique | ✅ |
| 11 | `main` | 310-311 | Mot de passe admin codé en dur, en clair | 🟠 Haute | ✅ |
| 12 | `backup_user_data` | 143-147 | Mot de passe écrit **en clair** sur disque | 🔴 Critique | ✅ |
| 13 | `backup_user_data` | 139, 141 | **Path traversal** — écriture arbitraire | 🔴 Critique | ✅ |
| 14 | `restore_user_data` | 160, 162 | **Path traversal** — lecture arbitraire | 🔴 Critique | ✅ |
| 15 | `restore_user_data` | main 360 | Accessible **sans authentification** | 🟡 Moyenne | ✅ |
| 16 | `transfer_money` | 124 | **Montant négatif accepté** (vol de fonds) | 🟠 Haute | ✅ |
| 17 | `transfer_money` | 124-125 | Aucun contrôle de solde | 🟠 Haute | ✅ |
| 18 | `transfer_money` | 122-128 | Auto-transfert non bloqué | 🟢 Faible | ✅ |
| 19 | `transfer_money`, `register` | 70, 120 | Entier non validé (`scanf("%d")`) | 🟡 Moyenne | ✅ |
| 20 | `lire_entier` *(dérivé)* | 70, 120, 320 | Troncature `long`→`int` contournant la validation | 🟡 Moyenne | ✅ |
| 21 | `compute_stats` | 247 | Division par zéro (SIGFPE) | 🟡 Moyenne | ✅ |
| 22 | `register`, `main` | 77, 314 | Retour de `malloc()` non vérifié | 🟠 Haute | ✅ |
| 23 | *global* | — | Aucun `free()` : fuite mémoire des tokens | 🟡 Moyenne | ✅ |
| 24 | `main` | 320 | Boucle infinie (saisie non numérique / EOF) | 🟡 Moyenne | ✅ |
| 25 | `register_user` | 66-67 | `confirm` jamais comparé à `password` | 🟢 Faible | ✅ |
| 26 | `hash_password` *(conception)* | 39-45 | Hachage **rapide** : pas de fonction de dérivation de clé | 🟠 Haute | ⏳ |
| 27 | `login_user` *(conception)* | 87-88 | Comparaison d'empreintes non à temps constant | 🟡 Moyenne | ⏳ |
| 28 | *global* | — | Secrets non effacés de la mémoire après usage | 🟢 Faible | ⏳ |
| 29 | `register_user` | 74 | **Auto-attribution du flag administrateur** | 🟠 Haute | ⏳ |
| 30 | `register_user` | 78 | Token prévisible (`TOK_<index>_<nom>`) | 🟡 Moyenne | ⏳ |
| 31 | `struct Session`, `cleanup_sessions` | 27-31, 268-275 | Sessions déclarées mais inexploitées, sans expiration | 🟡 Moyenne | ⏳ |
| 32 | `main` *(conception)* | 327-338 | Verrouillage anti-brute-force global et définitif | 🟡 Moyenne | ⏳ |
| 33 | `clone_user` | 202 | Duplication du solde (création monétaire) | 🟡 Moyenne | ⏳ |
| 34 | `register`, `change_password` | — | Aucune politique de complexité des mots de passe | 🟡 Moyenne | ⏳ |
| 35 | `backup_user_data` | 141-147 | Fichier de sauvegarde non chiffré | 🟡 Moyenne | ⏳ |
| 36 | *global* | — | Aucun journal d'audit ni limitation de débit | 🟢 Faible | ⏳ |

### 1.3 Bilan chiffré

| Gravité | Identifiées | Corrigées | Reportées | Taux |
| :--- | :---: | :---: | :---: | :---: |
| 🔴 Critique | 12 | **12** | 0 | **100 %** |
| 🟠 Haute | 8 | **6** | 2 | 75 % |
| 🟡 Moyenne | 13 | **9** | 4 | 69 % |
| 🟢 Faible | 3 | **1** | 2 | 33 % |
| **TOTAL** | **36** | **24** | **12** | **67 %** |

### 1.4 Stratégie de priorisation

Corriger 36 vulnérabilités en 4 heures n'était pas réaliste. J'ai donc appliqué une priorisation par **risque exploitable** plutôt que par facilité :

1. **Traité en priorité — tout ce qui est directement exploitable** : corruption mémoire (débordements, format string), injections (commande, chemin), contournement d'authentification (backdoor, mots de passe en clair) et intégrité financière (montants négatifs, contrôle de solde). L'intégralité des failles **Critiques** est corrigée.

2. **Reporté — les faiblesses de *conception*** : elles ne s'exploitent pas par une simple saisie malveillante mais découlent de choix d'architecture (modèle d'autorisation, gestion de sessions, politique cryptographique). Les corriger correctement suppose de repenser des pans entiers du programme ; les bâcler aurait produit une fausse impression de sécurité, ce qui est pire qu'une faiblesse assumée.

Chacune des 12 pistes reportées est documentée en [section 5](#5-pistes-à-explorer) avec son risque réel, la correction envisagée et sa difficulté estimée.

---

## 2. CORRECTIONS DÉTAILLÉES

> Chaque correction présente les 4 sections exigées :
> **① Vulnérabilité originale · ② Attaque possible · ③ Correction implémentée · ④ Justification de sécurité**

---

### ✦ Correction #1 — Élimination de `gets()`

**Fonctions** : `show_profile()`, `system_command()`, `change_password()` · **Lignes** : 105, 181, 224, 229

#### 🔴 Vulnérabilité originale

`gets()` ne reçoit aucune indication de taille : elle écrit tout ce que l'utilisateur saisit, sans limite. Une saisie plus longue que le tampon déborde sur la pile et écrase les données voisines, dont l'adresse de retour de la fonction.

```c
char format[80];
gets(format);            // aucune borne
```

#### 💥 Attaque possible

Envoyer plus de 80 octets écrase la pile. Avec un contenu construit (adresse de retour détournée + shellcode, ou chaîne ROP), l'attaquant prend le contrôle du flux d'exécution.

```bash
python3 -c "print('A'*200)" | ./vulnerable
```

**Impact** : ☑ exécution de code arbitraire · ☑ déni de service (crash)

#### ✅ Correction implémentée

Tous les `gets()` sont remplacés par une fonction maison `lire_ligne()` basée sur `fgets()` :

```c
int lire_ligne(char *buffer, int taille) {
    if (fgets(buffer, taille, stdin) == NULL) {
        buffer[0] = '\0';
        return 0;
    }
    int len = strlen(buffer);
    if (len > 0 && buffer[len - 1] == '\n') {
        buffer[len - 1] = '\0';
        return 1;
    }
    /* pas de '\n' : la ligne depassait le buffer. On vide le reste
       et on signale une erreur pour que l'appelant REJETTE l'entree
       au lieu de la tronquer silencieusement. */
    int c, trop_long = 0;
    while ((c = getchar()) != '\n' && c != EOF) trop_long = 1;
    if (trop_long) { buffer[0] = '\0'; return 0; }
    return 1;
}
```

**Modifications** :
1. `gets()` → `fgets()` avec taille explicite.
2. Suppression du `\n` final.
3. Purge du reste de la ligne (évite de polluer la lecture suivante).
4. **Rejet** d'une saisie trop longue plutôt qu'une troncature silencieuse.

#### 🛡️ Justification de sécurité

`fgets()` lit au maximum `taille - 1` octets et garantit toujours le `'\0'` terminal : le débordement est **structurellement impossible**. Le rejet explicite des lignes trop longues évite qu'une saisie de 500 caractères soit silencieusement raccourcie en une valeur valide.

```bash
printf '1\n%s\n0\n' "$(python3 -c "print('A'*500)")" | ./secure
# → "Nom invalide"   (aucun débordement, aucun crash)
```

---

### ✦ Correction #2 — Vulnérabilité de format string

**Fonction** : `show_profile()` · **Ligne** : 106

#### 🔴 Vulnérabilité originale

La saisie de l'utilisateur est passée **comme chaîne de format** à `printf`. Tous les spécificateurs qu'elle contient sont donc interprétés.

```c
gets(format);
printf(format);          // format contrôlé par l'utilisateur
```

#### 💥 Attaque possible

| Saisie | Effet |
| :--- | :--- |
| `%x %x %x` | lit et affiche le contenu de la pile |
| `%s` | déréférence un pointeur lu sur la pile → crash ou fuite |
| `%n` | **écrit** en mémoire le nombre d'octets déjà affichés |

`%n` transforme une simple fuite en **écriture arbitraire**, donc en exécution de code.

**Impact** : ☑ lecture mémoire · ☑ écriture mémoire · ☑ exécution de code · ☑ fuite d'informations

#### ✅ Correction implémentée

```c
printf("Note : %s\n", note);   // format FIXE, saisie en ARGUMENT
```

#### 🛡️ Justification de sécurité

Le format est désormais un **littéral constant** écrit par le développeur. La saisie n'est plus qu'un argument consommé par `%s` : les `%x`, `%n`, `%p` éventuellement présents sont affichés tels quels, jamais interprétés.

```bash
printf '2\nadmin\nadmin123\n3\n%%x %%n %%p\n0\n' | ./secure
# → "Note : %x %n %p"   (affiché littéralement)
```

---

### ✦ Correction #3 — SHA-256 salé à la place de DJB2 et du stockage en clair

**Fonctions** : `hash_password()` (39-45), `login_user()` (87-88), `struct User` (21)

#### 🔴 Vulnérabilité originale

Deux problèmes cumulés :

1. `hash_password()` implémente **DJB2**, un hash **non cryptographique** sur 32 bits (collisions calculables en quelques secondes).
2. Ce hash n'est de toute façon **jamais utilisé** : le mot de passe est stocké en clair dans la structure et comparé par `strcmp`.

```c
unsigned int hash_password(char *pass) {          // DJB2, non cryptographique
    unsigned int h = 5381; int c;
    while ((c = *pass++)) h = h * 33 + c;
    return h;
}
...
if (strcmp(users[i].password, password) == 0)     // comparaison en clair
```

#### 💥 Attaque possible

Un dump mémoire, un fichier de backup (cf. correction #6) ou un simple accès au disque révèle **tous les mots de passe en clair**. Aucun calcul n'est même nécessaire.

**Impact** : ☑ fuite des mots de passe · ☑ usurpation de comptes · ☑ élévation de privilèges

#### ✅ Correction implémentée

La structure ne conserve plus que le **sel** et l'**empreinte** — jamais le mot de passe :

```c
typedef struct {
    char username[TAILLE_NOM];
    char sel[TAILLE_SEL_HEX];    /* sel aleatoire 128 bits, en hexadecimal */
    char hash[TAILLE_HASH];      /* SHA-256(sel + mot de passe)            */
    int  admin_flag;
    int  balance;
    char *token;
} User;
```

```c
int calculer_hash(const char *mdp, const unsigned char *sel, char *sortie) {
    unsigned char resultat[EVP_MAX_MD_SIZE];
    unsigned int taille = 0;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (ctx == NULL) return 0;

    if (EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1 ||
        EVP_DigestUpdate(ctx, sel, TAILLE_SEL)     != 1 ||
        EVP_DigestUpdate(ctx, mdp, strlen(mdp))    != 1 ||
        EVP_DigestFinal_ex(ctx, resultat, &taille) != 1) {
        EVP_MD_CTX_free(ctx);
        return 0;
    }
    EVP_MD_CTX_free(ctx);
    vers_hex(resultat, 32, sortie);
    return 1;
}
```

Le sel de 128 bits est tiré par `RAND_bytes()` à chaque définition de mot de passe.

**Modifications** :
1. DJB2 supprimé, remplacé par SHA-256 (OpenSSL), conformément aux consignes du TP.
2. Champ `password[16]` **retiré** de la structure.
3. Sel aléatoire unique par compte.
4. Vérification par recalcul de l'empreinte, jamais par comparaison de mot de passe.

#### 🛡️ Justification de sécurité

SHA-256 est résistant aux préimages et aux collisions : retrouver un mot de passe à partir de l'empreinte n'est pas faisable par inversion directe. Le **sel unique** défait les tables Rainbow et empêche de constater que deux comptes partagent le même mot de passe.

J'ai utilisé l'API `EVP_*` et non `SHA256_Init/Update/Final` : cette dernière est **dépréciée depuis OpenSSL 3.0** et génère des warnings sous `-Wall -Wextra`.

**Vérification empirique** — même mot de passe, deux comptes :

```
compte A : hash = 2c419db9c7aa887d5b42…
compte B : hash = 9a6d54c0f37e17aede3a…
→ empreintes différentes (le salage fonctionne)
→ mais déterministe à sel constant, donc la connexion fonctionne
```

> ⏳ **Limite assumée.** SHA-256 reste une fonction **rapide**, conçue pour le hachage de données et non pour le stockage de mots de passe. Un attaquant qui obtiendrait la base pourrait tester des milliards de candidats par seconde sur GPU. Une fonction de dérivation de clé (PBKDF2, Argon2id) serait nécessaire pour ralentir cette attaque hors ligne. Voir **piste #1**, section 5.

---

### ✦ Correction #4 — Remplacement des `strcpy` et `sprintf` non bornés

**Fonctions** : `register_user()` (72-73, 78), `clone_user()` (199), `change_password()` (230), `main()` (310-311)

#### 🔴 Vulnérabilité originale

Les tampons de saisie font 100 octets, les champs de destination **16 octets**. `strcpy` copie jusqu'au `'\0'` sans se soucier de la taille de destination : tout nom de plus de 15 caractères déborde.

```c
char username[100];
strcpy(users[user_count].username, username);            // 100 → 16 : overflow
sprintf(users[user_count].token, "TOK_%d_%s", ...);      // token[32] : overflow
```

#### 💥 Attaque possible

Un nom de 40 caractères déborde `username[16]` et écrase les champs **suivants** de la structure — `password`, puis `admin_flag`, puis `balance`. Un attaquant peut ainsi corrompre l'état d'un compte, voire activer son propre flag administrateur.

**Impact** : ☑ corruption mémoire · ☑ élévation de privilèges · ☑ exécution de code · ☑ crash

#### ✅ Correction implémentée

```c
snprintf(users[i].username, TAILLE_NOM,   "%s", username);
snprintf(users[i].token,    TAILLE_TOKEN, "TOK_%d_%s", i, username);
```

Pour la copie du sel et du hash **entre deux comptes** (clonage), j'utilise `memcpy` entre deux champs de taille fixe identique :

```c
memcpy(users[i].sel,  users[source_id].sel,  TAILLE_SEL_HEX);
memcpy(users[i].hash, users[source_id].hash, TAILLE_HASH);
```

> 💡 **Pourquoi `memcpy` et non `snprintf` ici ?** Source et destination appartiennent au **même tableau** `users[]`. GCC le détecte et émet un warning `-Wrestrict` (`argument overlaps destination object`). `memcpy` entre deux champs de taille identique et connue à la compilation est à la fois correct et sans warning.

#### 🛡️ Justification de sécurité

`snprintf` n'écrit **jamais** plus de `taille` octets, terminaison `'\0'` comprise. Combiné à la validation de longueur en amont (`nom_valide()` limite à 15 caractères), tout débordement devient impossible.

> **Note** : les consignes suggéraient `strncpy`. J'ai préféré `snprintf` car `strncpy` **ne garantit pas** la terminaison nulle si la source est plus longue que `n` — ce qui recrée un risque de lecture hors limites.

---

### ✦ Correction #5 — Suppression de l'injection de commande

**Fonction** : `system_command()` · **Lignes** : 181-184

#### 🔴 Vulnérabilité originale

La saisie utilisateur est concaténée dans une chaîne transmise à `system()`, qui la fait exécuter par `/bin/sh`. La saisie est en plus lue par `gets()`.

```c
gets(cmd);
sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
system(full_cmd);
```

#### 💥 Attaque possible

Les métacaractères du shell (`;`, `&&`, `|`, `` ` ``, `$()`) permettent d'enchaîner des commandes arbitraires avec les privilèges du programme :

```
Entrée : ls ; cat /etc/passwd ; rm -rf ~
```

**Impact** : ☑ exécution de commandes système · ☑ fuite d'informations · ☑ destruction de données

#### ✅ Correction implémentée

La fonctionnalité est **supprimée** et remplacée par un affichage d'informations internes, sans aucune commande externe :

```c
void system_command() {
    printf("=== INFOS SYSTEME ===\n");
    printf("Heure : %ld\n", (long)time(NULL));
    printf("Nombre de comptes : %d\n", user_count);
}
```

#### 🛡️ Justification de sécurité

Aucun shell n'est invoqué et **aucune donnée utilisateur n'atteint un interpréteur**. L'injection devient impossible par construction — c'est la seule garantie robuste, l'échappement de métacaractères étant notoirement difficile à rendre exhaustif.

```bash
printf '2\nadmin\nadmin123\n7\n0\n' | ./secure
# → "=== INFOS SYSTEME ===" (aucun /bin/sh lancé)
```

---

### ✦ Correction #6 — Path traversal et fuite de secrets (backup / restore)

**Fonctions** : `backup_user_data()` (139-147), `restore_user_data()` (160-162)

#### 🔴 Vulnérabilité originale

Le nom de fichier est lu sans aucune validation puis ouvert directement. De plus, le backup écrit le **mot de passe en clair** dans le fichier.

```c
scanf("%s", filename);
fp = fopen(filename, "w");
fprintf(fp, "%s:%s:%d:%d\n", username, password, admin_flag, balance);
//                    ↑ mot de passe en clair sur le disque
```

#### 💥 Attaque possible

| Vecteur | Saisie | Conséquence |
| :--- | :--- | :--- |
| Écriture arbitraire | `../../home/victime/.bashrc` | écrase un fichier exécuté au login → RCE |
| Lecture arbitraire | `../../etc/passwd` | divulgue un fichier système via `restore` |
| Fuite directe | *(n'importe quel nom)* | le backup contient les identifiants |

**Impact** : ☑ lecture/écriture de fichiers arbitraires · ☑ fuite d'informations · ☑ élévation de privilèges

#### ✅ Correction implémentée

```c
int fichier_valide(const char *nom) {
    int len = strlen(nom);
    if (len < 1 || len > 50)          return 0;
    if (nom[0] == '/' || nom[0] == '.') return 0;   /* ni absolu ni "." / ".." */
    if (strstr(nom, "..") != NULL)      return 0;   /* pas de remontée */
    for (int i = 0; i < len; i++) {
        char c = nom[i];
        if (!isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.')
            return 0;                               /* interdit '/', '\', espaces */
    }
    return 1;
}
```

```c
/* Plus AUCUN mot de passe (ni hash) exporté */
fprintf(fp, "%s:%d:%d\n",
        users[user_id].username,
        users[user_id].admin_flag,
        users[user_id].balance);
```

`restore_user_data()` est en outre désormais **réservée aux utilisateurs connectés**.

#### 🛡️ Justification de sécurité

La validation repose sur une **liste blanche** de caractères : tout ce qui n'est pas explicitement autorisé est refusé. Le séparateur `/` et la séquence `..` étant exclus, l'accès reste confiné au répertoire courant. Une liste noire aurait été contournable (encodages, `....//`, etc.).

Le fichier produit ne contient plus aucun secret — vérifié :

```
$ cat backup_admin
admin:1:10000          ← nom, flag admin, solde. Aucun mot de passe.
```

---

### ✦ Correction #7 — Suppression de la backdoor

**Fonction** : `change_password()` · **Ligne** : 227

#### 🔴 Vulnérabilité originale

Un mot de passe maître codé en dur permet de changer le mot de passe de **n'importe quel compte** sans connaître l'ancien.

```c
if (strcmp(users[user_id].password, old_pass) == 0 ||
    strcmp(old_pass, "master_reset_2024") == 0) {     // ← PORTE DÉROBÉE
```

#### 💥 Attaque possible

La chaîne est présente en clair dans le binaire et se découvre en une commande :

```bash
strings vulnerable | grep master
# master_reset_2024
```

N'importe qui peut alors s'approprier le compte `admin`.

**Impact** : ☑ élévation de privilèges · ☑ prise de contrôle totale des comptes

#### ✅ Correction implémentée

```c
if (!verifier_mdp(user_id, old_pass)) {
    printf("Ancien mot de passe incorrect\n");
    return;
}
```

**Modifications** :
1. Suppression pure et simple de la branche `master_reset_2024`.
2. Vérification exclusivement par recalcul de la dérivation PBKDF2 salée.
3. Ajout d'une confirmation du nouveau mot de passe.

#### 🛡️ Justification de sécurité

Seule la connaissance du **vrai** mot de passe, validée cryptographiquement, autorise la modification. Aucun secret universel ne subsiste dans le binaire.

```bash
printf '2\nadmin\nadmin123\n10\nmaster_reset_2024\nX\nX\n0\n' | ./secure
# → "Ancien mot de passe incorrect"
```

---

### ✦ Correction #8 — Contrôles métier des transferts

**Fonction** : `transfer_money()` · **Lignes** : 120-125

#### 🔴 Vulnérabilité originale

Le montant n'est jamais validé et le solde n'est jamais vérifié.

```c
scanf("%d", &amount);
users[from_user].balance -= amount;   // amount peut être négatif
users[i].balance         += amount;   // aucun contrôle de solde
```

#### 💥 Attaque possible

Un **montant négatif** inverse le sens du transfert :

```
Transfert de -1 000 000 vers "victime"
→ balance_attaquant -= (-1000000)  ⇒ +1 000 000
→ balance_victime   += (-1000000)  ⇒ -1 000 000
```

Sans contrôle de solde, on peut par ailleurs vider un compte au-delà du disponible.

**Impact** : ☑ vol de fonds · ☑ corruption de la logique métier

#### ✅ Correction implémentée

```c
if (amount <= 0) {
    printf("Le montant doit etre positif\n"); return;
}
if (dest == from_user) {
    printf("Transfert vers soi-meme impossible\n"); return;
}
if (users[from_user].balance < amount) {
    printf("Solde insuffisant\n"); return;
}
users[from_user].balance -= amount;
users[dest].balance      += amount;
```

#### 🛡️ Justification de sécurité

Les trois invariants métier — **montant strictement positif**, **solde suffisant**, **destinataire distinct** — sont vérifiés **avant** toute écriture. Le montant étant borné par le solde de l'émetteur, la somme totale du système est conservée et aucun dépassement d'entier n'est possible.

---

### ✦ Correction #9 — Robustesse des entrées numériques et division par zéro

**Fonctions** : `compute_stats()` (247), `main()` (320), toutes les lectures d'entiers

#### 🔴 Vulnérabilité originale

**(a)** `compute_stats()` divise par `user_count` sans vérifier qu'il est non nul :

```c
avg = (double)total / user_count;      // SIGFPE si user_count == 0
```

**(b)** `scanf("%d", &choice)` dans la boucle du menu : sur une saisie non numérique, `scanf` **ne consomme pas** l'entrée fautive, qui est relue indéfiniment → boucle infinie à 100 % de CPU.

#### 💥 Attaque possible

- Statistiques sur une base vide → crash immédiat (`SIGFPE`).
- Saisie `abc` ou fin d'entrée → le programme tourne sans fin.

**Impact** : ☑ déni de service (crash) · ☑ déni de service (boucle infinie)

#### ✅ Correction implémentée

```c
if (user_count == 0) { printf("Aucun utilisateur\n"); return; }
double avg = (double)total / user_count;
```

Lecture d'entier robuste, avec contrôle explicite des bornes :

```c
int lire_entier(int *resultat) {
    char ligne[32]; char *fin; long v;

    if (!lire_ligne(ligne, sizeof(ligne))) return 0;
    if (ligne[0] == '\0')                  return 0;

    errno = 0;
    v = strtol(ligne, &fin, 10);

    if (fin == ligne || *fin != '\0') return 0;  /* pas un nombre */
    if (errno == ERANGE)              return 0;  /* dépasse un long */
    if (v < INT_MIN || v > INT_MAX)   return 0;  /* ne tient pas dans un int */

    *resultat = (int)v;
    return 1;
}
```

Et la boucle du menu distingue « saisie invalide » de « fin d'entrée » :

```c
if (!lire_entier(&choice)) {
    if (feof(stdin)) { printf("\nAu revoir!\n"); break; }   /* fin propre */
    printf("Choix invalide\n");
    continue;
}
```

#### 🛡️ Justification de sécurité

Le contrôle `v < INT_MIN || v > INT_MAX` mérite une explication : sans lui, `strtol` renvoie un `long` (64 bits) tronqué à l'affectation dans un `int` (32 bits). **La validation porterait alors sur la valeur tronquée, et serait contournable** :

| Saisie | Sans contrôle | Conséquence |
| :--- | :--- | :--- |
| `4294967297` (2³²+1) | tronqué en **1** | passe la validation « admin ∈ {0,1} » |
| `4294967396` (2³²+100) | tronqué en **100** | transfert de 100 € au lieu du montant demandé |

C'est la règle **CERT INT31-C** (*ensure that integer conversions do not result in lost or misinterpreted data*). Le `feof()` garantit par ailleurs une terminaison propre en fin de flux, indispensable quand le programme est alimenté par un fichier de test.

---

### ✦ Correction #10 — Validation des entrées et durcissement du clonage

**Fonctions** : `register_user`, `transfer_money`, `clone_user`, `search_user`, `main` — lignes 61, 64, 67, 117, 192, 258, 329, 331

#### 🔴 Vulnérabilité originale

`scanf("%s", buf)` lit sans aucune borne jusqu'au premier espace : tous les tampons concernés peuvent déborder. Aucune contrainte n'existe non plus sur les caractères acceptés.

```c
scanf("%s", username);     // aucune borne, aucun filtre sur les caractères
```

#### 💥 Attaque possible

- Saisie très longue → débordement de pile (même mécanisme que `gets()`).
- Un nom contenant `:` casse le format du fichier de backup (`nom:admin:solde`) et permet d'y injecter de faux champs.

**Impact** : ☑ corruption mémoire · ☑ injection dans les données

#### ✅ Correction implémentée

Toutes les saisies passent par `lire_ligne()`, puis par une validation en liste blanche :

```c
int nom_valide(const char *nom) {
    int len = strlen(nom);
    if (len < 1 || len > 15) return 0;
    for (int i = 0; i < len; i++) {
        char c = nom[i];
        if (!isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.')
            return 0;
    }
    return 1;
}
```

Le même principe s'applique aux noms de fichiers (`fichier_valide()`, correction #6).

#### 🛡️ Justification de sécurité

La **liste blanche** garantit qu'aucun caractère inattendu ne circule : ni séparateur `:`, ni espace, ni caractère de contrôle. Une liste noire aurait été contournable (encodages, variantes). La longueur est bornée à 15, soit exactement la capacité du champ de destination — la validation et la taille du buffer sont donc cohérentes par construction.

```bash
printf '1\nev:il\nx\nx\n0\n0\n' | ./secure     # → "Nom invalide"
```

> ⏳ **Limite assumée.** `clone_user()` recopie toujours le solde de la source (L202), ce qui duplique de l'argent à chaque clonage. Trancher ce point demande de définir la sémantique attendue du clonage, ce qui relève de la spécification fonctionnelle plus que de la sécurisation. Voir **piste #6**, section 5.

---

## 3. TESTS DE VALIDATION

### 3.1 Compilation

```bash
gcc -o secure secure.c -lcrypto -Wall -Wextra -fstack-protector-all -D_FORTIFY_SOURCE=2
```

**Résultat** : aucune sortie.

| Mesure | Valeur |
| :--- | :---: |
| Warnings | **0** |
| Erreurs | **0** |
| Warnings avec `-Wpedantic` en plus | **0** |

La variante durcie compile également proprement :

```bash
gcc -Wall -Wextra -g -fstack-protector-all -D_FORTIFY_SOURCE=2 \
    -fPIE -pie -Wl,-z,relro,-z,now -o secure secure.c -lcrypto
```

### 3.2 Tests fonctionnels

| Fonctionnalité | Test effectué | Résultat |
| :--- | :--- | :---: |
| Création utilisateur | Nom de 500 caractères | ✅ Rejeté — *« Nom invalide »* |
| Création utilisateur | Nom contenant `:` | ✅ Rejeté |
| Création utilisateur | Nom déjà existant | ✅ Rejeté — *« Ce nom existe deja »* |
| Connexion | Identifiants corrects | ✅ Connexion réussie (SHA-256) |
| Connexion | Mauvais mot de passe | ✅ *« Echec de connexion »* |
| Transfert | Montant négatif | ✅ *« Le montant doit etre positif »* |
| Transfert | Montant supérieur au solde | ✅ *« Solde insuffisant »* |
| Transfert | Montant valide (100 → −40) | ✅ Solde mis à jour : 60 |
| Backup | Nom contenant `../` | ✅ *« Nom de fichier non autorise »* |
| Infos système | Menu 7 en tant que non-admin | ✅ *« Acces refuse »* |
| Statistiques | Exécution | ✅ Aucun crash |
| Clonage | Vérification du total | ⏳ Le solde est dupliqué — *piste #6* |
| Fin d'entrée | Flux terminé sans « 0 » | ✅ Sortie propre, pas de boucle |

### 3.3 Analyse mémoire (Valgrind)

```bash
valgrind --leak-check=full --show-leak-kinds=all --errors-for-leak-kinds=all ./secure
```

Scénario testé : initialisation admin → création de compte → clonage → changement de mot de passe → sortie.

```
==1662==     in use at exit: 0 bytes in 0 blocks
==1662== All heap blocks were freed -- no leaks are possible
==1662== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

| Mesure | Valeur |
| :--- | :---: |
| Fuites détectées | **0 octet** |
| Blocs non libérés | **0** |
| Erreurs mémoire | **0** |

Le second chemin de sortie (fin de flux / EOF) a été testé séparément : **également 0 fuite**. La fonction `liberer()` est appelée dans les deux cas — après le `return` du menu et après le `break` de la boucle.

### 3.4 Tests de sécurité

| # | Test | Entrée | Résultat obtenu | Statut |
| :-: | :--- | :--- | :--- | :-: |
| 1 | Buffer overflow | nom de 500 caractères | `Nom invalide` | ✅ |
| 2 | Format string | `%x %n %p` | `Note : %x %n %p` (littéral) | ✅ |
| 3 | Command injection | menu 7 | `=== INFOS SYSTEME ===` (aucun shell) | ✅ |
| 4 | Path traversal | `../../etc/passwd` | `Nom de fichier non autorise` | ✅ |
| 5 | Backdoor | `master_reset_2024` | `Ancien mot de passe incorrect` | ✅ |
| 6 | Troncature d'entier | `4294967297` en flag admin | `Valeur invalide` | ✅ |
| 7 | Troncature d'entier | `4294967396` en montant | `Montant invalide` | ✅ |
| 8 | Anti brute-force | 3 échecs puis bons identifiants | `Trop de tentatives. Acces bloque.` | ✅ |
| 9 | Déni de service | flux terminé (EOF) | sortie propre | ✅ |

**Bilan : 19 tests automatisés — 19 réussis, 0 échec.**

> Le test de création monétaire par clonage est volontairement conservé dans le tableau fonctionnel avec le statut ⏳ : il **échoue**, et c'est documenté. Le masquer aurait donné une image faussement complète des résultats.

### 3.5 Fuzzing

300 séquences d'entrées aléatoires (options de menu valides et invalides, chaînes longues, métacaractères, spécificateurs de format, chemins relatifs, entrées vides) :

| Mesure | Résultat |
| :--- | :---: |
| Crashes (signal) | **0** |
| Boucles infinies / timeouts | **0** |

---

### 3.6 Analyse dynamique instrumentée (AddressSanitizer + UndefinedBehaviorSanitizer)

Valgrind détecte les erreurs mémoire à l'exécution, mais **ASan** et **UBSan** instrumentent le binaire à la compilation et couvrent des classes d'erreurs supplémentaires : débordements de pile et de tableaux globaux, usage après libération, et surtout les **comportements indéfinis** (dépassements d'entiers signés, décalages invalides, déréférencements mal alignés).

**Compilation** :

```bash
gcc -fsanitize=address,undefined -fno-omit-frame-pointer -g \
    -Wall -Wextra -o secure_asan secure.c -lcrypto
```

**Validation préalable de l'instrumentation.** Un outil silencieux peut être un outil inactif. J'ai donc vérifié qu'ASan détecte bien un bug volontaire avant de conclure quoi que ce soit sur `secure.c` :

```c
/* canari : debordement et fuite volontaires */
char *p = malloc(8);
strcpy(p, "AAAAAAAAAAAAAAAA");
```

```
SUMMARY: AddressSanitizer: heap-buffer-overflow ... in memcpy
```

L'instrumentation est donc bien active : le silence obtenu sur `secure.c` a une valeur probante.

**Résultats sur `secure.c`** :

| Scénario | Erreurs ASan/UBSan |
| :--- | :---: |
| Parcours fonctionnel complet (création, connexion, transfert, backup, restauration, clonage, changement de mot de passe) | **0** |
| Nom d'utilisateur de 5 000 octets | **0** |
| Chaîne de format massive `%x%x%x%x%n%s%p` | **0** |
| Path traversal `../../../../etc/passwd` | **0** |
| Entiers `99999999999999999999` et son opposé | **0** |
| Choix de menu `4294967296` (2³²) | **0** |
| Montant `INT_MAX` | **0** |
| Clonages successifs | **0** |
| Recherche vide, EOF brutal | **0** |
| **Fuzzing : 60 séquences aléatoires instrumentées** | **0** |

**Bilan : 0 erreur mémoire, 0 comportement indéfini, 0 fuite** sur l'ensemble des scénarios instrumentés.

---

### 3.7 Analyse statique (`cppcheck` et `clang --analyze`)

L'analyse statique examine le code **sans l'exécuter** et repère des défauts qu'aucun test ne déclencherait forcément. Pour que le résultat soit interprétable, j'ai systématiquement comparé `secure.c` à `vulnerable.c` : un « 0 » n'a de sens que si l'outil trouve effectivement quelque chose sur du code fautif.

#### cppcheck

```bash
cppcheck --enable=all --inconclusive --std=c99 --force \
         --suppress=missingIncludeSystem secure.c
```

| Fichier | Problèmes détectés |
| :--- | :---: |
| `vulnerable.c` *(témoin)* | **20** |
| `secure.c` | **0** |

Extrait du rapport sur `vulnerable.c` :

```
vulnerable.c:105:5: warning: Obsolete function 'gets' called. [getsCalled]
vulnerable.c:181:5: warning: Obsolete function 'gets' called. [getsCalled]
vulnerable.c:224:5: warning: Obsolete function 'gets' called. [getsCalled]
vulnerable.c:229:9: warning: Obsolete function 'gets' called. [getsCalled]
vulnerable.c:61:5:  warning: scanf() without field width limits can crash
                             with huge input data. [invalidscanf]
... (8 occurrences de invalidscanf au total)
```

#### clang --analyze

| Fichier | Warnings |
| :--- | :---: |
| `vulnerable.c` *(témoin, en `-std=gnu89`)* | **10** — 4 × `security.insecureAPI.gets`, 6 × `security.insecureAPI.strcpy` |
| `secure.c` | **0** |

Deux observations méritent d'être signalées :

**1. `vulnerable.c` ne compile même pas sous un standard C moderne.** Clang refuse d'abord de l'analyser :

```
vulnerable.c:105:5: error: call to undeclared function 'gets';
                    ISO C99 and later do not support implicit function declarations
```

`gets()` a été **retirée de la norme C11**. Il a fallu forcer `-std=gnu89` pour obtenir l'analyse — ce qui est en soi un constat sur l'obsolescence du code d'origine.

**2. Faux positifs assumés sur `secure.c`.** Avec la configuration par défaut, clang remonte 11 warnings sur `secure.c`, **tous** issus d'un unique checker :

```
[security.insecureAPI.DeprecatedOrUnsafeBufferHandling] × 11
```

Ce checker exige les fonctions de l'**Annexe K de C11** (`snprintf_s`, `sscanf_s`). Or cette annexe est **optionnelle** dans la norme et **n'est pas implémentée par la glibc** :

```bash
$ grep snprintf_s /usr/include/stdio.h
(aucun résultat)
```

Le conseil est donc littéralement inapplicable sous Linux. J'ai désactivé ce seul checker, en le documentant plutôt qu'en le masquant silencieusement :

```bash
clang --analyze \
  -Xclang -analyzer-checker=core,deadcode,unix,security.insecureAPI.UncheckedReturn \
  -Xclang -analyzer-disable-checker=security.insecureAPI.DeprecatedOrUnsafeBufferHandling \
  secure.c
# → 0 warning
```

#### Reproductibilité

Toute la chaîne d'audit est intégrée au `Makefile` :

```bash
make cppcheck        # analyse statique cppcheck
make clang-analyze   # analyse statique clang
make asan-run        # exécution sous ASan + UBSan
make valgrind        # analyse mémoire
make audit           # enchaîne les quatre
```

---

## 4. CONCLUSION

### 4.1 Résumé des corrections

| Gravité | Identifiées | Corrigées | Reportées | Couverture |
| :--- | :---: | :---: | :---: | :---: |
| 🔴 Critique | 12 | **12** | 0 | **100 %** |
| 🟠 Haute | 8 | **6** | 2 | 75 % |
| 🟡 Moyenne | 13 | **9** | 4 | 69 % |
| 🟢 Faible | 3 | **1** | 2 | 33 % |
| **TOTAL** | **36** | **24** | **12** | **67 %** |

Volume : `vulnerable.c` fait 402 lignes, `secure.c` en fait 725 — l'essentiel de l'augmentation vient des fonctions de validation et de la couche cryptographique.

**Le choix assumé de ne pas tout corriger.** Une couverture de 100 % aurait été possible sur le papier, en ajoutant des correctifs superficiels aux 12 faiblesses restantes. J'ai préféré :

- **traiter intégralement les 12 vulnérabilités Critiques**, c'est-à-dire toutes celles qu'une saisie malveillante suffit à exploiter ;
- **documenter précisément les 12 autres** en section 5, avec leur risque, la correction envisagée et sa difficulté.

Ce choix repose sur une conviction : une faiblesse connue, mesurée et tracée est moins dangereuse qu'une faiblesse masquée par un correctif approximatif. Les pistes reportées relèvent presque toutes de la **conception** (modèle d'autorisation, gestion de sessions, politique cryptographique) et non du défaut de programmation — les corriger correctement suppose des décisions d'architecture, parfois de spécification, qui dépassent le cadre d'une séance de sécurisation.

**Principaux changements** :

1. **Élimination totale des fonctions dangereuses** — `gets`, `scanf("%s")`, `strcpy`, `strcat`, `sprintf`, `system` : 0 occurrence dans le code (vérifié par analyse du source dépouillé de ses commentaires et chaînes littérales).
2. **Refonte de l'authentification** — SHA-256 salé (sel aléatoire de 128 bits) via l'API OpenSSL EVP, aucun mot de passe en clair en mémoire ni sur disque, backdoor supprimée.
3. **Validation systématique des entrées** — noms, montants, fichiers ; contrôle des bornes d'entiers ; robustesse à l'EOF ; gestion mémoire complète sans fuite.
4. **Validation outillée** — au-delà des tests manuels, le code est passé sous AddressSanitizer, UndefinedBehaviorSanitizer, `cppcheck` et l'analyseur statique de clang, avec comparaison systématique à `vulnerable.c` comme témoin.

### 4.2 Difficultés rencontrées

**Problème 1 — API OpenSSL dépréciée**
`SHA256_Init` / `SHA256_Update` / `SHA256_Final`, suggérées par la documentation classique, sont dépréciées depuis OpenSSL 3.0 et déclenchent des warnings sous `-Wall -Wextra`, ce qui contredisait l'objectif « 0 warning ».
→ *Résolu* en passant à l'API `EVP_*` (contexte `EVP_MD_CTX`, `EVP_sha256()`), qui est la voie recommandée.

**Problème 2 — Warning `-Wrestrict` sur `snprintf`**
Copier un champ de `users[]` vers un autre champ de `users[]` avec `snprintf` déclenche `argument overlaps destination object` : le compilateur considère les deux comme un même objet.
→ *Résolu* avec `memcpy` entre deux champs de taille fixe identique.

**Problème 3 — Boucle infinie en fin de flux**
Découvert **en testant avec un fichier redirigé** : une fois l'entrée épuisée, `lire_entier()` renvoyait 0 et le menu affichait « Choix invalide » indéfiniment (plusieurs millions d'itérations avant l'interruption manuelle). C'est un déni de service.
→ *Résolu* par un test `feof(stdin)` qui termine proprement le programme.

**Problème 4 — Troncature d'entier découverte tardivement**
En relisant `lire_entier()`, j'ai constaté que `strtol` renvoie un `long` affecté à un `int` sans contrôle de bornes. La saisie `4294967297` devenait `1` et **contournait la validation** du flag admin ; `4294967396` devenait `100` et faisait exécuter un transfert d'un montant différent de celui demandé.
→ *Résolu* par un contrôle `errno == ERANGE` et une comparaison explicite à `INT_MIN` / `INT_MAX` (règle CERT INT31-C).

### 4.3 Limites connues

Les faiblesses résiduelles ne sont pas listées ici mais traitées en détail dans la [section 5 — Pistes à explorer](#5-pistes-à-explorer), avec pour chacune le risque réel, la correction envisagée et sa difficulté.

En résumé, `secure.c` **ne doit pas être considéré comme un programme sûr en production**. Il est débarrassé de toutes ses failles directement exploitables, mais il conserve quatre faiblesses structurelles qu'il faut avoir en tête :

| Faiblesse résiduelle | Conséquence concrète |
| :--- | :--- |
| Auto-attribution du flag admin *(piste #4)* | N'importe qui peut créer un compte administrateur |
| Hachage rapide sans KDF *(piste #1)* | Une base volée reste attaquable par force brute |
| Aucune session réelle *(piste #5)* | La « connexion » n'est qu'une variable locale |
| Clonage dupliquant le solde *(piste #6)* | L'invariant monétaire n'est pas garanti |

### 4.4 Apprentissages clés

1. **Un petit ensemble de fonctions concentre la majorité des failles C.** Proscrire `gets`, `scanf("%s")`, `strcpy` et `sprintf` élimine d'un coup des classes entières de vulnérabilités.
2. **Une donnée utilisateur ne doit jamais atteindre un interpréteur** sans neutralisation — que ce soit le format de `printf`, le shell de `system` ou le résolveur de chemins de `fopen`.
3. **La sécurité cryptographique tient autant à l'implémentation qu'à l'algorithme.** SHA-256 sans sel, ou avec le mot de passe stocké à côté, n'apporte rien.
4. **Un programme sécurisé doit aussi être robuste.** Mes deux bugs les plus intéressants (boucle infinie sur EOF, troncature d'entier) n'étaient pas des débordements mais des défauts de robustesse — et tous deux étaient exploitables en déni de service ou en contournement de validation.
5. **Tester vaut mieux que relire.** Ces deux bugs sont apparus au test, pas à la relecture.
6. **Un résultat d'outil ne vaut que si l'outil est validé.** Un « 0 problème » peut signifier « code sain » comme « outil mal configuré ». Comparer systématiquement à un témoin fautif (`vulnerable.c`, canari ASan) est ce qui rend le résultat interprétable.
7. **Tous les avertissements ne se valent pas.** Les 11 warnings de clang venaient d'un checker exigeant une annexe optionnelle absente de la glibc : les écarter demandait de comprendre la norme, pas de désactiver au hasard.
8. **Prioriser fait partie du travail de sécurité.** Devant 36 vulnérabilités et 4 heures, l'exercice n'était pas de tout corriger mais de décider *quoi* corriger. Distinguer ce qui est exploitable par une simple saisie de ce qui relève d'un défaut d'architecture m'a paru plus formateur que d'appliquer 36 correctifs mécaniques.
9. **Une faiblesse assumée vaut mieux qu'une faiblesse masquée.** Ajouter du chiffrement sans savoir où stocker la clé (piste #9), ou trancher la sémantique du clonage sans spécification (piste #6), aurait donné l'illusion d'une protection. Documenter le problème est parfois la réponse la plus honnête.

**Compétences développées** :

- [x] Identification de vulnérabilités
- [x] Utilisation de fonctions sécurisées
- [x] Validation d'entrées
- [x] Gestion mémoire rigoureuse
- [x] Cryptographie appliquée

### 4.5 Auto-évaluation

| Critère | Note estimée | Justification |
| :--- | :---: | :--- |
| Analyse | ____ / 6 | Audit ligne par ligne des 402 lignes, 36 vulnérabilités documentées avec numéros de ligne, y compris les portions saines |
| Corrections | ____ / 10 | 100 % des failles Critiques corrigées, 0 warning (`-Wpedantic` inclus), SHA-256 salé, 0 fuite Valgrind, 0 erreur ASan/UBSan, 0 problème d'analyse statique, 19/19 tests |
| Documentation | ____ / 4 | 10 corrections détaillées en 4 sections, tests reproductibles, 12 pistes documentées avec risque et difficulté |
| **TOTAL** | **____ / 20** | |

> *Note laissée à l'appréciation du correcteur.*

---

## 5. PISTES À EXPLORER

Les 12 vulnérabilités ci-dessous ont été **identifiées mais volontairement non corrigées**. Ce ne sont pas des oublis : ce sont des faiblesses dont la correction correcte suppose de modifier l'architecture du programme, et non d'appliquer un correctif ponctuel. Les traiter à la hâte aurait produit une sécurité de façade — plus dangereuse qu'une faiblesse assumée, parce qu'elle donne l'illusion d'être protégé.

Chaque piste indique le **risque réel**, la **correction envisagée** et une **difficulté estimée**.

---

### Piste #1 — Utiliser une fonction de dérivation de clé (KDF)

| | |
| :--- | :--- |
| **Vulnérabilité** | #26 — hachage rapide (SHA-256) pour stocker des mots de passe |
| **Gravité** | 🟠 Haute |
| **Difficulté** | ⭐⭐ Faible à modérée |

**Risque réel.** SHA-256 est conçu pour être *rapide*, ce qui est exactement l'inverse du besoin ici. Un attaquant qui obtiendrait la base peut tester des milliards de candidats par seconde sur GPU. Le salage empêche les tables précalculées, mais pas l'attaque par force brute sur un mot de passe faible.

**Correction envisagée.** Remplacer `calculer_hash()` par `PKCS5_PBKDF2_HMAC()` (disponible nativement dans OpenSSL), avec 600 000 itérations — recommandation OWASP 2023 pour PBKDF2-HMAC-SHA256 :

```c
PKCS5_PBKDF2_HMAC(mdp, strlen(mdp), sel, TAILLE_SEL,
                  600000, EVP_sha256(), TAILLE_CLE, cle);
```

L'ordre de grandeur du gain est le suivant :

| | Coût par essai | Essais/seconde (GPU) |
| :--- | :--- | :--- |
| SHA-256 simple | ~0,000001 s | ~10⁹ |
| PBKDF2, 600 000 itérations | ~0,15 s | ~10³ |

**Pourquoi reporté.** Le changement en lui-même est court, mais il impose de stocker le **paramètre de coût à côté de chaque empreinte** pour pouvoir l'augmenter dans le temps sans invalider les comptes existants — donc de faire évoluer le format de stockage. `Argon2id` serait encore préférable (résistance au calcul parallèle et coût mémoire), mais nécessite une dépendance hors OpenSSL.

---

### Piste #2 — Comparaison d'empreintes à temps constant

| | |
| :--- | :--- |
| **Vulnérabilité** | #27 — `strcmp` sur les empreintes |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐ Faible |

**Risque réel.** `strcmp` s'arrête à la première différence. Le temps de réponse révèle donc combien de caractères initiaux de l'empreinte sont corrects, ce qui permet théoriquement de la reconstituer octet par octet. En pratique, l'attaque est difficile ici (bruit de mesure, empreinte non contrôlée par l'attaquant), mais la faiblesse est réelle et le correctif trivial.

**Correction envisagée.**

```c
return CRYPTO_memcmp(hash_candidat, users[i].hash, TAILLE_HASH - 1) == 0;
```

`CRYPTO_memcmp` compare **toujours** la totalité des octets, quel que soit le résultat.

**Pourquoi reporté.** Correction très simple, mais son intérêt réel dépend du modèle de menace : elle n'a de sens que couplée à la piste #1 et à une gestion de sessions digne de ce nom. Je préférais la présenter dans un ensemble cohérent plutôt que l'ajouter isolément.

---

### Piste #3 — Effacer les secrets de la mémoire

| | |
| :--- | :--- |
| **Vulnérabilité** | #28 — mots de passe et empreintes laissés en mémoire |
| **Gravité** | 🟢 Faible |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Les mots de passe saisis restent dans les tampons de la pile après usage. Un vidage mémoire (*core dump*), une hibernation ou une lecture de la mémoire du processus peut les révéler.

**Correction envisagée.** Appeler `OPENSSL_cleanse()` sur chaque tampon sensible dès qu'il n'est plus utile. Contrairement à `memset`, cette fonction n'est pas supprimée par l'optimiseur du compilateur.

**Pourquoi reporté.** Le faire *correctement* suppose de recenser tous les chemins où un secret transite (saisie, confirmation, comparaison, sortie d'erreur anticipée) et de garantir l'effacement même en cas de `return` prématuré. C'est un travail de revue systématique, pas un ajout ponctuel.

---

### Piste #4 — Modèle d'autorisation : supprimer l'auto-attribution du flag admin

| | |
| :--- | :--- |
| **Vulnérabilité** | #29 — `register_user()` L74 : l'utilisateur choisit lui-même `admin_flag` |
| **Gravité** | 🟠 Haute |
| **Difficulté** | ⭐⭐⭐ Élevée |

**Risque réel.** N'importe qui peut créer un compte administrateur en répondant `1` à la question « Droits admin ». J'ai bien validé que la valeur soit `0` ou `1` (correction #9, avec le contrôle de troncature d'entier), mais **la question elle-même ne devrait pas être posée à l'utilisateur**. Le contrôle d'accès du menu 7 devient de fait décoratif.

**Correction envisagée.** Retirer purement et simplement la saisie du flag ; tout nouveau compte est créé non privilégié. L'élévation ne pourrait se faire que par une action d'un administrateur déjà authentifié :

```c
users[i].admin_flag = 0;    /* jamais choisi par l'utilisateur */
```
puis une fonction `promouvoir_utilisateur()` réservée aux administrateurs.

**Pourquoi reporté.** C'est la piste la plus structurante. Elle suppose d'introduire une véritable notion de rôle, une opération de promotion, et de revoir tous les points du menu qui testent `admin_flag`. Elle modifie aussi le comportement fonctionnel attendu du programme d'origine — un choix qui mériterait d'être validé avec l'encadrant plutôt que décidé unilatéralement.

---

### Piste #5 — Tokens imprévisibles et gestion réelle des sessions

| | |
| :--- | :--- |
| **Vulnérabilités** | #30 (token prévisible) et #31 (sessions inexploitées) |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐⭐⭐ Élevée |

**Risque réel.** Le token vaut `TOK_<index>_<nom>` : il est entièrement **déductible** de données publiques (le menu 9 affiche l'index et le nom de chaque utilisateur). Si ce token servait un jour à authentifier une requête, n'importe qui pourrait le forger. Par ailleurs, la structure `Session` et la fonction `cleanup_sessions()` existent dans le code d'origine mais ne sont **jamais utilisées** : `session_count` reste à 0, aucune session n'est créée ni expirée. La « connexion » se résume à une variable locale `logged_user`.

**Correction envisagée.**

```c
unsigned char brut[24];
RAND_bytes(brut, sizeof(brut));      /* token cryptographiquement aleatoire */
vers_hex(brut, sizeof(brut), users[i].token);
```

et une véritable table de sessions : création à la connexion avec horodatage, vérification d'expiration à chaque opération sensible, invalidation à la déconnexion.

**Pourquoi reporté.** Implémenter des sessions crédibles revient à réécrire la boucle principale et tous les contrôles d'accès. C'est un projet en soi, largement au-delà du périmètre d'une séance de sécurisation.

---

### Piste #6 — Sémantique du clonage et invariant monétaire

| | |
| :--- | :--- |
| **Vulnérabilité** | #33 — `clone_user()` L202 recopie le solde |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐ Faible techniquement, ⭐⭐⭐ en spécification |

**Risque réel.** Dans une application bancaire, la somme des soldes doit être un **invariant** : l'argent se déplace, il ne se crée pas. Or chaque clonage duplique le solde de la source. Mesuré :

```
avant clonage de « admin » : Total: 10 000 €
après clonage              : Total: 20 000 €     ← 10 000 € créés
```

En répétant l'opération jusqu'à `MAX_USERS`, on fabrique environ 190 000 €.

**Correction envisagée.** Techniquement immédiat — `users[i].balance = 0;` — mais le vrai problème est ailleurs.

**Pourquoi reporté.** Ni l'énoncé ni le code d'origine ne précisent ce que « cloner un utilisateur » est censé signifier. S'agit-il de dupliquer un profil de test ? De créer un compte joint ? Selon la réponse, le solde doit valoir 0, être transféré, ou être partagé. Choisir arbitrairement aurait masqué une **ambiguïté de spécification** derrière une ligne de code. Je préfère la signaler explicitement.

---

### Piste #7 — Verrouillage anti-brute-force par compte, avec expiration

| | |
| :--- | :--- |
| **Vulnérabilité** | #32 — verrouillage global et définitif |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Le compteur `essais` implémenté est **global** et **définitif** : trois échecs sur n'importe quel compte bloquent *toutes* les connexions jusqu'au redémarrage, y compris avec les bons identifiants. C'est un déni de service qu'un attaquant peut déclencher volontairement en trois tentatives, et une gêne majeure pour l'utilisateur légitime.

**Correction envisagée.** Un compteur **par compte**, assorti d'un déverrouillage temporel :

```c
typedef struct {
    int    echecs;
    time_t verrouille_jusqu_a;
} EtatAuth;
```

avec un délai croissant (temporisation exponentielle) plutôt qu'un blocage définitif.

**Pourquoi reporté.** L'implémentation demande de gérer un état par compte persistant à travers les tentatives, et de choisir une politique (seuil, durée, progression) qui relève autant de l'ergonomie que de la sécurité. La version actuelle est volontairement rudimentaire et signalée comme telle.

---

### Piste #8 — Politique de complexité des mots de passe

| | |
| :--- | :--- |
| **Vulnérabilité** | #34 — aucune contrainte sur les mots de passe |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Le programme accepte un mot de passe d'un seul caractère. Toute la protection cryptographique (sel, hachage) devient inopérante face à un mot de passe trivial : `a` sera trouvé instantanément quelle que soit la KDF employée.

**Correction envisagée.** Imposer une longueur minimale (12 caractères selon les recommandations de l'ANSSI), et surtout **vérifier le mot de passe contre une liste des plus courants** — approche recommandée par le NIST SP 800-63B, plus efficace que les règles de composition classiques (majuscule + chiffre + symbole), qui poussent surtout à des variantes prévisibles du type `Password1!`.

**Pourquoi reporté.** Faire les choses correctement suppose d'embarquer et d'interroger une liste de mots de passe compromis, donc de gérer un fichier de données supplémentaire. Une simple règle de longueur aurait été cosmétique.

---

### Piste #9 — Chiffrement des fichiers de sauvegarde

| | |
| :--- | :--- |
| **Vulnérabilité** | #35 — backup en clair |
| **Gravité** | 🟡 Moyenne |
| **Difficulté** | ⭐⭐⭐ Élevée |

**Risque réel.** J'ai supprimé le mot de passe du fichier de sauvegarde (correction #6), qui ne contient donc plus de secret d'authentification. Il expose néanmoins des données personnelles : identité, statut administrateur, solde. Le fichier est lisible par tout utilisateur du système.

**Correction envisagée.** Chiffrer le contenu avec `EVP_EncryptInit_ex()` en AES-256-GCM, ce qui apporterait en prime un contrôle d'intégrité (détection de modification du fichier).

**Pourquoi reporté.** Le chiffrement n'est pas le point dur — la **gestion de la clé** l'est. La stocker dans le binaire ne protégerait de rien ; la dériver d'un mot de passe utilisateur impose de le redemander à chaque sauvegarde et restauration. Sans réponse claire à cette question, ajouter du chiffrement relèverait du théâtre de sécurité.

---

### Piste #10 — Journal d'audit persistant

| | |
| :--- | :--- |
| **Vulnérabilité** | #36 — aucune traçabilité |
| **Gravité** | 🟢 Faible |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Aucune trace n'est conservée : ni des connexions échouées, ni des transferts, ni des créations de comptes administrateurs. Une intrusion serait indétectable *a posteriori*, et aucune investigation ne serait possible.

**Correction envisagée.** Un fichier de journal horodaté, en ajout seul, consignant les événements sensibles (connexion réussie ou échouée, transfert, changement de mot de passe, création de compte privilégié) — sans jamais y écrire de secret.

**Pourquoi reporté.** Un journal utile suppose de traiter la rotation des fichiers, les droits d'accès en écriture, et surtout de garantir qu'aucune donnée sensible n'y fuit. Un journal mal conçu devient lui-même une source de fuite.

---

### Piste #11 — Limitation de débit applicative

| | |
| :--- | :--- |
| **Vulnérabilité** | #36 — aucune limite sur les opérations |
| **Gravité** | 🟢 Faible |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Rien ne limite la cadence des opérations : création de comptes jusqu'à saturation de `MAX_USERS`, transferts en boucle, tentatives de connexion. Un script peut épuiser les ressources en quelques millisecondes.

**Correction envisagée.** Une temporisation minimale entre opérations sensibles et un quota par utilisateur. Sur un service réseau, cette responsabilité incomberait plutôt à une couche en amont (pare-feu applicatif, proxy inverse).

**Pourquoi reporté.** Sur un programme en ligne de commande mono-utilisateur, la mesure a peu de sens : l'utilisateur dispose déjà d'un accès local complet. La piste n'a d'intérêt que si le programme évolue vers un service réseau.

---

### Piste #12 — Séparation du modèle de données et de la présentation

| | |
| :--- | :--- |
| **Vulnérabilité** | Transverse — dérive du format de sauvegarde |
| **Gravité** | 🟢 Faible |
| **Difficulté** | ⭐⭐ Modérée |

**Risque réel.** Le format de sauvegarde repose sur un séparateur `:` sans échappement. Je m'en protège aujourd'hui en **interdisant le `:` dans les noms d'utilisateur** (correction #10) — mais c'est un couplage fragile : si quelqu'un assouplit un jour `nom_valide()` sans penser au format de sauvegarde, l'injection de champs redevient possible.

**Correction envisagée.** Un format sérialisé robuste avec échappement explicite (ou un format structuré type JSON), afin que la validation des noms et le format de stockage cessent de dépendre l'un de l'autre.

**Pourquoi reporté.** La protection actuelle est efficace et testée. La refonte du format relève de la dette technique plutôt que d'une faille exploitable en l'état — mais elle méritait d'être signalée, car c'est typiquement le genre de couplage implicite qui réintroduit une faille des mois plus tard.

---

### Synthèse des pistes

| Piste | Vulnérabilité | Gravité | Difficulté | Priorité recommandée |
| :--- | :--- | :---: | :---: | :--- |
| #4 | Auto-attribution du flag admin | 🟠 Haute | ⭐⭐⭐ | **1 — à traiter en premier** |
| #1 | Absence de KDF | 🟠 Haute | ⭐⭐ | **2 — meilleur rapport gain/effort** |
| #8 | Politique de mot de passe | 🟡 Moyenne | ⭐⭐ | 3 |
| #7 | Verrouillage par compte | 🟡 Moyenne | ⭐⭐ | 4 |
| #5 | Tokens et sessions | 🟡 Moyenne | ⭐⭐⭐ | 5 |
| #6 | Sémantique du clonage | 🟡 Moyenne | ⭐ | 6 — *à clarifier avec l'encadrant* |
| #2 | Comparaison à temps constant | 🟡 Moyenne | ⭐ | 7 |
| #9 | Chiffrement des sauvegardes | 🟡 Moyenne | ⭐⭐⭐ | 8 |
| #3 | Effacement mémoire | 🟢 Faible | ⭐⭐ | 9 |
| #10 | Journal d'audit | 🟢 Faible | ⭐⭐ | 10 |
| #12 | Format de sérialisation | 🟢 Faible | ⭐⭐ | 11 |
| #11 | Limitation de débit | 🟢 Faible | ⭐⭐ | 12 |

Si je devais poursuivre ce travail, je commencerais par les pistes **#4** et **#1** : la première neutralise la dernière voie d'élévation de privilèges encore ouverte, la seconde offre le meilleur gain de sécurité pour un effort limité.

---

## 6. ANNEXES

### Annexe A — Checklist de vérification finale

| Vérification | Statut |
| :--- | :---: |
| Tous les `gets()` remplacés par `fgets()` | ✅ |
| Tous les `scanf("%s")` remplacés par une lecture bornée | ✅ |
| Tous les `strcpy()` remplacés par `snprintf()` / `memcpy` borné | ✅ |
| Aucun `strcat()` | ✅ |
| Tous les `sprintf()` remplacés par `snprintf()` | ✅ |
| Aucun appel à `system()` | ✅ |
| Cryptographie SHA-256 (OpenSSL EVP) | ✅ |
| Sel aléatoire de 128 bits par utilisateur | ✅ |
| Dérivation de clé (PBKDF2 / Argon2id) | ⏳ *piste #1* |
| Comparaison d'empreintes à temps constant | ⏳ *piste #2* |
| Effacement des secrets en mémoire | ⏳ *piste #3* |
| Aucun mot de passe en clair (mémoire et disque) | ✅ |
| Aucune backdoor | ✅ |
| Indices de tableaux validés | ✅ |
| Retours de `malloc()` vérifiés | ✅ |
| Mémoire libérée (`liberer()`) sur tous les chemins de sortie | ✅ |
| 0 fuite mémoire (Valgrind) | ✅ |
| 0 warning de compilation | ✅ |
| 0 erreur ASan / UBSan | ✅ |
| 0 problème `cppcheck` et `clang --analyze` | ✅ |
| Validation stricte des noms de fichiers | ✅ |
| Protection contre l'injection de commande | ✅ |
| Bornes des conversions d'entiers vérifiées | ✅ |
| Robustesse à l'EOF (pas de boucle infinie) | ✅ |

### Annexe B — Commandes de compilation et de test

```bash
# Compilation sécurisée
make secure

# Compilation durcie (PIE + RELRO complet)
make secure-hardened

# Analyse mémoire
make valgrind

# Vérification des dépendances (GCC, Valgrind, OpenSSL)
make check-deps

# Analyse statique
make cppcheck
make clang-analyze

# Rejoue le scénario de tests
make test-inputs

# Analyse dynamique instrumentée (ASan + UBSan)
make asan-run

# Chaîne d'audit complète (compilation + statique + sanitizers + Valgrind)
make audit
```

### Annexe C — Scénario de test (`test_inputs.txt`)

Le fichier `test_inputs.txt` fourni avec le rendu contient **mon** scénario de test, réécrit pour `secure.c`. Le fichier d'exemple initial avait été conçu pour `vulnerable.c` et se désynchronisait : `change_password()` réclame désormais une **confirmation** du nouveau mot de passe, si bien que la ligne suivante était consommée comme confirmation et le reste du scénario décalé.

Il se rejoue en une commande :

```bash
make test-inputs        # ou : ./secure < test_inputs.txt
```

Le scénario enchaîne 25 étapes couvrant chaque correctif, en alternant cas malveillants et cas nominaux :

| Étapes | Ce qui est testé | Résultat attendu |
| :--- | :--- | :--- |
| 1-2 | Nom de 64 caractères, puis nom contenant `:` | `Nom invalide` ×2 |
| 3 | Création valide de `alice` | `Utilisateur enregistre` |
| 4 | Création en doublon | `Ce nom existe deja` |
| 5 | Flag admin à `4294967297` (troncature d'entier) | `Valeur invalide` |
| 6 | Création valide de `bob` | `Utilisateur enregistre` |
| 7-8 | Mauvais mot de passe, puis bon mot de passe | `Echec`, puis `Connecte en tant que alice` |
| 9 | Note contenant `%s %x %p %n` | Affichage **littéral** |
| 10-12 | Transfert négatif, supérieur au solde, puis valide | `positif`, `Solde insuffisant`, `Transfert effectue` |
| 13-14 | Backup vers `../../etc/passwd`, puis nom valide | `non autorise`, puis `Backup cree` |
| 15-16 | Restauration de `../../../etc/shadow`, puis nom valide | `non autorise`, puis lecture du fichier |
| 17 | Menu 7 (audit) avec un compte non administrateur | `Acces refuse` |
| 18-19 | Clonage, puis liste des utilisateurs | `Clone cree` |
| 20 | Changement de mot de passe via `master_reset_2024` | `Ancien mot de passe incorrect` |
| 21 | Changement de mot de passe légitime | `Mot de passe change` |
| 22-23 | Statistiques, puis recherche | `Total:`, 2 résultats |
| 24-25 | Choix de menu `abc`, puis `4294967296` | `Choix invalide` ×2 |

**Vérification automatisée.** Le nombre d'occurrences de chaque message a été comparé à la valeur attendue : **19 contrôles sur 19 concordent**, et le programme se termine proprement sur `Au revoir!` — preuve que le scénario reste synchronisé de bout en bout, sans décalage des saisies.

---

### Annexe D — Références utilisées

1. **OWASP Top 10** — catégories *Injection* et *Cryptographic Failures*.
2. **SEI CERT C Coding Standard** — règles `STR31-C` (bornes des copies de chaînes), `FIO30-C` (format strings), `INT31-C` (conversions d'entiers), `MEM31-C` (libération mémoire).
3. **Documentation OpenSSL 3.x** — `EVP_DigestInit_ex`, `EVP_DigestUpdate`, `EVP_DigestFinal_ex`, `RAND_bytes`.
4. **NIST SP 800-132** — *Recommendation for Password-Based Key Derivation* (PBKDF2).
5. **OWASP Password Storage Cheat Sheet** (2023) — 600 000 itérations pour PBKDF2-HMAC-SHA256.
6. **Documentation des outils** — AddressSanitizer / UndefinedBehaviorSanitizer (Clang/GCC), `cppcheck`, Clang Static Analyzer.
7. **Pages de manuel** — `man fgets`, `man snprintf`, `man strtol`, `man 3 system`.

---

<div align="center">

**FIN DU RAPPORT**

*FATHI Naim — 30/07/2026*

</div>
