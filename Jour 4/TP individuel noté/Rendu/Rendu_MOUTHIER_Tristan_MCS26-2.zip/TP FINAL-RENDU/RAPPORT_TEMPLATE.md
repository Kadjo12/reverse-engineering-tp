# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : MOUTHIER Tristan
**Date** : 30/07/2026
**Durée** : 4 heures

---

## TABLE DES MATIÈRES
1. [Synthèse des vulnérabilités](#synthèse)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS <a name="synthèse"></a>

### Tableau récapitulatif

Type : Buffer overflow
╔════════════════════════════════════════════════════════════════════════════════════════════════════════╗
| #  | Ligne      | Problème                                                                  | Gravité  |
|----|------------|---------------------------------------------------------------------------|----------|
| 1  | 61, 64, 67 | `scanf("%s", ...)` dans `username[100]`, pas de borne                     | Critique |
| 2  |    72-73   | `strcpy` de `[100]` → `username[16]` / `password[16]`                     | Critique |
| 3  |     78     | `sprintf(token, "TOK_%d_%s", ...)` → `malloc(32)` avec un username de 100 | Critique |
| 4  |     105    | `gets(format)` dans `format[80]`                                          | Critique |
| 5  |     117    | `scanf("%s")` dans `to_username[50]`                                      | Haute    |
| 6  |     139    | `scanf("%s")` dans `filename[100]`                                        | Haute    |
| 7  |     160    | `scanf("%s")` dans `filename[200]`                                        | Haute    |
| 8  |     181    | `gets(cmd)` dans `cmd[150]`                                               | Critique |
| 9  |     183    | `sprintf(full_cmd, "echo '…' && %s", cmd)` — 150 + 22 > `full_cmd[200]`   | Critique |
| 10 |  192, 199  | `scanf("%s")` dans `[30]` puis `strcpy` → `username[16]`                  | Critique | 
| 11 |  224, 229  | `gets(old_pass)` / `gets(new_pass)` dans `[80]`                           | Critique |
| 12 |    230     | `strcpy(users[id].password, new_pass)` — 80 → 16                          | Critique | 
| 13 |  329, 331  | `scanf("%s")` dans `username[50]` / `password[50]` de `main`              | Haute    | 
| 14 |     258    | `scanf("%s")` dans `query[100]`                                           | Haute    |
╚════════════════════════════════════════════════════════════════════════════════════════════════════════╝

Type : Logique métier
╔═════════════════════════════════════════════════════════════════════════════════════════════════════╗
| #  | Ligne       | Problème                                                              | Gravité  |
|----|-------------|-----------------------------------------------------------------------|----------|
| 15 | 70          | `scanf("%d", &admin)` — l'utilisateur s'auto-attribue les droits admin| Critique |
| 16 | 67          | `confirm` est lu… puis jamais comparé à `password`                    | Moyenne  |
| 17 | 124         | Montant négatif → transfert inversé, vol du destinataire              | Critique |
| 18 | 124         | Aucune vérification `balance >= amount` → découvert illimité          | Critique |
| 19 | 124-125     | Débordement d'entier sur `balance += amount`                          | Haute    |
| 20 | 122-128     | Auto-transfert (`from_user == i`) autorisé                            | Faible   |
| 21 | 199-204     | `clone_user` recopie `admin_flag` de la source                        | Haute    |
| 22 | 199         | Aucun contrôle de doublon → création possible d'un second admin       | Haute    |
| 23 | 378,388,391 | `list_users`, `compute_stats`, `search_user` sans authentification    | Haute    |
| 24 | 212-213     | `list_users` divulgue soldes + statut admin de tous les comptes       | Moyenne  |
╚═════════════════════════════════════════════════════════════════════════════════════════════════════╝

Type : Gestion mémoire
╔══════════════════════════════════════════════════════════════════════════════════════════════╗
| #  | Ligne   | Problème                                                            | Gravité |
|----|---------|---------------------------------------------------------------------|---------|
| 25 | 77, 314 | Retour de `malloc()` non vérifié → déréférencement de NULL          | Haute   |
| 26 | 77, 314 | Aucun `free()` dans tout le fichier → fuite mémoire                 | Moyenne |
| 27 | 199-204 | `clone_user` n'initialise pas `token` → pointeur NULL/incohérent    | Haute   |
| 28 | 395     | `return 0` sans libérer les tokens                                  | Moyenne |
| 29 | 247  | `total / user_count` → division par zéro si `user_count == 0` (latent) | Faible  |
| 30 | 239     | `int total` déborde en additionnant les soldes                      | Moyenne |
╚══════════════════════════════════════════════════════════════════════════════════════════════╝

Type : Robustesse / entrées
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
| #  | Ligne   | Problème                                                                                                              |
|----|---------|-----------------------------------------------------------------------------------------------------------------------|
| 31 | 320     | `scanf("%d", &choice)` sans vérifier le retour → une lettre laisse le token dans `stdin` → boucle infinie (DoS)       |
| 32 | 321     | `getchar()` ne consomme qu'un seul caractère                                                                          |
| 33 | 96      | `show_profile(user_id)` ne valide pas son index                                                                       |
| 34 | 268-275 | `cleanup_sessions` détecte les sessions expirées mais n'en supprime aucune; `sessions[]` n'est jamais rempli code mort|
| 35 | —       | Pas de logout, `logged_user` jamais remis à -1, aucun timeout de session                                              |
| 36 | 64, 331 | Mots de passe affichés en clair à la saisie (pas de désactivation de l'écho)                                          |
╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

**Total de vulnérabilités identifiées** : _____

---

## 2. CORRECTIONS DÉTAILLÉES <a name="corrections"></a>

> Chaque correction doit contenir les 4 sections obligatoires.

---

## Corrections implémentées

### Correction #1 — Buffer overflow dans show_profile()
**Ligne** : 105 | **Type** : Buffer overflow | **Gravité** : Critique

Avant :
    gets(format);
Après :
    fgets(format, sizeof(format), stdin);

`gets()` ignore la taille du buffer `format[80]` : une saisie plus longue écrase
la mémoire adjacente (retour de fonction → exécution de code arbitraire).
La fonction a été retirée de la norme C en 2011.
`fgets()` reçoit la taille du buffer en 2e argument et ne dépasse jamais.

### Correction #2 — Format string dans show_profile()
**Ligne** : 106 | **Type** : Format string | **Gravité** : Critique

Avant :
    printf(format);
Après :
    printf("%s", format);

La saisie utilisateur était interprétée comme chaîne de format. `%x %x %x`
affiche le contenu de la pile (fuite mémoire), `%s` provoque un crash, et `%n`
écrit en mémoire → écriture arbitraire. Le format est désormais une constante
du programme ; la saisie est traitée comme simple donnée à afficher.

### Correction #3 — Backdoor dans change_password()
**Lignes** : 226-227 | **Type** : Authentification / backdoor | **Gravité** : Critique

Avant :
    if(strcmp(users[user_id].password, old_pass) == 0 ||
       strcmp(old_pass, "master_reset_2024") == 0) {
Après :
    if(strcmp(users[user_id].password, old_pass) == 0) {

Un mot de passe maître codé en dur permettait de changer le mot de passe de
n'importe quel compte sans connaître l'ancien : compromission totale de tous
les comptes, y compris admin. La condition de contournement a été supprimée.

### Correction #4 — Validation de la saisie numérique dans transfer_money()
**Ligne** : 120 | **Type** : Robustesse / DoS | **Gravité** : Haute

Avant :
    scanf("%d", &amount);
Après :
    if (scanf("%d", &amount) != 1) {
        printf("Entrée invalide pour le montant\n");
        int c;
        while ((c = getchar()) != '\n' && c != EOF) { }
        return;
    }

Sur une saisie non numérique ("abc"), scanf n'écrivait rien dans `amount`
(variable non initialisée = valeur imprévisible) et laissait les caractères
dans le tampon d'entrée, bloquant toutes les lectures suivantes → boucle
infinie du menu (déni de service). On vérifie maintenant la valeur de retour
de scanf (nombre de variables remplies) et on vide le tampon en cas d'échec.

### Correction #5 — Montant négatif dans transfer_money()
**Ligne** : 124 | **Type** : Logique métier | **Gravité** : Critique

Avant :
    users[from_user].balance -= amount;
Après :
    if (amount > 0) { ... }

Un montant négatif inversait le sens du transfert : l'attaquant débitait le
compte du destinataire à son profit. `transfer_money(admin, -10000)` volait
10 000 € au compte admin. Seuls les montants strictement positifs sont acceptés.


## 3. TESTS DE VALIDATION <a name="tests"></a>

Pas de test de validation

## 4. CONCLUSION <a name="conclusion"></a>

Manque de temps pour finir le TP ou faire les test de validations