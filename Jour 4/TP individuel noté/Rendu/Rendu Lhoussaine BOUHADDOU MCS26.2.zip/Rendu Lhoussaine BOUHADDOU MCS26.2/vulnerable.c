#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

typedef struct {
    char username[16];
    unsigned char password_hash[SHA256_DIGEST_LENGTH]; // stockage hash SHA-256
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// Fonction de hashage avec SHA-256
void hash_password(const char *pass, unsigned char *digest) {
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, pass, strlen(pass));
    SHA256_Final(digest, &ctx);
}

// Vérifie si deux hashs sont égaux
int compare_hashes(const unsigned char *a, const unsigned char *b) {
    return memcmp(a, b, SHA256_DIGEST_LENGTH) == 0;
}

// Fonction utilitaire pour convertir hash en hex
void hash_to_hex(const unsigned char *hash, char *hex_output) {
    for(int i=0; i<SHA256_DIGEST_LENGTH; i++) {
        sprintf(hex_output + i*2, "%02x", hash[i]);
    }
    hex_output[SHA256_DIGEST_LENGTH*2] = '\0';
}

// Fonction pour comparer mot de passe en clair avec hash stocké
int verify_password(const char *pass, unsigned char *stored_hash) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    hash_password(pass, hash);
    return compare_hashes(hash, stored_hash);
}

// Fonction pour saisir une chaîne sécurisée
void secure_input(char *buffer, size_t size) {
    if(fgets(buffer, size, stdin)) {
        buffer[strcspn(buffer, "\n")] = 0; // supprimer saut de ligne
    } else {
        buffer[0] = '\0';
    }
}

// Fonction de registration utilisateur
void register_user() {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    char username[50], password[50];
    int admin;

    printf("=== ENREGISTREMENT ===\n");
    printf("Username (max 15): ");
    scanf("%14s", username);
    getchar();

    printf("Password (max 15): ");
    scanf("%14s", password);
    getchar();

    printf("Droits admin (1=oui, 0=non): ");
    scanf("%d", &admin);
    getchar();

    // Vérifier si username déjà existe
    for(int i=0; i<user_count; i++) {
        if(strcmp(users[i].username, username) == 0) {
            printf("Utilisateur déjà existant.\n");
            return;
        }
    }

    // remplir la structure
    strncpy(users[user_count].username, username, sizeof(users[user_count].username));
    hash_password(password, users[user_count].password_hash);
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;

    users[user_count].token = malloc(32);
    if(!users[user_count].token) {
        printf("Erreur d'allocation mémoire\n");
        return;
    }
    snprintf(users[user_count].token, 32, "TOK_%d_%s", user_count, username);
    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Fonction de login utilisateur
int login_user(const char *username, const char *password) {
    for(int i=0; i<user_count; i++) {
        if(strcmp(users[i].username, username) == 0) {
            if(verify_password(password, users[i].password_hash)) {
                return i;
            }
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    printf("Format d'affichage personnalisé: ");
    fgets(format, sizeof(format), stdin);
    format[strcspn(format, "\n")] = 0;
    printf("%s\n", format);
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    scanf("%49s", to_username);
    getchar();

    printf("Montant: ");
    scanf("%d", &amount);
    getchar();

    if(amount <= 0) {
        printf("Montant invalide.\n");
        return;
    }

    int dest_index = -1;
    for(int i=0; i<user_count; i++) {
        if(strcmp(users[i].username, to_username) == 0) {
            dest_index = i;
            break;
        }
    }
    if(dest_index == -1) {
        printf("Utilisateur destinataire introuvable\n");
        return;
    }
    if(users[from_user].balance < amount) {
        printf("Fonds insuffisants\n");
        return;
    }

    users[from_user].balance -= amount;
    users[dest_index].balance += amount;
    printf("Transfert effectué!\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[100];
    printf("Nom du fichier de backup (max 99): ");
    scanf("%99s", filename);
    getchar();

    FILE *fp = fopen(filename, "w");
    if(!fp) {
        printf("Erreur d'ouverture du fichier\n");
        return;
    }
    // Stocker le hash en hex
    char hash_hex[SHA256_DIGEST_LENGTH*2+1];
    hash_to_hex(users[user_id].password_hash, hash_hex);
    fprintf(fp, "%s:%s:%d:%d\n",
        users[user_id].username,
        hash_hex,
        users[user_id].admin_flag,
        users[user_id].balance);
    fclose(fp);
    printf("Backup créé\n");
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    printf("Fichier à restaurer (max 199): ");
    scanf("%199s", filename);
    getchar();

    FILE *fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    char buffer[256];
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    fgets(cmd, sizeof(cmd), stdin);
    cmd[strcspn(cmd, "\n")] = 0;

    // Validation simple pour éviter injections
    if(strstr(cmd, ";") || strstr(cmd, "&&") || strstr(cmd, "|")) {
        printf("Commande non autorisée.\n");
        return;
    }
    char full_cmd[200];
    snprintf(full_cmd, sizeof(full_cmd), "echo 'Exécution:' && %s", cmd);
    system(full_cmd);
}

// Clonage utilisateur
void clone_user(int source_id) {
    char target_username[30];

    printf("Nom du clone (max 29): ");
    scanf("%29s", target_username);
    getchar();

    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    // Vérifier si le nom existe déjà
    for(int i=0; i<user_count; i++) {
        if(strcmp(users[i].username, target_username) == 0) {
            printf("Nom d'utilisateur déjà existant.\n");
            return;
        }
    }

    strncpy(users[user_count].username, target_username, sizeof(users[user_count].username));
    memcpy(users[user_count].password_hash, users[source_id].password_hash, SHA256_DIGEST_LENGTH);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;

    users[user_count].token = malloc(32);
    if(!users[user_count].token) {
        printf("Erreur mémoire\n");
        return;
    }
    snprintf(users[user_count].token, 32, "TOK_%d_%s", user_count, target_username);
    user_count++;
    printf("Clone créé\n");
}

// Liste tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i=0; i<user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[80], new_pass[80];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    fgets(old_pass, sizeof(old_pass), stdin);
    old_pass[strcspn(old_pass, "\n")] = 0;

    if(verify_password(old_pass, users[user_id].password_hash) || strcmp(old_pass, "master_reset_2024") == 0) {
        printf("Nouveau mot de passe (max 15): ");
        fgets(new_pass, sizeof(new_pass), stdin);
        new_pass[strcspn(new_pass, "\n")] = 0;
        hash_password(new_pass, users[user_id].password_hash);
        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    for(int i=0; i<user_count; i++) {
        total += users[i].balance;
    }
    double avg = (user_count > 0) ? ((double)total / user_count) : 0;
    printf("Total: %d€, Moyenne: %.2f€\n", total, avg);
}

// Rechercher utilisateur
void search_user() {
    char query[100];
    printf("Rechercher: ");
    scanf("%99s", query);
    getchar();

    for(int i=0; i<user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer sessions expirées
void cleanup_sessions() {
    time_t now = time(NULL);
    for(int i=0; i<session_count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    // Compte admin par défaut
    strcpy(users[0].username, "admin");
    hash_password("admin123", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(32);
    if(users[0].token) {
        strcpy(users[0].token, "ADMIN_TOKEN");
    }
    user_count = 1;

    while(1) {
        display_menu();
        scanf("%d", &choice);
        getchar();

        switch(choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                scanf("%49s", username);
                getchar();
                printf("Password: ");
                scanf("%49s", password);
                getchar();
                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                // Libérer toutes les tokens
                for(int i=0; i<user_count; i++) {
                    if(users[i].token) {
                        free(users[i].token);
                        users[i].token = NULL;
                    }
                }
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    return 0;
}
