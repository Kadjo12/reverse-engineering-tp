/*
 * TP FINAL - secure.c (version corrigée de vulnerable.c)
 *
 * Corrections repérées dans le code par un commentaire "CORRECTION n" :
 *   1 format string          7 strcpy / taille des champs
 *   2 élévation privilèges   8 contrôles d'accès
 *   3 backdoor + creds durs   9 gestion mémoire
 *   4 validation transferts  10 validation noms de fichiers
 *   5 gets()                 11 boucle infinie scanf("%d")
 *   6 scanf("%s")
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <limits.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_USERS 20

typedef struct {
    char username[32];   /* CORRECTION 7 */
    char password[64];   /* CORRECTION 7 */
    int admin_flag;
    int balance;
    char *token;
} User;

User users[MAX_USERS];
int user_count = 0;
int logged_user = -1;

/* CORRECTION 5 + CORRECTION 6 : remplace gets() et scanf("%s") */
int read_line(char *buf, size_t size) {
    size_t len; int c;
    if(!fgets(buf, (int)size, stdin)) { buf[0] = '\0'; return 0; }
    len = strlen(buf);
    if(len > 0 && buf[len-1] == '\n') { buf[len-1] = '\0'; return 1; }
    while((c = getchar()) != '\n') if(c == EOF) return 0;
    return -1;
}

/* CORRECTION 11 : remplace scanf("%d") */
int read_int(int *out) {
    char buf[32]; char *end; long v;
    if(read_line(buf, sizeof(buf)) != 1 || buf[0] == '\0') return 0;
    v = strtol(buf, &end, 10);
    if(end == buf || *end != '\0' || v < INT_MIN || v > INT_MAX) return 0;
    *out = (int)v; return 1;
}

/* CORRECTION 10 : interdit '/', '..' et les noms cachés */
int safe_filename(const char *n) {
    size_t i, len = strlen(n);
    if(len == 0 || len > 64 || n[0] == '.' || n[0] == '-') return 0;
    for(i = 0; i < len; i++) {
        if(!isalnum((unsigned char)n[i]) && n[i] != '_' && n[i] != '-' && n[i] != '.') return 0;
        if(n[i] == '.' && n[i+1] == '.') return 0;
    }
    return 1;
}

/* CORRECTION 8 : contrôle d'accès centralisé */
int require_login(void) {
    if(logged_user < 0 || logged_user >= user_count) { printf("Veuillez vous connecter\n"); return 0; }
    return 1;
}
int require_admin(void) {
    if(!require_login()) return 0;
    if(!users[logged_user].admin_flag) { printf("Accès refusé\n"); return 0; }
    return 1;
}

/* CORRECTION 9 */
void cleanup(void) {
    for(int i = 0; i < MAX_USERS; i++) { free(users[i].token); users[i].token = NULL; }
}

// Fonction de hashage personnalisée
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;
    while ((c = *pass++))
        h = h * 33 + c;
    return h;
}

// Enregistrement d'un nouvel utilisateur
void register_user() {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    
    char username[32];
    char password[64];
    char confirm[64];
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");   /* CORRECTION 6 : lecture bornée, entrée trop longue refusée */
    if(read_line(username, sizeof(username)) != 1 || username[0] == '\0') { printf("Saisie invalide\n"); return; }
    
    printf("Password: ");
    if(read_line(password, sizeof(password)) != 1 || password[0] == '\0') { printf("Saisie invalide\n"); return; }
    
    printf("Confirmer password: ");
    if(read_line(confirm, sizeof(confirm)) != 1 || strcmp(password, confirm) != 0) { printf("Saisie invalide\n"); return; }
    
    /* CORRECTION 7 */
    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", username);
    snprintf(users[user_count].password, sizeof(users[user_count].password), "%s", password);
    users[user_count].admin_flag = 0;   /* CORRECTION 2 */
    users[user_count].balance = 100;
    
    users[user_count].token = malloc(32);
    if(!users[user_count].token) { printf("Erreur mémoire\n"); return; }   /* CORRECTION 9 */
    snprintf(users[user_count].token, 32, "TOK_%d", user_count);
    
    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, username) == 0 && 
           strcmp(users[i].password, password) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    
    printf("Format d'affichage personnalisé: ");
    read_line(format, sizeof(format));   /* CORRECTION 5 */
    printf("%s\n", format);             /* CORRECTION 1 */
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[32];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    read_line(to_username, sizeof(to_username));   /* CORRECTION 6 */
    
    printf("Montant: ");
    if(!read_int(&amount)) { printf("Montant invalide\n"); return; }
    
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, to_username) == 0) {
            /* CORRECTION 4 */
            if(i == from_user || amount <= 0 || amount > users[from_user].balance
               || users[i].balance > INT_MAX - amount) {
                printf("Transfert refusé\n"); return;
            }
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[65];
    FILE *fp;
    int fd;
    
    printf("Nom du fichier de backup: ");
    if(read_line(filename, sizeof(filename)) != 1 || !safe_filename(filename)) { printf("Nom de fichier refusé\n"); return; }  /* CORRECTION 10 */
    
    fd = open(filename, O_WRONLY | O_CREAT | O_EXCL, 0600);   /* CORRECTION 10 */
    fp = (fd >= 0) ? fdopen(fd, "w") : NULL;
    if(fp) {
        fprintf(fp, "%s:%d:%d\n", 
                users[user_id].username,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[65];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    if(read_line(filename, sizeof(filename)) != 1 || !safe_filename(filename)) { printf("Nom de fichier refusé\n"); return; }  /* CORRECTION 10 */
    
    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    char full_cmd[200];
    
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    read_line(cmd, sizeof(cmd));   /* CORRECTION 5 */
    
    snprintf(full_cmd, sizeof(full_cmd), "echo 'Exécution:' && %s", cmd);
    if(system(full_cmd) == -1) printf("Échec de l'exécution\n");
}

// Copie de données utilisateur
void clone_user(int source_id) {
    (void)source_id;   /* CORRECTION 2 : le clone n'hérite plus rien de la source */
    char target_username[32];
    char password[64];
    
    printf("Nom du clone: ");   /* CORRECTION 6 */
    if(read_line(target_username, sizeof(target_username)) != 1 || target_username[0] == '\0') { printf("Création refusée\n"); return; }
    printf("Mot de passe du clone: ");
    if(read_line(password, sizeof(password)) != 1 || password[0] == '\0') { printf("Création refusée\n"); return; }
    if(user_count >= MAX_USERS) { printf("Limite atteinte\n"); return; }
    
    /* CORRECTION 7 */
    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", target_username);
    snprintf(users[user_count].password, sizeof(users[user_count].password), "%s", password);
    users[user_count].admin_flag = 0;   /* CORRECTION 2 */
    users[user_count].balance = 0;      /* CORRECTION 2 */
    
    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    if(!users[logged_user].admin_flag) {   /* CORRECTION 8 */
        printf("0. %s (Balance: %d€)\n", users[logged_user].username, users[logged_user].balance);
        return;
    }
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[64];
    char new_pass[64];
    
    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    read_line(old_pass, sizeof(old_pass));   /* CORRECTION 5 */
    
    /* CORRECTION 3 : backdoor "master_reset_2024" supprimée */
    if(strcmp(users[user_id].password, old_pass) == 0) {
        printf("Nouveau mot de passe: ");
        read_line(new_pass, sizeof(new_pass));   /* CORRECTION 5 */
        /* CORRECTION 7 */
        snprintf(users[user_id].password, sizeof(users[user_id].password), "%s", new_pass);
        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];
    
    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[32];
    
    printf("Rechercher: ");
    if(read_line(query, sizeof(query)) != 1 || query[0] == '\0') { printf("Recherche refusée\n"); return; }
    
    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    char username[32], password[64];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    /* CORRECTION 3 : plus de mot de passe admin en dur */
    snprintf(users[0].username, sizeof(users[0].username), "admin");
    printf("Définir le mot de passe administrateur: ");
    if(read_line(users[0].password, sizeof(users[0].password)) != 1) return 1;
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(32);
    if(!users[0].token) return 1;   /* CORRECTION 9 */
    snprintf(users[0].token, 32, "TOK_0");
    user_count = 1;
    
    while(1) {
        display_menu();
        /* CORRECTION 11 */
        if(!read_int(&choice)) {
            if(feof(stdin)) break;
            printf("Choix invalide\n"); continue;
        }
        
        switch(choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                read_line(username, sizeof(username));   /* CORRECTION 6 */
                printf("Password: ");
                read_line(password, sizeof(password));   /* CORRECTION 6 */
                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(require_login()) show_profile(logged_user);   /* CORRECTION 8 */
                break;
            case 4:
                if(require_login()) transfer_money(logged_user);   /* CORRECTION 8 */
                break;
            case 5:
                if(require_login()) backup_user_data(logged_user);   /* CORRECTION 8 */
                break;
            case 6:
                if(require_login()) restore_user_data();   /* CORRECTION 8 */
                break;
            case 7:
                if(require_admin()) system_command();   /* CORRECTION 8 */
                break;
            case 8:
                if(require_login()) clone_user(logged_user);   /* CORRECTION 8 */
                break;
            case 9:
                if(require_login()) list_users();   /* CORRECTION 8 */
                break;
            case 10:
                if(require_login()) change_password(logged_user);   /* CORRECTION 8 */
                break;
            case 11:
                if(require_admin()) compute_stats();   /* CORRECTION 8 */
                break;
            case 12:
                if(require_login()) search_user();   /* CORRECTION 8 */
                break;
            case 0:
                printf("Au revoir!\n");
                cleanup();   /* CORRECTION 9 */
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }
    
    cleanup();   /* CORRECTION 9 */
    return 0;
}
