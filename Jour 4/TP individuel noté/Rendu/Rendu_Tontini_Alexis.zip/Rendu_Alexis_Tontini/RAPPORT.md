# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : Alexis TONTINI  
**Date** : 30 juillet 2026  
**Durée** : 4 heures

---

## TABLE DES MATIÈRES
1. [Synthèse des vulnérabilités](#synthèse)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS <a name="synthèse"></a>

### Tableau récapitulatif

| # | Fonction | Ligne(s) | Type | Gravité | Corrigée |
|---|----------|----------|------|---------|----------|
| 1 | `show_profile` | 105-106 | Format string | Critique | ☑ Oui ☐ Non |
| 2 | `register_user`, `clone_user` | 70, 74, 201-202 | Élévation de privilèges et création de monnaie | Critique | ☑ Oui ☐ Non |
| 3 | `main`, `change_password` | 310-315, 227 | Identifiants en dur et backdoor | Critique | ☑ Oui ☐ Non |
| 4 | `transfer_money` | 120-125 | Validation des transferts absente | Critique | ☑ Oui ☐ Non |
| 5 | `show_profile`, `system_command`, `change_password`, `register_user`, `transfer_money`, `backup_user_data`, `restore_user_data`, `clone_user`, `search_user`, `main` | 61, 64, 67, 105, 117, 139, 160, 181, 192, 224, 229, 258, 329, 331 | Buffer overflow — `gets()` et `scanf("%s")`, 15 occurrences | Critique | ☑ Oui ☐ Non |
| 6 | `register_user`, `clone_user`, `change_password` | 72-73, 199, 230 | Débordement de structure — `strcpy` | Critique | ☑ Oui ☐ Non |
| 7 | `main` | 360, 377, 387, 390 | Contrôle d'accès absent (menus 6, 9, 11, 12) | Haute | ☑ Oui ☐ Non |
| 8 | `register_user`, `main` | 77-78, 314 | Gestion mémoire — `malloc` non vérifié, aucun `free`, heap overflow | Critique | ☑ Oui ☐ Non |
| 9 | `backup_user_data`, `restore_user_data` | 139-142, 160-166 | Path traversal | Critique | ☑ Oui ☐ Non |
| 10 | `main` | 320 | Boucle infinie sur `scanf("%d")` | Haute | ☑ Oui ☐ Non |
| 11 | Structure `User`, `hash_password` | 21, 39-45 | Mots de passe en clair, hachage faible | Critique | ☐ Oui ☑ Non |
| 12 | `system_command` | 183-184 | Injection de commande | Critique | ☐ Oui ☑ Non |

Rajouter des lignes si nécessaire.

**Total de vulnérabilités identifiées** : 12 (10 corrigées, 2 non corrigées — voir 4.3)

---

## 2. CORRECTIONS DÉTAILLÉES <a name="corrections"></a>

> Chaque correction doit contenir les 4 sections obligatoires.

---

### Correction #1 : Format string

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `show_profile()`  
**Ligne(s)** : 105-106

**Description** :
```
La saisie de l'utilisateur est passée à printf() comme chaîne de format, et non
comme argument à afficher.
```

**Code vulnérable** :
```c
gets(format);
printf(format);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
printf interprète les directives % et cherche des arguments inexistants, donc
lit la pile. %x affiche des adresses. %n ÉCRIT en mémoire à une adresse prise
sur la pile : écriture arbitraire, donc exécution de code.

Entrée malicieuse : %x %x %n
```

**Impact** :
- [x] Exécution de code arbitraire
- [x] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Fuite d'informations
- [ ] Autre : _______________

#### ✅ Correction implémentée

**Code corrigé** :
```c
read_line(format, sizeof(format));
printf("%s\n", format);
```

**Modifications effectuées** :
1. La chaîne de format devient une constante du programme.
2. La saisie passe en argument de `%s`.
3. Vérifié sur tout le fichier : aucun `printf` ne reçoit de format variable.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Avec un format constant, les directives sont fixées à la compilation et
cohérentes avec les arguments. Une saisie contenant %n est affichée comme du
texte ordinaire. Le compilateur peut en plus vérifier la cohérence
format/arguments via -Wformat, impossible avec un format variable.
```

**Tests effectués** :
```bash
printf 'A\n1\nbob\np1\np1\n2\nbob\np1\n3\n%x %x %n\n0\n' | ./secure
# Obtenu : "%x %x %n" affiché littéralement
```

---

### Correction #2 : Élévation de privilèges et création de monnaie

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`, `clone_user()`  
**Ligne(s)** : 70, 74, 199-202

**Description** :
```
Le programme demande à l'utilisateur s'il veut les droits admin et applique la
réponse. Le clone recopie admin_flag, le mot de passe et le solde de la source.
```

**Code vulnérable** :
```c
printf("Droits admin (1=oui, 0=non): ");
scanf("%d", &admin);
users[user_count].admin_flag = admin;

users[user_count].admin_flag = users[source_id].admin_flag;
users[user_count].balance = users[source_id].balance;
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Répondre "1" suffit pour devenir admin, ce qui ouvre le menu 7 :
  menu 1 (compte admin) -> menu 2 (connexion) -> menu 7 (commande système)

Le clone recopie le solde sans débiter la source : un compte à 10 000 € cloné
5 fois porte le total du système à 60 000 €.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : atteinte à l'intégrité financière

#### ✅ Correction implémentée

**Code corrigé** :
```c
users[user_count].admin_flag = 0;   /* register_user, prompt supprimé */

void clone_user(int source_id) {
    (void)source_id;                /* n'hérite plus rien de la source */
    ...
    users[user_count].admin_flag = 0;
    users[user_count].balance = 0;
```

**Modifications effectuées** :
1. Suppression du prompt « Droits admin ».
2. Toute inscription crée un compte standard.
3. Le clone demande son propre mot de passe et démarre à 0 €.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Une décision de sécurité ne doit jamais dépendre d'une donnée fournie par la
partie qu'elle contraint. admin_flag devenu inaccessible depuis les entrées, le
contrôle du menu 7 redevient une vraie barrière.

Seul le transfert modifie un solde, et il débite exactement ce qu'il crédite :
la somme des soldes est invariante.
```

**Tests effectués** :
```bash
printf 'A\n1\nx\np1\np1\n2\nx\np1\n7\n0\n' | ./secure
# Obtenu : "Utilisateur enregistré!" puis "Accès refusé"
```

---

### Correction #3 : Identifiants en dur et backdoor

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `main()`, `change_password()`  
**Ligne(s)** : 310-315, 227

**Description** :
```
Compte admin/admin123 créé en dur, token ADMIN_TOKEN constant, et mot de passe
maître "master_reset_2024" accepté au changement de mot de passe.
```

**Code vulnérable** :
```c
strcpy(users[0].password, "admin123");
strcpy(users[0].token, "ADMIN_TOKEN");

if(strcmp(users[user_id].password, old_pass) == 0 ||
   strcmp(old_pass, "master_reset_2024") == 0) {
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Les trois chaînes sont en clair dans le binaire :

    strings ./vulnerable | grep -i admin

Aucune analyse nécessaire. Le compte obtenu ouvre le menu 7. La backdoor permet
de changer le mot de passe d'un compte connecté sans connaître l'ancien.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations
- [x] Autre : contournement d'authentification

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("Définir le mot de passe administrateur: ");
if(read_line(users[0].password, sizeof(users[0].password)) != 1
   || users[0].password[0] == '\0') return 1;
snprintf(users[0].token, 32, "TOK_0");

if(strcmp(users[user_id].password, old_pass) == 0) {   /* backdoor supprimée */
```

**Modifications effectuées** :
1. Mot de passe admin saisi au lancement, absent du binaire, et refusé s'il est vide.
2. Suppression de la condition `|| strcmp(old_pass, "master_reset_2024") == 0`.
3. Token `ADMIN_TOKEN` remplacé par une valeur dérivée de l'index.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Plus aucun secret dans le binaire, et le mot de passe admin diffère à chaque
déploiement puisqu'il est choisi à l'exécution.

Une backdoor n'est pas un défaut d'implémentation mais une porte volontaire :
la seule correction acceptable est sa suppression, pas son obfuscation.
```

**Tests effectués** :
```bash
strings secure | grep -cE "admin123|master_reset|ADMIN_TOKEN"     # Obtenu : 0
printf 'A\n1\nbob\np1\np1\n2\nbob\np1\n10\nmaster_reset_2024\n0\n' | ./secure
# Obtenu : "Ancien mot de passe incorrect"
```

---

### Correction #4 : Validation des transferts

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `transfer_money()`  
**Ligne(s)** : 120-127

**Description** :
```
Le montant est lu sans validation : ni signe, ni plafond, ni contrôle du solde
disponible, ni protection contre le dépassement de capacité de int.
```

**Code vulnérable** :
```c
scanf("%d", &amount);
users[from_user].balance -= amount;
users[i].balance += amount;
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Saisir -5000 donne :
    from.balance -= (-5000)   soit un CRÉDIT pour l'attaquant
    to.balance   += (-5000)   soit un DÉBIT pour la victime
Le transfert s'inverse : l'attaquant se paie sur le compte de sa cible.

Sans contrôle de solde, un compte à 100 € peut transférer 1 000 000 € et tomber
à -999 900 €. Dépasser INT_MAX est un comportement indéfini.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : vol de fonds, comportement indéfini

#### ✅ Correction implémentée

**Code corrigé** :
```c
if(!read_int(&amount)) { printf("Montant invalide\n"); return; }
...
if(i == from_user || amount <= 0 || amount > users[from_user].balance
   || users[i].balance > INT_MAX - amount) {
    printf("Transfert refusé\n"); return;
}
```

**Modifications effectuées** :
1. Montant strictement positif exigé et solde disponible contrôlé.
2. Vérification anti-dépassement avant l'addition.
3. Refus du transfert vers soi-même.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
La contrainte 0 < amount <= from.balance garantit le sens du transfert et la
disponibilité des fonds.

Le test s'écrit "balance > INT_MAX - amount" et NON "balance + amount >
INT_MAX" : la seconde forme calcule justement le dépassement à éviter, or c'est
un comportement indéfini et un compilateur optimisant peut supposer qu'il
n'arrive jamais et supprimer le test.

Toutes les vérifications précèdent la première écriture : aucun état où le
débit serait appliqué sans le crédit.
```

**Tests effectués** :
```bash
printf 'A\n1\nbob\np1\np1\n2\nbob\np1\n4\nadmin\n-5000\n3\n\n0\n' | ./secure
# Obtenu : "Transfert refusé" puis "Balance: 100€"  -> solde inchangé
```

---

### Correction #5 : Débordements de tampon (`gets()` et `scanf("%s")`)

#### 🔴 Vulnérabilité originale
**Fonction concernée** : toutes les fonctions lisant une chaîne  
**Ligne(s)** : `gets()` en 105, 181, 224, 229 — `scanf("%s")` en 61, 64, 67, 117, 139, 160, 192, 258, 329, 331

**Description** :
```
gets() ne reçoit pas la taille du tampon : il n'existe aucune façon sûre de
l'utiliser, et il a été retiré du standard C11. scanf("%s") lit sans limite de
longueur, la taille de la destination ne lui étant jamais communiquée.
```

**Code vulnérable** :
```c
char format[80];
gets(format);

char username[100];
scanf("%s", username);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Ces tampons sont dans la pile. Une entrée de plusieurs centaines d'octets
écrase les variables voisines, le pointeur de cadre, puis l'adresse de retour,
ce qui permet de détourner l'exécution.

Cas le plus net : dans change_password(), old_pass[80] et new_pass[80] sont
adjacents, donc une entrée longue dans le premier écrase le second.

Entrée malicieuse : 500 caractères au prompt "Username:".
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption des variables adjacentes

#### ✅ Correction implémentée

**Code corrigé** :
```c
/* retourne 1 = ligne complète, 0 = EOF, -1 = ligne trop longue */
int read_line(char *buf, size_t size) {
    size_t len; int c;
    if(!fgets(buf, (int)size, stdin)) { buf[0] = '\0'; return 0; }
    len = strlen(buf);
    if(len > 0 && buf[len-1] == '\n') { buf[len-1] = '\0'; return 1; }
    while((c = getchar()) != '\n') if(c == EOF) return 0;   /* vide le reste */
    return -1;
}

if(read_line(username, sizeof(username)) != 1 || username[0] == '\0') {
    printf("Saisie invalide\n"); return;
}
```

**Modifications effectuées** :
1. Les 15 appels à `gets()` et `scanf("%s")` passent par `read_line()`.
2. `sizeof(buffer)` systématiquement transmis.
3. Une entrée trop longue est refusée, pas tronquée.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
fgets() reçoit la taille du tampon et écrit au maximum size - 1 caractères plus
le '\0'. Le débordement est impossible par construction.

Deux points vont au-delà des consignes :
- scanf("%15s") borne l'écriture mais laisse le reste de la ligne dans le
  tampon, que la lecture suivante consomme, ce qui désynchronise les saisies.
  read_line() vide le reste.
- Une entrée trop longue est refusée plutôt que tronquée : tronquer un nom
  pourrait faire coïncider deux comptes distincts.
```

**Tests effectués** :
```bash
{ echo "A"; echo "1"; printf 'X%.0s' $(seq 1 500); echo; echo "0"; } | ./secure
# Obtenu : "Saisie invalide", aucun crash
```

---

### Correction #6 : Débordement de structure par `strcpy()`

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`, `clone_user()`, `change_password()`  
**Ligne(s)** : 72-73, 199, 230

**Description** :
```
Les champs de la structure User mesurent 16 octets, les tampons de saisie 30 à
100. strcpy() copie jusqu'au '\0' de la source sans considérer la destination.
```

**Code vulnérable** :
```c
char username[16];
char password[16];
...
strcpy(users[user_count].username, username);   /* 100 -> 16 */
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
La disposition de la structure est connue. En partant de username, l'écriture
continue sur password, admin_flag, balance, puis le pointeur token :

    [0..15] username | [16..31] password | [32..35] admin_flag
    [36..39] balance | [40..47] token

Un nom de 32 octets dont les octets 24 à 27 sont non nuls crée un compte AVEC
LES DROITS ADMIN, sans les avoir demandés.

Effet de bord : quand la copie remplit exactement 16 octets, le '\0' n'est pas
écrit, donc strcmp() et strstr() lisent dans le compte suivant.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [x] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption du solde et du pointeur `token`

#### ✅ Correction implémentée

**Code corrigé** :
```c
char username[32];
char password[64];
...
snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", username);
snprintf(users[user_count].password, sizeof(users[user_count].password), "%s", password);
```

**Modifications effectuées** :
1. Champs dimensionnés en cohérence avec les tampons de saisie.
2. Les 3 `strcpy()` remplacés par `snprintf()`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
snprintf() écrit au maximum size - 1 caractères ET garantit le '\0', les deux
propriétés dans la même fonction.

Les consignes recommandent strncpy() : c'est un piège. strncpy(dst, src, n)
n'écrit pas de '\0' si la source fait au moins n caractères. On corrige alors
le débordement d'écriture en créant une lecture hors bornes, exactement le
défaut décrit ci-dessus. Il faudrait penser à ajouter dst[n-1] = '\0' sur
chaque appel ; snprintf() rend l'oubli impossible.
```

**Tests effectués** :
```bash
{ echo "A"; echo "1"; printf 'X%.0s' $(seq 1 32); echo; echo "0"; } | ./secure
# Obtenu : "Saisie invalide", admin_flag intact
```

---

### Correction #7 : Contrôles d'accès absents

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `main()`  
**Ligne(s)** : 360, 377, 387, 390

**Description** :
```
Quatre entrées du menu ne vérifient pas l'authentification : 6 (restauration),
9 (liste), 11 (statistiques), 12 (recherche). Les indices utilisateur ne sont
par ailleurs jamais validés avant l'accès au tableau users[].
```

**Code vulnérable** :
```c
case 6:
    restore_user_data();     /* aucun contrôle */
case 9:
    list_users();            /* aucun contrôle */
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Menu 9 : liste complète des comptes avec soldes et statut admin, soit la
cartographie des cibles. Menu 12 : énumération par sous-chaîne. Menu 11 :
agrégats financiers.

Menu 6, le plus grave : lecture de fichier arbitraire sans authentification
(voir correction #9). Il suffit de lancer le programme et de taper 6.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [x] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Fuite d'informations
- [x] Autre : énumération des comptes

#### ✅ Correction implémentée

**Code corrigé** :
```c
int require_login(void) {
    if(logged_user < 0 || logged_user >= user_count) {
        printf("Veuillez vous connecter\n"); return 0;
    }
    return 1;
}
int require_admin(void) {
    if(!require_login()) return 0;
    if(!users[logged_user].admin_flag) { printf("Accès refusé\n"); return 0; }
    return 1;
}

case 6:  if(require_login()) restore_user_data();   break;
case 11: if(require_admin()) compute_stats();       break;
```

**Modifications effectuées** :
1. Contrôle centralisé dans `require_login()` et `require_admin()`.
2. Authentification exigée sur les menus 3, 4, 5, 6, 8, 9, 10, 12 ; droits admin sur 7 et 11.
3. Vue restreinte du menu 9 pour un utilisateur standard.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Centraliser la règle supprime la duplication, donc le risque d'oubli : l'ajout
d'une fonctionnalité impose un choix visible à la lecture du switch.

require_admin() appelle require_login(), donc un privilège n'est jamais évalué
sur une session invalide : tester users[logged_user].admin_flag avant de
valider logged_user serait déjà un accès hors bornes. La vérification couvre
les deux bornes du tableau.
```

**Tests effectués** :
```bash
printf 'A\n6\n9\n11\n12\n0\n' | ./secure | grep -c "Veuillez vous connecter\|Accès refusé"
# Obtenu : 4  -> les quatre menus sont protégés
```

---

### Correction #8 : Gestion mémoire

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`, `main()`  
**Ligne(s)** : 77-78, 314

**Description** :
```
Trois défauts sur le même bloc : retour de malloc() non testé, sprintf() de
taille variable dans 32 octets fixes, et aucun free() dans tout le programme.
```

**Code vulnérable** :
```c
users[user_count].token = malloc(32);
sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Le préfixe et l'index occupent 6 à 7 octets, il en reste ~25 pour un nom qui
peut en compter 99. Au-delà, l'écriture sort du bloc et corrompt les
métadonnées de l'allocateur : voie classique vers l'exécution de code.

Si malloc() échoue, sprintf() écrit à l'adresse 0 et le programme s'arrête :
déni de service par épuisement mémoire.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : fuite mémoire

#### ✅ Correction implémentée

**Code corrigé** :
```c
users[user_count].token = malloc(32);
if(!users[user_count].token) { printf("Erreur mémoire\n"); return; }
snprintf(users[user_count].token, 32, "TOK_%d", user_count);

void cleanup(void) {
    for(int i = 0; i < MAX_USERS; i++) { free(users[i].token); users[i].token = NULL; }
}
```

**Modifications effectuées** :
1. Retour de `malloc()` testé ; en cas d'échec le compte n'est pas créé.
2. `sprintf` remplacé par `snprintf` avec la même taille que l'allocation.
3. `cleanup()` appelée sur tous les chemins de sortie de `main()`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
L'allocation et l'écriture utilisent la même taille, donc aucune divergence
possible, et le nom d'utilisateur ne fait plus partie du token, ce qui supprime
la partie de longueur variable.

cleanup() parcourt MAX_USERS et non user_count, pour libérer aussi un token
alloué lors d'une création interrompue avant l'incrément. free(NULL) étant sans
effet, la boucle est sûre sur les emplacements vides.
```

**Tests effectués** :
```bash
rm -f bkp.txt
valgrind --leak-check=full --show-leak-kinds=all ./secure < test_inputs.txt
# Attendu : "All heap blocks were freed -- no leaks are possible"
```

---

### Correction #9 : Path traversal

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `backup_user_data()`, `restore_user_data()`  
**Ligne(s)** : 139-148, 160-170

**Description** :
```
Le nom de fichier saisi est transmis directement à fopen() sans validation. Il
peut contenir "..", "/" ou un chemin absolu. Le backup contient de plus le mot
de passe en clair et est créé en 0644.
```

**Code vulnérable** :
```c
scanf("%s", filename);
fp = fopen(filename, "w");
fprintf(fp, "%s:%s:%d:%d\n", users[user_id].username,
        users[user_id].password, ...);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Écriture (menu 5) : "../../../../home/victime/.bashrc" ouvre ce fichier en mode
"w", ce qui le TRONQUE puis y écrit. Un fichier de démarrage de shell écrasé
s'exécute à la session suivante : destruction de données ou exécution de code.

Lecture (menu 6) : "../../etc/passwd" affiche le contenu du fichier, et ce menu
était accessible sans authentification.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Fuite d'informations
- [x] Autre : écriture de fichier arbitraire, destruction de données

#### ✅ Correction implémentée

**Code corrigé** :
```c
int safe_filename(const char *n) {
    size_t i, len = strlen(n);
    if(len == 0 || len > 64 || n[0] == '.' || n[0] == '-') return 0;
    for(i = 0; i < len; i++) {
        if(!isalnum((unsigned char)n[i]) && n[i] != '_' && n[i] != '-' && n[i] != '.') return 0;
        if(n[i] == '.' && n[i+1] == '.') return 0;
    }
    return 1;
}

if(read_line(filename, sizeof(filename)) != 1 || !safe_filename(filename)) {
    printf("Nom de fichier refusé\n"); return;
}
fd = open(filename, O_WRONLY | O_CREAT | O_EXCL, 0600);
fp = (fd >= 0) ? fdopen(fd, "w") : NULL;
```

**Modifications effectuées** :
1. Validation par liste blanche de caractères, `..` et noms cachés rejetés.
2. `O_EXCL` et permissions `0600` à la création.
3. Le mot de passe n'est plus écrit dans le fichier de sauvegarde.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
La liste blanche exclut '/', seul séparateur de chemin sous POSIX : un nom
validé désigne forcément une entrée du répertoire courant. Une liste blanche
est fermée par défaut, donc un motif d'attaque non anticipé est refusé, alors
qu'une liste noire ne bloque que ce qu'elle connaît.

O_EXCL rend la création atomique et la fait échouer si la cible existe, ce qui
neutralise l'écrasement de fichier et les attaques par lien symbolique. Le mode
0600 limite la lecture au propriétaire.
```

**Tests effectués** :
```bash
printf 'A\n2\nadmin\nA\n5\n../../etc/passwd\n0\n' | ./secure
# Obtenu : "Nom de fichier refusé"
ls -l bkp.txt        # Obtenu : -rw------- (0600)
```

---

### Correction #10 : Boucle infinie sur `scanf("%d")`

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `main()`  
**Ligne(s)** : 320

**Description** :
```
La valeur de retour de scanf("%d", &choice) n'est jamais testée.
```

**Code vulnérable** :
```c
scanf("%d", &choice);
getchar();
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Sur une entrée non numérique, scanf retourne 0, laisse choice inchangé et NE
CONSOMME PAS le caractère fautif ; getchar() n'en retire qu'un. L'itération
suivante rencontre les mêmes caractères : le programme boucle indéfiniment à
100 % de CPU. Une seule lettre suffit.

Même phénomène à la fermeture de stdin, ce qui rend toute analyse Valgrind
impossible avec une entrée redirigée.

Entrée malicieuse : "abc"
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : saturation du processeur

#### ✅ Correction implémentée

**Code corrigé** :
```c
int read_int(int *out) {
    char buf[32]; char *end; long v;
    if(read_line(buf, sizeof(buf)) != 1 || buf[0] == '\0') return 0;
    v = strtol(buf, &end, 10);
    if(end == buf || *end != '\0' || v < INT_MIN || v > INT_MAX) return 0;
    *out = (int)v; return 1;
}

if(!read_int(&choice)) {
    if(feof(stdin)) break;
    printf("Choix invalide\n"); continue;
}
```

**Modifications effectuées** :
1. `strtol()` avec contrôle que la chaîne est intégralement consommée.
2. Distinction entre entrée invalide et fermeture de `stdin`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
strtol() distingue l'échec du succès, et l'exigence *end == '\0' rejette les
entrées partiellement numériques comme "12abc".

read_line() consommant la ligne entière, aucun caractère résiduel ne peut
provoquer une itération identique : la progression de la boucle est garantie.
Le traitement de l'EOF assure la terminaison avec une entrée redirigée, ce qui
rend l'analyse Valgrind possible.
```

**Tests effectués** :
```bash
printf 'A\nabc\nzzz\n0\n' | timeout 5 ./secure | grep -c "Choix invalide"
# Obtenu : 2, puis "Au revoir!" avant le timeout
```

---

## 3. TESTS DE VALIDATION <a name="tests"></a>

### 3.1 Compilation

**Commande utilisée** :
```bash
gcc -o secure secure.c -Wall -Wextra -O2 -g -fstack-protector-all -D_FORTIFY_SOURCE=2
```

**Résultat** :
```
$ gcc -o secure secure.c -Wall -Wextra -O2 -g -fstack-protector-all -D_FORTIFY_SOURCE=2
$ echo $?
0
```
Aucune sortie : ni avertissement, ni erreur. `-lcrypto` n'est pas nécessaire, aucune fonction OpenSSL n'étant utilisée. `-O2` a été ajouté au Makefile car `-D_FORTIFY_SOURCE=2` est inactif sans optimisation.

**Nombre de warnings** : 0  
**Nombre d'erreurs** : 0

---

### 3.2 Tests fonctionnels

| Fonctionnalité | Test effectué | Résultat |
|---------------|---------------|----------|
| Création utilisateur | Tentative avec nom très long (500 caractères) | ☑ OK ☐ KO |
| Connexion | Login avec mauvais credentials | ☑ OK ☐ KO |
| Transfert | Montant négatif | ☑ OK ☐ KO |
| Backup | Nom de fichier avec `../` | ☑ OK ☐ KO |
| Commande système | Injection avec `;` | ☐ OK ☑ KO |

---

### 3.3 Analyse mémoire (Valgrind)

**Commande** :
```bash
rm -f bkp.txt
valgrind --leak-check=full --show-leak-kinds=all ./secure < test_inputs.txt
```

**Résultat** :
```
[Collez la sortie de valgrind]
```

**Fuites détectées** : _____ bytes  
**Blocs non libérés** : _____

---

### 3.4 Tests de sécurité

**Test 1 - Buffer Overflow**
```bash
# Entrée testée : { echo "A"; echo "1"; printf 'X%.0s' $(seq 1 500); echo; echo "0"; } | ./secure
# Résultat attendu : rejet de l'entrée, aucun crash
# Résultat obtenu : "Saisie invalide", retour au menu, code de sortie 0
```

**Test 2 - Format String**
```bash
# Entrée testée : printf 'A\n1\nbob\np1\np1\n2\nbob\np1\n3\n%x %x %n\n0\n' | ./secure
# Résultat attendu : chaîne affichée littéralement
# Résultat obtenu : "%x %x %n" affiché tel quel, aucune directive interprétée
```

**Test 3 - Command Injection**
```bash
# Entrée testée : printf 'A\n2\nadmin\nA\n7\nls ; cat /etc/passwd\n0\n' | ./secure
# Résultat attendu : rejet de la commande
# Résultat obtenu : les deux commandes s'exécutent -> non corrigé, voir 4.3
```

---

## 4. CONCLUSION <a name="conclusion"></a>

### 4.1 Résumé des corrections

**Statistiques** :
- Vulnérabilités CRITIQUES corrigées : 8
- Vulnérabilités HAUTES corrigées : 2
- Vulnérabilités MOYENNES corrigées : 0
- Total de lignes modifiées : ~280 (154 ajoutées, 126 supprimées, soit 402 → 430 lignes)

**Principaux changements** :
1. Toutes les lectures passent par `read_line()` et `read_int()` : plus aucun `gets`, `scanf`, `strcpy` ni `sprintf`.
2. Contrôle d'accès centralisé, `admin_flag` inaccessible depuis les entrées, backdoor et identifiants en dur supprimés.
3. Validation des transferts, noms de fichiers en liste blanche, `malloc()` vérifié et `cleanup()` sur tous les chemins de sortie.

---

### 4.2 Difficultés rencontrées

**Problème 1** :
```
strncpy() ne garantit pas la terminaison de chaîne. Les consignes le
recommandent pour remplacer strcpy(), mais il n'écrit pas de '\0' si la source
fait au moins n caractères : on corrige le débordement d'écriture en créant une
lecture hors bornes.

Résolu par snprintf(dst, sizeof(dst), "%s", src) partout, qui borne l'écriture
ET garantit le terminateur.
```

**Problème 2** :
```
Désynchronisation des entrées. La première version utilisait scanf("%15s")
comme suggéré ; les caractères excédentaires restaient dans le tampon et
étaient consommés par la lecture suivante, rendant les enchaînements de menus
imprévisibles.

Résolu par une lecture orientée ligne avec vidage explicite du reste, plus un
traitement de l'EOF sans lequel le programme boucle indéfiniment avec une
entrée redirigée — ce qui empêchait aussi toute analyse Valgrind.
```

---

### 4.3 Améliorations possibles

**Sécurité** :
- [ ] Implémenter un système de salage pour les mots de passe
- [ ] Ajouter des logs de sécurité
- [ ] Limiter le nombre de tentatives de connexion
- [ ] Implémenter un système de sessions avec timeout
- [x] Autre : **deux vulnérabilités identifiées mais non corrigées dans cette version**

```
1) Mots de passe en clair et hachage faible (#11 du tableau). Ils restent
   stockés en clair dans la structure User, et hash_password() (DJB2, 32 bits,
   sans sel, jamais appelée) n'a pas été remplacée.
   Correction attendue : SHA-256 via EVP_Digest() d'OpenSSL sur un sel
   aléatoire de 16 octets par utilisateur, suppression du champ password,
   comparaison par CRYPTO_memcmp() contre les attaques temporelles.

2) Injection de commande (#12 du tableau). system_command() concatène toujours
   la saisie dans une chaîne passée à system(). Le débordement de tampon a été
   corrigé, pas l'injection. Le menu 7 exige les droits admin et
   l'auto-attribution est impossible (corrections #2 et #7), donc seul
   l'administrateur peut l'exploiter, mais la faille subsiste.
   Correction attendue : liste blanche fermée de commandes, la chaîne exécutée
   étant une constante du programme ; mieux encore fork() + execvp(), qui
   supprime le shell.
```

**Fonctionnalité** :
- [ ] Chiffrement des données sensibles
- [ ] Audit trail complet
- [ ] Protection contre les timing attacks
- [x] Autre : persistance des comptes, structure dynamique à la place du tableau fixe de 20 comptes, soldes exprimés en centimes

---

### 4.4 Apprentissages clés

**Ce que j'ai appris** :
1. Le remplacement mécanique des fonctions dangereuses ne suffit pas : les failles les plus rentables de ce programme sont des défauts de logique (montant négatif, auto-attribution du drapeau admin) qui n'apparaissent dans aucune liste de fonctions interdites.
2. Les vulnérabilités se combinent : aucune n'est aussi grave isolément que la chaîne complète, auto-attribution des droits admin → menu 7 → injection de commande → exécution de code.
3. Les conseils de correction courants sont parfois faux : `strncpy()` et `scanf("%15s")` sont présentés comme sûrs mais introduisent chacun un nouveau défaut. Et une décision de sécurité ne doit jamais dépendre d'une donnée fournie par la partie qu'elle contraint.

**Compétences développées** :
- [x] Identification de vulnérabilités
- [x] Utilisation de fonctions sécurisées
- [x] Validation d'entrées
- [x] Gestion mémoire rigoureuse
- [ ] Cryptographie appliquée

---

### 4.5 Auto-évaluation

| Critère | Note estimée /20 | Justification |
|---------|------------------|---------------|
| Analyse | 3 /6 | 12 vulnérabilités identifiées avec ligne, type et gravité, mais le tableau reste sous le seuil de 25 demandé par les consignes. |
| Corrections | 6 /10 | Compilation sans warning, mémoire libérée, fonctionnalités préservées, 10 vulnérabilités corrigées dont 8 critiques. Points retirés : SHA-256 et injection de commande non traités. |
| Documentation | 3 /4 | Les quatre sections obligatoires sont présentes pour chaque correction, avec exemple d'exploitation, code avant/après et test reproductible. Rédaction concise. |
| **TOTAL** | **12 /20** | |

---

## ANNEXES

### Annexe A : Checklist de vérification finale

- [x] Tous les `gets()` remplacés par `fgets()`
- [x] Tous les `scanf("%s")` sécurisés avec taille maximale. Exemp,le : `scanf("%19s", buffer)` pour un buffer de 20 bytes
- [x] Tous les `strcpy()` remplacés par `strncpy()` — remplacés par `snprintf()`, voir correction #6
- [x] Tous les `strcat()` remplacés par `strncat()` — aucun `strcat` dans le code original
- [x] Tous les `sprintf()` remplacés par `snprintf()`
- [ ] Cryptographie utilise SHA-256 — non implémenté, voir 4.3
- [ ] Pas de mots de passe en clair — non corrigé, voir 4.3
- [x] Pas de backdoors
- [x] Tous les indices de tableaux validés
- [x] Tous les `malloc()` ont un `free()` correspondant
- [ ] 0 fuites mémoire (valgrind) — à confirmer, voir 3.3
- [x] 0 warnings de compilation
- [x] Validation stricte des noms de fichiers
- [ ] Protection contre command injection — non corrigé, voir 4.3

### Annexe B : Références utilisées

1. `man 3 fgets`, `man 3 snprintf`, `man 3 strncpy`, `man 3 strtol`, `man 2 open`
2. OWASP Top 10 — A01 Broken Access Control, A03 Injection, A07 Identification and Authentication Failures
3. CWE-120, CWE-134, CWE-22, CWE-798, CWE-269, CWE-190 · ISO/IEC 9899:2011 (retrait de `gets()`)

---

**FIN DU RAPPORT**
