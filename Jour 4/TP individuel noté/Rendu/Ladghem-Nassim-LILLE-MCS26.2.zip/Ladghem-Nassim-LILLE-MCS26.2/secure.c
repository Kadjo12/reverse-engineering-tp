#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>

#if defined(__unix__) || defined(__APPLE__)
#include <termios.h>
#include <unistd.h>
#define HAVE_TERMIOS 1
#endif

#define MAX_USERS 20
#define MAX_SESSIONS 10
#define USERNAME_MAX 15          /* taille utile, +1 pour le \0 */
#define TOKEN_MAX 31
#define SALT_LEN 16              /* octets de sel bruts        */
#define SALT_HEX_LEN (SALT_LEN * 2)
#define HASH_HEX_LEN 64          /* SHA-256 -> 64 caracteres hexa */
#define MAX_LOGIN_ATTEMPTS 5
#define BACKUP_DIR "backups"

typedef struct {
    char username[USERNAME_MAX + 1];
    char password_hash[HASH_HEX_LEN + 1]; /* SHA-256(salt || password) en hexa */
    char salt[SALT_HEX_LEN + 1];          /* sel unique par utilisateur, en hexa */
    int  admin_flag;
    int  balance;
    char token[TOKEN_MAX + 1];
    int  failed_attempts;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;


typedef struct {
    uint32_t state[8];
    uint64_t bitlen;
    unsigned char data[64];
    unsigned int datalen;
} SHA256_CTX;

static const uint32_t sha256_k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

#define ROTR(x,n) (((x) >> (n)) | ((x) << (32 - (n))))

static void sha256_transform(SHA256_CTX *ctx, const unsigned char data[]) {
    uint32_t a,b,c,d,e,f,g,h,t1,t2,m[64];
    unsigned int i, j;

    for (i = 0, j = 0; i < 16; ++i, j += 4)
        m[i] = ((uint32_t)data[j] << 24) | ((uint32_t)data[j+1] << 16) |
               ((uint32_t)data[j+2] << 8) | ((uint32_t)data[j+3]);
    for (; i < 64; ++i) {
        uint32_t s0 = ROTR(m[i-15],7) ^ ROTR(m[i-15],18) ^ (m[i-15] >> 3);
        uint32_t s1 = ROTR(m[i-2],17) ^ ROTR(m[i-2],19) ^ (m[i-2] >> 10);
        m[i] = m[i-16] + s0 + m[i-7] + s1;
    }

    a=ctx->state[0]; b=ctx->state[1]; c=ctx->state[2]; d=ctx->state[3];
    e=ctx->state[4]; f=ctx->state[5]; g=ctx->state[6]; h=ctx->state[7];

    for (i = 0; i < 64; ++i) {
        uint32_t S1 = ROTR(e,6) ^ ROTR(e,11) ^ ROTR(e,25);
        uint32_t ch = (e & f) ^ (~e & g);
        t1 = h + S1 + ch + sha256_k[i] + m[i];
        uint32_t S0 = ROTR(a,2) ^ ROTR(a,13) ^ ROTR(a,22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        t2 = S0 + maj;
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }

    ctx->state[0]+=a; ctx->state[1]+=b; ctx->state[2]+=c; ctx->state[3]+=d;
    ctx->state[4]+=e; ctx->state[5]+=f; ctx->state[6]+=g; ctx->state[7]+=h;
}

static void sha256_init(SHA256_CTX *ctx) {
    ctx->datalen = 0;
    ctx->bitlen = 0;
    ctx->state[0]=0x6a09e667; ctx->state[1]=0xbb67ae85;
    ctx->state[2]=0x3c6ef372; ctx->state[3]=0xa54ff53a;
    ctx->state[4]=0x510e527f; ctx->state[5]=0x9b05688c;
    ctx->state[6]=0x1f83d9ab; ctx->state[7]=0x5be0cd19;
}

static void sha256_update(SHA256_CTX *ctx, const unsigned char data[], size_t len) {
    for (size_t i = 0; i < len; ++i) {
        ctx->data[ctx->datalen] = data[i];
        ctx->datalen++;
        if (ctx->datalen == 64) {
            sha256_transform(ctx, ctx->data);
            ctx->bitlen += 512;
            ctx->datalen = 0;
        }
    }
}

static void sha256_final(SHA256_CTX *ctx, unsigned char hash[]) {
    unsigned int i = ctx->datalen;

    if (ctx->datalen < 56) {
        ctx->data[i++] = 0x80;
        while (i < 56) ctx->data[i++] = 0x00;
    } else {
        ctx->data[i++] = 0x80;
        while (i < 64) ctx->data[i++] = 0x00;
        sha256_transform(ctx, ctx->data);
        memset(ctx->data, 0, 56);
    }

    ctx->bitlen += (uint64_t)ctx->datalen * 8;
    ctx->data[63] = (unsigned char)(ctx->bitlen);
    ctx->data[62] = (unsigned char)(ctx->bitlen >> 8);
    ctx->data[61] = (unsigned char)(ctx->bitlen >> 16);
    ctx->data[60] = (unsigned char)(ctx->bitlen >> 24);
    ctx->data[59] = (unsigned char)(ctx->bitlen >> 32);
    ctx->data[58] = (unsigned char)(ctx->bitlen >> 40);
    ctx->data[57] = (unsigned char)(ctx->bitlen >> 48);
    ctx->data[56] = (unsigned char)(ctx->bitlen >> 56);
    sha256_transform(ctx, ctx->data);

    for (i = 0; i < 4; ++i) {
        for (int j = 0; j < 8; ++j) {
            hash[j*4 + i] = (unsigned char)((ctx->state[j] >> (24 - i*8)) & 0xff);
        }
    }
}

static void bytes_to_hex(const unsigned char *bytes, size_t len, char *out_hex) {
    static const char hexchars[] = "0123456789abcdef";
    for (size_t i = 0; i < len; ++i) {
        out_hex[i*2]     = hexchars[(bytes[i] >> 4) & 0xF];
        out_hex[i*2 + 1] = hexchars[bytes[i] & 0xF];
    }
    out_hex[len*2] = '\0';
}

/* Hash = SHA256(salt_hex || password), stocke en hexa (65 caracteres) */
static void hash_password_salted(const char *password, const char *salt_hex, char *out_hex65) {
    SHA256_CTX ctx;
    unsigned char digest[32];
    sha256_init(&ctx);
    sha256_update(&ctx, (const unsigned char *)salt_hex, strlen(salt_hex));
    sha256_update(&ctx, (const unsigned char *)password, strlen(password));
    sha256_final(&ctx, digest);
    bytes_to_hex(digest, 32, out_hex65);
}

/* FIX #10 : remplace le hash "maison" (djb2, non cryptographique et
 * jamais utilise dans le code d'origine) par un vrai SHA-256 sale,
 * reellement utilise pour stocker les mots de passe. */
static void generate_salt_hex(char *out_hex) {
    unsigned char raw[SALT_LEN];
    FILE *urandom = fopen("/dev/urandom", "rb");
    if (urandom) {
        if (fread(raw, 1, SALT_LEN, urandom) != SALT_LEN) {
            /* Repli degrade si la lecture echoue malgre l'ouverture */
            for (int i = 0; i < SALT_LEN; ++i) raw[i] = (unsigned char)(rand() & 0xFF);
        }
        fclose(urandom);
    } else {
        /* Repli si /dev/urandom est indisponible (portabilite) :
         * moins fort cryptographiquement, mais evite un crash. */
        for (int i = 0; i < SALT_LEN; ++i) raw[i] = (unsigned char)(rand() & 0xFF);
    }
    bytes_to_hex(raw, SALT_LEN, out_hex);
}

/* Comparaison en temps constant pour eviter les attaques par timing
 * sur la comparaison de hash / mot de passe. */
static int constant_time_equal(const char *a, const char *b) {
    size_t la = strlen(a), lb = strlen(b);
    if (la != lb) return 0;
    unsigned char diff = 0;
    for (size_t i = 0; i < la; ++i) diff |= (unsigned char)(a[i] ^ b[i]);
    return diff == 0;
}

/* ==========================================================================
 * Entrees utilisateur securisees (remplacent gets()/scanf("%s")/scanf("%d"))
 * ========================================================================== */

/* FIX #1, #2, #5, #7 : gets() est intrinsequement dangereux (aucune limite
 * de taille, retire du C11) et scanf("%s") ne borne jamais la taille lue.
 * On utilise fgets() qui prend explicitement la taille du buffer. */
static int safe_read_line(char *buf, size_t size) {
    if (fgets(buf, (int)size, stdin) == NULL) {
        buf[0] = '\0';
        return -1;
    }
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        /* La ligne depassait le buffer : on vide le reste du flux
         * pour ne pas polluer la prochaine lecture. */
        int c;
        while ((c = getchar()) != '\n' && c != EOF) { }
    }
    return 0;
}

static int safe_read_int(long *out) {
    char buf[32];
    if (safe_read_line(buf, sizeof(buf)) != 0) return -1;

    char *endptr;
    errno = 0;
    long val = strtol(buf, &endptr, 10);
    if (endptr == buf || *endptr != '\0' || errno == ERANGE) return -1;
    *out = val;
    return 0;
}

#ifdef HAVE_TERMIOS
static void set_echo(int enable) {
    struct termios tty;
    if (tcgetattr(STDIN_FILENO, &tty) != 0) return;
    if (enable) tty.c_lflag |= ECHO;
    else        tty.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &tty);
}
#else
static void set_echo(int enable) { (void)enable; }
#endif

/* Lit un mot de passe sans l'afficher a l'ecran quand c'est possible. */
static int safe_read_password(char *buf, size_t size) {
    set_echo(0);
    int r = safe_read_line(buf, size);
    set_echo(1);
    printf("\n");
    return r;
}

/* Un nom d'utilisateur ne doit contenir que des caracteres "surs" :
 * cela evite d'injecter ':' ou '\n' dans le fichier de backup
 * (FIX #4) et des caracteres de controle dans le token (FIX #1). */
static int is_valid_username(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len > USERNAME_MAX) return 0;
    for (size_t i = 0; i < len; ++i) {
        if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-') return 0;
    }
    return 1;
}

/* Un nom de fichier de sauvegarde ne doit pas permettre de sortir du
 * repertoire de backup (FIX #4 : Path Traversal). */
static int is_valid_backup_name(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len > 40) return 0;
    if (strstr(s, "..") != NULL) return 0;
    if (strchr(s, '/') != NULL || strchr(s, '\\') != NULL) return 0;
    if (s[0] == '.') return 0;
    for (size_t i = 0; i < len; ++i) {
        if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-' && s[i] != '.') return 0;
    }
    return 1;
}

/* ==========================================================================
 * Logique metier
 * ========================================================================== */

static int find_user_by_username(const char *username) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) return i;
    }
    return -1;
}


static void register_user(void) {
    char username[64];
    char password[64];
    char confirm[64];

    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    if (safe_read_line(username, sizeof(username)) != 0) return;

    if (!is_valid_username(username)) {
        printf("Username invalide (1-%d caracteres alphanumeriques, '_' ou '-').\n", USERNAME_MAX);
        return;
    }
    if (find_user_by_username(username) != -1) {
        printf("Ce nom d'utilisateur existe deja.\n");
        return;
    }

    printf("Password: ");
    if (safe_read_password(password, sizeof(password)) != 0) return;
    if (strlen(password) < 8) {
        printf("Le mot de passe doit contenir au moins 8 caracteres.\n");
        return;
    }

    printf("Confirmer password: ");
    if (safe_read_password(confirm, sizeof(confirm)) != 0) return;
    if (!constant_time_equal(password, confirm)) {
        printf("Les mots de passe ne correspondent pas.\n");
        return;
    }

    strcpy(users[user_count].username, username); /* taille verifiee ci-dessus */
    generate_salt_hex(users[user_count].salt);
    hash_password_salted(password, users[user_count].salt, users[user_count].password_hash);
    users[user_count].admin_flag = 0;   /* FIX #9 : jamais accorde a l'inscription */
    users[user_count].balance = 100;
    users[user_count].failed_attempts = 0;

    /* FIX #1 (suite) : snprintf borne strictement a la taille du buffer,
     * plus de malloc(32) potentiellement trop petit pour username long. */
    snprintf(users[user_count].token, sizeof(users[user_count].token),
             "TOK_%d_%.10s", user_count, username);

    /* Efface les mots de passe en clair de la pile des qu'ils ne sont
     * plus necessaires. */
    memset(password, 0, sizeof(password));
    memset(confirm, 0, sizeof(confirm));

    user_count++;
    printf("Utilisateur enregistre !\n");
}

/* FIX #7 (partiel) : login utilise desormais la comparaison de hash
 * en temps constant, plus de mot de passe en clair compare. Ajoute
 * un compteur de tentatives echouees (anti brute-force, bonus). */
static int login_user(const char *username, const char *password) {
    int idx = find_user_by_username(username);
    if (idx == -1) return -1;

    if (users[idx].failed_attempts >= MAX_LOGIN_ATTEMPTS) {
        printf("Compte temporairement verrouille (trop de tentatives).\n");
        return -1;
    }

    char computed[HASH_HEX_LEN + 1];
    hash_password_salted(password, users[idx].salt, computed);

    if (constant_time_equal(computed, users[idx].password_hash)) {
        users[idx].failed_attempts = 0;
        return idx;
    }
    users[idx].failed_attempts++;
    return -1;
}

/* FIX #2 : suppression totale de gets() et de printf(format) avec un
 * format fourni par l'utilisateur (format string attack). L'utilisateur
 * peut toujours saisir un texte libre, mais il est toujours affiche
 * via "%s", jamais interprete comme chaine de format. */
static void show_profile(int user_id) {
    char note[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d EUR\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Note libre (affichage brut, non interprete) : ");
    if (safe_read_line(note, sizeof(note)) == 0) {
        printf("%s\n", note); /* FIX #2 : jamais printf(note) */
    }
}

/* FIX #3 : montant valide (positif, non nul), verification du solde
 * source suffisant, protection contre le depassement d'entier sur le
 * solde destinataire, et transfert vers soi-meme interdit. */
static void transfer_money(int from_user) {
    char to_username[64];
    long amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    if (safe_read_line(to_username, sizeof(to_username)) != 0) return;

    int to_idx = find_user_by_username(to_username);
    if (to_idx == -1) {
        printf("Utilisateur destinataire introuvable\n");
        return;
    }
    if (to_idx == from_user) {
        printf("Impossible de transferer vers son propre compte.\n");
        return;
    }

    printf("Montant: ");
    if (safe_read_int(&amount) != 0 || amount <= 0) {
        printf("Montant invalide.\n");
        return;
    }
    if (amount > users[from_user].balance) {
        printf("Solde insuffisant.\n");
        return;
    }
    if (users[to_idx].balance > INT_MAX - (int)amount) {
        printf("Operation refusee (depassement de solde destinataire).\n");
        return;
    }

    users[from_user].balance -= (int)amount;
    users[to_idx].balance += (int)amount;
    printf("Transfert effectue !\n");
}

/* Cree le repertoire de backup s'il n'existe pas (best effort). */
static void ensure_backup_dir(void) {
#if defined(__unix__) || defined(__APPLE__)
    system("mkdir -p " BACKUP_DIR); /* commande fixe, aucune donnee utilisateur */
#else
    (void)0;
#endif
}

/* FIX #4 : le nom de fichier est valide par une liste blanche stricte
 * (pas de '/', pas de '..'), et le chemin final est toujours construit
 * a l'interieur du repertoire BACKUP_DIR : impossible d'ecrire ou de
 * lire en dehors de ce repertoire (Path Traversal corrige). Le mot de
 * passe en clair n'est plus jamais ecrit sur disque : seul le hash
 * (non reversible) est sauvegarde. */
static void backup_user_data(int user_id) {
    char filename[64];
    char path[128];
    FILE *fp;

    ensure_backup_dir();

    printf("Nom du fichier de backup (sans chemin): ");
    if (safe_read_line(filename, sizeof(filename)) != 0) return;

    if (!is_valid_backup_name(filename)) {
        printf("Nom de fichier invalide.\n");
        return;
    }

    int n = snprintf(path, sizeof(path), "%s/%s", BACKUP_DIR, filename);
    if (n < 0 || (size_t)n >= sizeof(path)) {
        printf("Chemin trop long.\n");
        return;
    }

    fp = fopen(path, "w");
    if (fp) {
        fprintf(fp, "%s:%s:%d:%d\n",
                users[user_id].username,
                users[user_id].password_hash,   /* jamais le mot de passe en clair */
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup cree dans %s\n", path);
    } else {
        printf("Impossible de creer le fichier de backup.\n");
    }
}

/* FIX #4 (suite) : meme sanitation appliquee a la restauration, qui
 * dans le code d'origine permettait de lire n'importe quel fichier du
 * systeme (ex: /etc/passwd) via un chemin absolu ou relatif. */
static void restore_user_data(void) {
    char filename[64];
    char path[128];
    char buffer[256];
    FILE *fp;

    printf("Fichier a restaurer (sans chemin, dans %s/) : ", BACKUP_DIR);
    if (safe_read_line(filename, sizeof(filename)) != 0) return;

    if (!is_valid_backup_name(filename)) {
        printf("Nom de fichier invalide.\n");
        return;
    }

    int n = snprintf(path, sizeof(path), "%s/%s", BACKUP_DIR, filename);
    if (n < 0 || (size_t)n >= sizeof(path)) {
        printf("Chemin trop long.\n");
        return;
    }

    fp = fopen(path, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        return;
    }

    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

/* FIX #5 : la fonctionnalite "commande systeme arbitraire" est
 * supprimee. Il n'existe aucune facon sure de passer une chaine
 * fournie par l'utilisateur a system()/exec*() sans ouvrir une
 * injection de commande : meme avec un filtrage de caracteres, on
 * recree en general un moyen de contournement. La bonne pratique est
 * de ne jamais exposer ce genre de fonctionnalite. On la remplace ici
 * par une action fixe et inoffensive, sans donnee utilisateur. */
static void show_server_time(void) {
    time_t now = time(NULL);
    printf("=== INFORMATION SERVEUR ===\n");
    printf("Heure serveur : %s", ctime(&now));
}

/* FIX #6 : restreinte aux administrateurs, longueur de username
 * validee et verifiee unique avant strcpy (le buffer source et la
 * cible ont maintenant des tailles coherentes et verifiees). */
static void clone_user(int source_id) {
    char target_username[64];

    if (!users[source_id].admin_flag) {
        printf("Acces refuse : reserve aux administrateurs.\n");
        return;
    }
    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }

    printf("Nom du clone: ");
    if (safe_read_line(target_username, sizeof(target_username)) != 0) return;

    if (!is_valid_username(target_username)) {
        printf("Username invalide.\n");
        return;
    }
    if (find_user_by_username(target_username) != -1) {
        printf("Ce nom d'utilisateur existe deja.\n");
        return;
    }

    strcpy(users[user_count].username, target_username); /* taille verifiee */
    strcpy(users[user_count].password_hash, users[source_id].password_hash);
    strcpy(users[user_count].salt, users[source_id].salt);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;
    users[user_count].failed_attempts = 0;
    snprintf(users[user_count].token, sizeof(users[user_count].token),
             "TOK_%d_%.10s", user_count, target_username);

    user_count++;
    printf("Clone cree\n");
}

static void list_users(void) {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d EUR, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

/* FIX #7 : suppression totale du mot de passe maitre codé en dur
 * "master_reset_2024" (porte derobee). Plus de gets(). Verification
 * de l'ancien mot de passe via hash + comparaison en temps constant.
 * Nouveau mot de passe soumis aux memes exigences qu'a l'inscription. */
static void change_password(int user_id) {
    char old_pass[64];
    char new_pass[64];
    char confirm[64];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    if (safe_read_password(old_pass, sizeof(old_pass)) != 0) return;

    char computed[HASH_HEX_LEN + 1];
    hash_password_salted(old_pass, users[user_id].salt, computed);

    if (!constant_time_equal(computed, users[user_id].password_hash)) {
        printf("Ancien mot de passe incorrect\n");
        memset(old_pass, 0, sizeof(old_pass));
        return;
    }

    printf("Nouveau mot de passe: ");
    if (safe_read_password(new_pass, sizeof(new_pass)) != 0) return;
    if (strlen(new_pass) < 8) {
        printf("Le mot de passe doit contenir au moins 8 caracteres.\n");
        return;
    }
    printf("Confirmer nouveau mot de passe: ");
    if (safe_read_password(confirm, sizeof(confirm)) != 0) return;
    if (!constant_time_equal(new_pass, confirm)) {
        printf("Les mots de passe ne correspondent pas.\n");
        return;
    }

    generate_salt_hex(users[user_id].salt); /* nouveau sel a chaque changement */
    hash_password_salted(new_pass, users[user_id].salt, users[user_id].password_hash);

    memset(old_pass, 0, sizeof(old_pass));
    memset(new_pass, 0, sizeof(new_pass));
    memset(confirm, 0, sizeof(confirm));

    printf("Mot de passe change\n");
}

/* FIX #8 : protection contre la division par zero si user_count == 0.
 * sprintf remplace par snprintf par coherence defensive generale. */
static void compute_stats(void) {
    if (user_count == 0) {
        printf("Aucun utilisateur enregistre.\n");
        return;
    }

    long total = 0;
    for (int i = 0; i < user_count; i++) total += users[i].balance;

    double avg = (double)total / user_count;

    char buffer[120];
    snprintf(buffer, sizeof(buffer), "Total: %ld EUR, Moyenne: %.2f EUR", total, avg);
    printf("%s\n", buffer);
}

static void search_user(void) {
    char query[64];

    printf("Rechercher: ");
    if (safe_read_line(query, sizeof(query)) != 0) return;

    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouve: %s\n", users[i].username);
        }
    }
}

static void cleanup_sessions(void) {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600) {
            printf("Session %d expiree\n", i);
        }
    }
}

static void display_menu(void) {
    printf("\n=======================================\n");
    printf("   SYSTEME DE GESTION BANCAIRE (SECURISE)\n");
    printf("=======================================\n");
    printf(" 1. Creer compte\n");
    printf(" 2. Se connecter\n");
    printf(" 3. Voir profil\n");
    printf(" 4. Transferer argent\n");
    printf(" 5. Backup donnees\n");
    printf(" 6. Restaurer donnees\n");
    printf(" 7. Info serveur (admin)\n");     /* remplace la commande systeme */
    printf(" 8. Cloner utilisateur (admin)\n");
    printf(" 9. Liste utilisateurs\n");
    printf(" 10. Changer mot de passe\n");
    printf(" 11. Statistiques\n");
    printf(" 12. Rechercher utilisateur\n");
    printf(" 0. Quitter\n");
    printf("=======================================\n");
    printf("Choix: ");
}

/* FIX #9 : plus de compte admin/admin123 code en dur. Le premier
 * lancement force la creation interactive d'un compte administrateur
 * avec un mot de passe choisi (et valide) par l'operateur. */
static void create_initial_admin(void) {
    char username[64], password[64], confirm[64];

    printf("=== INITIALISATION : creation du compte administrateur ===\n");
    for (;;) {
        printf("Username admin: ");
        if (safe_read_line(username, sizeof(username)) != 0) continue;
        if (is_valid_username(username)) break;
        printf("Username invalide.\n");
    }

    for (;;) {
        printf("Mot de passe admin (8 caracteres min): ");
        if (safe_read_password(password, sizeof(password)) != 0) continue;
        if (strlen(password) < 8) { printf("Trop court.\n"); continue; }
        printf("Confirmer: ");
        if (safe_read_password(confirm, sizeof(confirm)) != 0) continue;
        if (constant_time_equal(password, confirm)) break;
        printf("Les mots de passe ne correspondent pas.\n");
    }

    strcpy(users[0].username, username);
    generate_salt_hex(users[0].salt);
    hash_password_salted(password, users[0].salt, users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].failed_attempts = 0;
    snprintf(users[0].token, sizeof(users[0].token), "TOK_0_%.10s", username);

    memset(password, 0, sizeof(password));
    memset(confirm, 0, sizeof(confirm));

    user_count = 1;
    printf("Compte administrateur cree.\n");
}

int main(void) {
    long choice;
    int logged_user = -1;
    char username[64], password[64];

    srand((unsigned int)time(NULL)); /* seed de repli pour generate_salt_hex */

    printf("=========================================\n");
    printf(" TP FINAL NOTE - VERSION SECURISEE\n");
    printf("=========================================\n\n");

    create_initial_admin();

    while (1) {
        display_menu();
        if (safe_read_int(&choice) != 0) {
            printf("Choix invalide\n");
            continue;
        }

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                if (safe_read_line(username, sizeof(username)) != 0) break;
                printf("Password: ");
                if (safe_read_password(password, sizeof(password)) != 0) break;
                logged_user = login_user(username, password);
                memset(password, 0, sizeof(password));
                if (logged_user >= 0) {
                    printf("Connecte en tant que %s\n", users[logged_user].username);
                } else {
                    printf("Echec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) show_profile(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 4:
                if (logged_user >= 0) transfer_money(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 5:
                if (logged_user >= 0) backup_user_data(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 6:
                if (logged_user >= 0) restore_user_data();
                else printf("Veuillez vous connecter\n");
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) show_server_time();
                else printf("Acces refuse\n");
                break;
            case 8:
                if (logged_user >= 0) clone_user(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) change_password(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir !\n");
                return 0;
            default:
                printf("Choix invalide\n");
        }
        cleanup_sessions();
    }
}
