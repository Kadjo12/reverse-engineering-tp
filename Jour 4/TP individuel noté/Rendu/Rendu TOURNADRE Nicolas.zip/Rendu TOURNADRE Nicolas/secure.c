/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Durée : 4 heures
 *
 * CONSIGNE : Ce programme contient de NOMBREUSES vulnérabilités.
 * Vous devez les identifier, les corriger et documenter chaque correction.
 *
 * Système de gestion de comptes utilisateurs avec authentification
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

typedef struct {
    char username[16];
    char password[16];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

/* Lecture bornée d'une ligne. */
int read_line(char *buffer, size_t size) {
    int c;

    if (fgets(buffer, size, stdin) == NULL)
        return 0;

    if (strchr(buffer, '\n') != NULL) {
        buffer[strcspn(buffer, "\n")] = '\0';
        return 1;
    }

    while ((c = getchar()) != '\n' && c != EOF) {}
    return -1;
}

/* Lit un entier valide sans laisser de caractères dans l'entrée. */
int read_int(int *value) {
    char input[32];
    char *end;
    long number;

    if (read_line(input, sizeof(input)) != 1)
        return 0;

    errno = 0;
    number = strtol(input, &end, 10);
    if (errno != 0 || *end != '\0' || number < INT_MIN || number > INT_MAX)
        return 0;

    *value = (int)number;
    return 1;
}

/* Copie une chaîne seulement si elle tient dans la destination. */
int safe_copy(char *destination, size_t size, const char *source) {
    if (strlen(source) >= size)
        return 0;

    strncpy(destination, source, size - 1);
    destination[size - 1] = '\0';
    return 1;
}

/* Vérifie un nom : 3 à 15 caractères, lettres, chiffres ou underscore. */
int valid_username(const char *username) {
    size_t length = strlen(username);

    if (length < 3 || length > 15)
        return 0;

    for (size_t i = 0; i < length; i++) {
        if (!isalnum((unsigned char)username[i]) && username[i] != '_')
            return 0;
    }
    return 1;
}

int username_exists(const char *username) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0)
            return 1;
    }
    return 0;
}

/* Mot de passe de 8 à 15 caractères avec au moins une lettre et un chiffre. */
int valid_password(const char *password) {
    size_t length = strlen(password);
    int has_letter = 0;
    int has_digit = 0;

    if (length < 8 || length > 15)
        return 0;

    for (size_t i = 0; i < length; i++) {
        has_letter |= isalpha((unsigned char)password[i]) != 0;
        has_digit |= isdigit((unsigned char)password[i]) != 0;
    }
    return has_letter && has_digit;
}

/* Lit et valide une valeur administrateur égale à 0 ou 1. */
int read_admin(int *admin) {
    char input[16];
    char extra;

    if (read_line(input, sizeof(input)) != 1)
        return 0;

    return sscanf(input, "%d %c", admin, &extra) == 1 &&
           (*admin == 0 || *admin == 1);
}

/* Refuse les chemins et n'accepte qu'un simple nom de fichier. */
int valid_filename(const char *filename) {
    return filename[0] != '\0' &&
           strstr(filename, "..") == NULL &&
           strchr(filename, '/') == NULL &&
           strchr(filename, '\\') == NULL;
}

// Fonction de hashage personnalisée
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;
    while ((c = *pass++))
        h = h * 33 + c;
    return h;
}

// Enregistrement d'un nouvel utilisateur
void register_user() {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[100];
    char password[100];
    char confirm[100];
    int admin;

    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    if (read_line(username, sizeof(username)) != 1) {
        printf("Nom d'utilisateur trop long ou invalide\n");
        return;
    }

    if (!valid_username(username)) {
        printf("Nom invalide : 3 à 15 caractères, lettres, chiffres ou _\n");
        return;
    }

    if (username_exists(username)) {
        printf("Ce nom d'utilisateur existe déjà\n");
        return;
    }

    printf("Password: ");
    if (read_line(password, sizeof(password)) != 1) {
        printf("Mot de passe trop long ou invalide\n");
        return;
    }

    if (!valid_password(password)) {
        printf("Mot de passe invalide : 8 à 15 caractères avec une lettre et un chiffre\n");
        return;
    }

    printf("Confirmer password: ");
    if (read_line(confirm, sizeof(confirm)) != 1 ||
        strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        return;
    }

    printf("Droits admin (1=oui, 0=non): ");
    if (!read_admin(&admin)) {
        printf("Valeur administrateur invalide\n");
        return;
    }

    safe_copy(users[user_count].username,
              sizeof(users[user_count].username), username);
    safe_copy(users[user_count].password,
              sizeof(users[user_count].password), password);

    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;

    users[user_count].token = malloc(32);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation mémoire\n");
        return;
    }

    snprintf(users[user_count].token, 32, "TOK_%d_%s",
             user_count, users[user_count].username);

    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, username) == 0 &&
           strcmp(users[i].password, password) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Format d'affichage personnalisé: ");
    if (read_line(format, sizeof(format)) != 1) {
        printf("Format trop long ou invalide\n");
        return;
    }
    printf("%s", format);
    printf("\n");
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    if (read_line(to_username, sizeof(to_username)) != 1) {
        printf("Nom du destinataire trop long ou invalide\n");
        return;
    }

    printf("Montant: ");
    if (!read_int(&amount) || amount <= 0) {
        printf("Montant invalide\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            if (users[from_user].balance < amount) {
                printf("Solde insuffisant\n");
                return;
            }

            if (users[i].balance > INT_MAX - amount) {
                printf("Montant trop élevé\n");
                return;
            }

            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;

    printf("Nom du fichier de backup: ");
    if (read_line(filename, sizeof(filename)) != 1) {
        printf("Nom du fichier trop long ou invalide\n");
        return;
    }

    if (!valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    fp = fopen(filename, "w");
    if(fp) {
        fprintf(fp, "%s:%s:%d:%d\n",
                users[user_id].username,
                users[user_id].password,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    char buffer[256];
    FILE *fp;

    printf("Fichier à restaurer: ");
    if (read_line(filename, sizeof(filename)) != 1) {
        printf("Nom du fichier trop long ou invalide\n");
        return;
    }

    if (!valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }

    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Les commandes système arbitraires sont désactivées.
void system_command() {
    printf("Commande système désactivée pour des raisons de sécurité\n");
}

// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[30];

    printf("Nom du clone: ");
    if (read_line(target_username, sizeof(target_username)) != 1) {
        printf("Nom du clone trop long ou invalide\n");
        return;
    }

    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }

    if (!safe_copy(users[user_count].username,
                   sizeof(users[user_count].username), target_username) ||
        !safe_copy(users[user_count].password,
                   sizeof(users[user_count].password), users[source_id].password)) {
        printf("Données du clone trop longues\n");
        return;
    }

    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;

    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[80];
    char new_pass[80];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    if (read_line(old_pass, sizeof(old_pass)) != 1) {
        printf("Ancien mot de passe trop long ou invalide\n");
        return;
    }

    if(strcmp(users[user_id].password, old_pass) == 0 ||
       strcmp(old_pass, "master_reset_2024") == 0) {
        printf("Nouveau mot de passe: ");
        if (read_line(new_pass, sizeof(new_pass)) != 1) {
            printf("Nouveau mot de passe trop long ou invalide\n");
            return;
        }

        if (!safe_copy(users[user_id].password,
                       sizeof(users[user_id].password), new_pass)) {
            printf("Mot de passe trop long (15 caractères maximum)\n");
            return;
        }

        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];

    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }

    avg = (double)total / user_count;

    sprintf(buffer, "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];

    printf("Rechercher: ");
    if (read_line(query, sizeof(query)) != 1) {
        printf("Recherche trop longue ou invalide\n");
        return;
    }

    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for(int i = 0; i < session_count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Libère la mémoire allouée aux tokens.
void cleanup() {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    // Compte admin par défaut
    safe_copy(users[0].username, sizeof(users[0].username), "admin");
    safe_copy(users[0].password, sizeof(users[0].password), "admin123");
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(32);
    if (users[0].token == NULL) {
        printf("Erreur d'allocation mémoire\n");
        return EXIT_FAILURE;
    }

    safe_copy(users[0].token, 32, "ADMIN_TOKEN");
    user_count = 1;

    while(1) {
        display_menu();
        scanf("%d", &choice);
        getchar();

        switch(choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                if (read_line(username, sizeof(username)) != 1) {
                    printf("Nom d'utilisateur trop long ou invalide\n");
                    break;
                }

                printf("Password: ");
                if (read_line(password, sizeof(password)) != 1) {
                    printf("Mot de passe trop long ou invalide\n");
                    break;
                }

                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                cleanup();
                printf("Au revoir!\n");
                return EXIT_SUCCESS;
            default:
                printf("Choix invalide\n");
        }
    }

    return 0;
}