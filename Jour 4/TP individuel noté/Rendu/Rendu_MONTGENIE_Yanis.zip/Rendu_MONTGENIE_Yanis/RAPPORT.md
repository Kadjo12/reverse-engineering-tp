# Rapport de sécurité — TP Final

**Etudiant** : MONTGENIE Yanis
**Date** : 30 juillet 2026
**Durée** : 4 heures

> **État d'avancement.** Faute de temps sur les 4 heures, les vulnérabilités Critiques et Hautes ont toutes été corrigées : **34 des 37 vulnérabilités sont traitées**. 3 points moyens/faibles (V#9, V#20, V#37) et les bonus n'ont pas pu être terminés. Le détail de ce qui est fait / non fait figure aussi en tête de `test_inputs.txt`.

---

## Table des matières

1. [Synthèse des vulnérabilités](#synthese)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. Synthèse des vulnérabilités <a name="synthese"></a>

Le programme simule un système bancaire avec authentification. Chaque fonction lit des entrées au clavier, manipule un tableau global d'utilisateurs et, pour certaines, touche au système de fichiers ou au shell. C'est précisément cette surface — entrées non bornées, tableau de taille fixe, appels système — qui concentre les failles.

L'analyse a relevé **37 vulnérabilités**. Le tableau ci-dessous les regroupe par fonction ; les buffers concernés sont tous largement plus petits que les entrées qu'ils acceptent, ce qui explique le nombre de débordements.

| #  | Fonction | Ligne(s) | Type | Gravité | Corrigée |
|----|----------|----------|------|---------|----------|
| 1  | `hash_password` | 39-45 | Cryptographie faible (hash maison djb2) | Haute | ☑ Oui |
| 2  | `register_user` | 61,64,67 | Buffer overflow (`scanf("%s")`) | Critique | ☑ Oui |
| 3  | `register_user` | 72-73 | Débordement de la structure globale (`strcpy`) | Critique | ☑ Oui |
| 4  | `register_user` | 70,74 | Élévation de privilèges (admin auto-attribué) | Critique | ☑ Oui |
| 5  | `register_user` | 67 | Logique : confirmation jamais vérifiée | Faible | ☑ Oui |
| 6  | `register_user` | 77 | `malloc` non vérifié | Moyenne | ☑ Oui |
| 7  | `register_user` | 78 | Heap overflow (`sprintf` token) | Critique | ☑ Oui |
| 8  | `register_user` | 73 | Mot de passe stocké en clair | Haute | ☑ Oui |
| 9  | `login_user` | 87-88 | Comparaison de mot de passe non constante (timing) | Moyenne | ☐ **Non** (différée) |
| 10 | `show_profile` | 96 | Indice `user_id` non validé | Moyenne | ☑ Oui |
| 11 | `show_profile` | 105 | Buffer overflow (`gets`) | Critique | ☑ Oui |
| 12 | `show_profile` | 106 | Format string (`printf(format)`) | Critique | ☑ Oui |
| 13 | `transfer_money` | 117 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 14 | `transfer_money` | 120,124 | Logique : montant négatif / solde non vérifié | Critique | ☑ Oui |
| 15 | `backup_user_data` | 139 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 16 | `backup_user_data` | 141 | Path traversal (écriture arbitraire) | Haute | ☑ Oui |
| 17 | `backup_user_data` | 143-147 | Fuite : mot de passe exporté en clair | Haute | ☑ Oui |
| 18 | `restore_user_data` | 160 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 19 | `restore_user_data` | 162 | Path traversal (lecture arbitraire) | Haute | ☑ Oui |
| 20 | `restore_user_data` | main:361 | Aucune authentification requise | Moyenne | ☐ **Non** (différée) |
| 21 | `system_command` | 181 | Buffer overflow (`gets`) | Critique | ☑ Oui |
| 22 | `system_command` | 183 | Buffer overflow (`sprintf`) | Haute | ☑ Oui |
| 23 | `system_command` | 184 | Injection de commande (`system`) | Critique | ☑ Oui |
| 24 | `clone_user` | 192 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 25 | `clone_user` | 199 | Débordement de la structure globale (`strcpy`) | Haute | ☑ Oui |
| 26 | `clone_user` | 200-202 | Logique : duplication d'argent + de privilèges | Haute | ☑ Oui |
| 27 | `change_password` | 224,229 | Buffer overflow (`gets` ×2) | Critique | ☑ Oui |
| 28 | `change_password` | 227 | Backdoor (mot de passe maître codé en dur) | Critique | ☑ Oui |
| 29 | `change_password` | 230 | Débordement de la structure globale (`strcpy`) | Critique | ☑ Oui |
| 30 | `compute_stats` | 247 | Division par zéro | Faible | ☑ Oui |
| 31 | `compute_stats` | 249 | `sprintf` (borné mais à proscrire) | Faible | ☑ Oui |
| 32 | `search_user` | 258 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 33 | `main` | 310-315 | Identifiants admin codés en dur (`admin123`) | Haute | ☑ Oui |
| 34 | `main` | 320 | DoS : `scanf("%d")` sans vérif → boucle infinie | Moyenne | ☑ Oui |
| 35 | `main` | 329,331 | Buffer overflow (`scanf("%s")`) | Haute | ☑ Oui |
| 36 | `main` / global | 77,314 | Fuite mémoire : tokens jamais libérés | Moyenne | ☑ Oui |
| 37 | `list_users` | 209-215 | Divulgation : aucun contrôle d'accès | Faible | ☐ **Non** (différée) |

**Total identifié : 37. Total corrigé : 34** (3 différées : V#9, V#20, V#37 — voir la section « Vulnérabilités non corrigées »).

Corrigé par gravité : 11/11 critiques, 15/15 hautes, 4/6 moyennes, 4/5 faibles.

---

## 2. Corrections détaillées <a name="corrections"></a>

Les corrections qui se répètent d'une fonction à l'autre (remplacer `gets`, borner `scanf`, remplacer `strcpy`) sont traitées une fois pour toutes dans les corrections 1 à 3, avec la liste exhaustive des occurrences. Les failles plus spécifiques ont chacune leur section. Dans `secure.c`, chaque point est repéré par un commentaire `[FIX …]`.

---

### Correction #1 : Suppression de `gets()`

#### Vulnérabilité originale
**Fonctions concernées** : `show_profile` (105), `system_command` (181), `change_password` (224, 229)

`gets()` lit une ligne sans jamais connaître la taille du tampon de destination. La fonction a été retirée du standard C11 justement pour cette raison : il n'existe aucune façon de l'utiliser sans risque.

```c
char format[80];
gets(format);          // écrit sans limite dans un tampon de 80 octets
```

#### Attaque possible
En saisissant plus de 80 caractères sur la ligne « Format d'affichage personnalisé », l'attaquant écrit au-delà de `format` sur la pile. Avec une charge suffisamment longue, il écrase l'adresse de retour de `show_profile` et détourne l'exécution. Le binaire vulnérable est d'ailleurs signalé par l'éditeur de liens lui-même : *« the `gets' function is dangerous and should not be used »*.

**Impact** : exécution de code arbitraire, déni de service (crash).

####  Correction implémentée
Toutes les lectures passent par un utilitaire unique bâti sur `fgets`, qui ne dépasse jamais la taille du tampon et vide le reste de la ligne si l'entrée est trop longue :

```c
static int read_line(const char *prompt, char *buf, size_t size) {
    if (prompt) { printf("%s", prompt); fflush(stdout); }
    if (fgets(buf, (int)size, stdin) == NULL) return -1;  // EOF
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {                       // ligne plus longue que le tampon
        int c;
        while ((c = getchar()) != '\n' && c != EOF) ;
    }
    return 0;
}
```

####  Justification de sécurité
`fgets` reçoit la taille du tampon en paramètre et écrit au plus `size - 1` octets avant d'ajouter le `\0`. Le débordement devient impossible par construction. Le drainage de fin de ligne évite qu'un reste d'entrée soit interprété comme la réponse suivante — un défaut classique quand on mélange les modes de lecture.

---

### Correction #2 : Bornage de `scanf("%s")`

####  Vulnérabilité originale
**Fonctions concernées** : `register_user` (61, 64, 67), `transfer_money` (117), `backup_user_data` (139), `restore_user_data` (160), `clone_user` (192), `search_user` (258), `main` (329, 331)

`scanf("%s", buf)` s'arrête à la première espace mais pas à la fin du tampon. C'est un `gets()` déguisé.

```c
char username[100];
scanf("%s", username);   // aucune borne
```

####  Attaque possible
Neuf points d'entrée acceptent une chaîne sans limite de longueur. Le plus direct est le menu principal (`main`, ligne 329) : le champ `username[50]` déborde avant même toute authentification.

**Impact** : exécution de code arbitraire, déni de service.

####  Correction implémentée
Chaque `scanf("%s")` est remplacé par un appel à `read_line`, puis l'entrée est validée. Exemple pour l'enregistrement :

```c
if (read_line("Username: ", username, sizeof(username)) != 0) return;
if (!valid_username(username)) {
    printf("Nom invalide (1-%d car., [A-Za-z0-9_-]).\n", USERNAME_MAX_LEN);
    return;
}
```

####  Justification de sécurité
La lecture est bornée, et la validation qui suit rejette tout ce qui n'entre pas dans le modèle attendu (longueur et jeu de caractères). Un nom d'utilisateur ne peut plus dépasser 15 caractères ni contenir autre chose que des alphanumériques, `_` ou `-`, ce qui neutralise au passage les tentatives d'injection décrites plus loin.

---

### Correction #3 : Remplacement de `strcpy` et débordement de la structure globale

####  Vulnérabilité originale
**Fonctions concernées** : `register_user` (72-73), `clone_user` (199), `change_password` (230)

Les champs `username` et `password` de la structure `User` font 16 octets. Les tampons locaux qui les alimentent en font 80 ou 100. Le `strcpy` recopie sans se soucier de la différence.

```c
char username[100];             // saisie utilisateur
strcpy(users[user_count].username, username);  // destination : 16 octets
```

####  Attaque possible
Comme `users` est un tableau global, écrire au-delà de `username[16]` déborde sur les champs voisins de la même structure — `password`, `admin_flag`, `balance`, le pointeur `token` — puis sur l'utilisateur suivant du tableau. Un nom de 20 caractères suffit à écraser le mot de passe stocké ; un nom plus long positionne `admin_flag` à une valeur non nulle. Le débordement de données donne donc directement une élévation de privilèges, sans même toucher à la pile.

**Impact** : corruption mémoire, élévation de privilèges, fuite d'informations.

####  Correction implémentée
La structure a d'abord été repensée (voir correction #7) pour ne plus stocker de mot de passe en clair. La copie du nom est bornée et terminée explicitement :

```c
strncpy(u->username, username, sizeof(u->username) - 1);
u->username[sizeof(u->username) - 1] = '\0';
```

La validation en amont garantit déjà que `username` tient dans 15 caractères ; `strncpy` avec `sizeof - 1` sert de seconde barrière.

####  Justification de sécurité
`strncpy` n'écrit jamais plus de `sizeof(u->username) - 1` octets, et l'ajout manuel du `\0` compense le seul défaut connu de la fonction (elle ne termine pas la chaîne si la source est trop longue). Aucun champ voisin n'est plus atteignable.

---

### Correction #4 : Débordement de tas sur le token et `malloc` non vérifié

####  Vulnérabilité originale
**Fonction concernée** : `register_user` (77-78)

```c
users[user_count].token = malloc(32);              // retour non vérifié
sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
```

Le token fait 32 octets, mais `username` peut en apporter 100. `sprintf` écrit sans limite.

####  Attaque possible
Un nom d'utilisateur long provoque un débordement de tas dans le bloc de 32 octets, corrompant les métadonnées de l'allocateur. Par ailleurs, si `malloc` échoue et renvoie `NULL`, le `sprintf` déréférence un pointeur nul et le programme plante.

**Impact** : corruption du tas, déni de service.

####  Correction implémentée
```c
static char *make_token(int id, const char *username) {
    char *t = malloc(TOKEN_SIZE);
    if (!t) return NULL;
    snprintf(t, TOKEN_SIZE, "TOK_%d_%s", id, username);
    return t;
}
```

L'appelant vérifie le retour et refuse l'opération plutôt que de laisser un état incohérent :

```c
u->token = make_token(user_count, u->username);
if (!u->token) { printf("Erreur d'allocation\n"); return; }
```

####  Justification de sécurité
`snprintf` tronque au lieu de déborder, et le token est de toute façon construit à partir d'un nom déjà limité à 15 caractères (`TOK_` + indice + `_` + nom tient dans 48 octets). Le retour de `malloc` est systématiquement testé, ce qui supprime le déréférencement de `NULL`.

---

### Correction #5 : Format string dans `show_profile`

####  Vulnérabilité originale
**Fonction concernée** : `show_profile` (106)

```c
gets(format);
printf(format);     // la chaîne de format est fournie par l'utilisateur
```

####  Attaque possible
`printf` interprète les directives de la chaîne qu'on lui passe. En saisissant `%x %x %x`, l'attaquant lit la pile ; avec `%s`, il déréférence des adresses arbitraires ; avec `%n`, il **écrit** en mémoire. C'est une primitive de lecture et d'écriture complète.

**Impact** : lecture de mémoire, écriture arbitraire, exécution de code.

####  Correction implémentée
```c
if (read_line(NULL, format, sizeof(format)) == 0) {
    printf("%s\n", format);   // le texte utilisateur est une donnée, pas un format
}
```

####  Justification de sécurité
La chaîne de format est désormais une constante (`"%s\n"`) et l'entrée utilisateur devient un simple argument. Aucune directive présente dans la saisie n'est interprétée. Le test le confirme : `Bonjour %s%s%s%n` s'affiche tel quel, sans crash ni fuite (section 3.4).

---

### Correction #6 : Backdoor dans `change_password`

####  Vulnérabilité originale
**Fonction concernée** : `change_password` (226-227)

```c
if(strcmp(users[user_id].password, old_pass) == 0 ||
   strcmp(old_pass, "master_reset_2024") == 0) {   // porte dérobée
```

####  Attaque possible
Quiconque connaît la chaîne `master_reset_2024` change le mot de passe du compte connecté sans connaître l'ancien. Un mot de passe maître codé en dur finit toujours par fuiter (rétro-ingénierie du binaire, dépôt de code, capture réseau) et ouvre alors tous les comptes.

**Impact** : contournement d'authentification, élévation de privilèges.

####  Correction implémentée
La branche est purement et simplement supprimée. La vérification repose sur l'empreinte du mot de passe :

```c
if (!check_password(&users[user_id], old_pass)) {
    printf("Ancien mot de passe incorrect\n");
    return;
}
```

####  Justification de sécurité
Il n'existe plus aucun secret partagé permettant de contourner le contrôle. La seule façon de changer un mot de passe est de fournir l'ancien, vérifié contre son empreinte salée.

---

### Correction #7 : Cryptographie — hash maison et stockage en clair

####  Vulnérabilité originale
**Fonctions concernées** : `hash_password` (39-45), stockage dans `register_user` (73), `main` (311)

```c
unsigned int hash_password(char *pass) {   // djb2, non cryptographique
    unsigned int h = 5381; int c;
    while ((c = *pass++)) h = h * 33 + c;
    return h;
}
```

Détail aggravant : cette fonction n'est même jamais appelée. Les mots de passe sont comparés et stockés **en clair** (`strcmp`, `strcpy`, écriture dans les backups).

####  Attaque possible
Un hash djb2 se casse en quelques millisecondes (32 bits, nombreuses collisions). Mais le vrai problème est en amont : les mots de passe vivent en clair dans le tableau global et sont recopiés tels quels dans les fichiers de sauvegarde. Quiconque lit la mémoire du processus ou un backup obtient les identifiants.

**Impact** : compromission totale des identifiants.

####  Correction implémentée
La structure ne conserve plus qu'un sel aléatoire et l'empreinte SHA-256 de `sel || mot de passe` :

```c
typedef struct {
    char username[16];
    unsigned char salt[SALT_LEN];          // 16 octets aléatoires
    char password_hash[HASH_HEX_LEN + 1];  // SHA-256 en hexadécimal
    int admin_flag;
    long balance;
    char *token;
} User;

static void sha256_hex(const unsigned char *salt, size_t salt_len,
                       const char *pass, char out_hex[HASH_HEX_LEN + 1]) {
    unsigned char buf[SALT_LEN + PASSWORD_MAX_LEN];
    unsigned char digest[SHA256_DIGEST_LENGTH];
    size_t plen = strlen(pass);
    if (plen > PASSWORD_MAX_LEN) plen = PASSWORD_MAX_LEN;
    memcpy(buf, salt, salt_len);
    memcpy(buf + salt_len, pass, plen);
    SHA256(buf, salt_len + plen, digest);        // OpenSSL
    /* ... encodage hexadécimal ... */
}
```

Le sel provient de `RAND_bytes` (générateur cryptographique d'OpenSSL), et les backups n'exportent plus aucun identifiant (correction #10).

####  Justification de sécurité
SHA-256 est une fonction de hachage cryptographique standard : impossible à inverser en pratique. Le sel par utilisateur casse les tables précalculées (rainbow tables) et fait que deux comptes au même mot de passe produisent des empreintes différentes. Aucun mot de passe n'existe plus en clair, ni en mémoire persistante, ni sur disque.

> Remarque sur les compromis. Pour du stockage de mots de passe en production, une fonction lente et paramétrable (bcrypt, scrypt, Argon2) serait préférable à SHA-256, précisément parce qu'elle ralentit les attaques par force brute hors ligne. Le sujet imposant SHA-256, c'est le choix retenu ici, complété par le sel ; le passage à Argon2 est listé en amélioration possible.

---

### Correction #8 : Élévation de privilèges (auto-admin et clonage)

####  Vulnérabilité originale
**Fonctions concernées** : `register_user` (69-74), `clone_user` (200-202)

```c
printf("Droits admin (1=oui, 0=non): ");
scanf("%d", &admin);
/* ... */
users[user_count].admin_flag = admin;   // l'utilisateur se déclare admin
```

Et lors du clonage :

```c
users[user_count].admin_flag = users[source_id].admin_flag;  // hérite des droits
users[user_count].balance = users[source_id].balance;        // hérite du solde
```

####  Attaque possible
N'importe qui crée un compte administrateur en répondant `1` à l'enregistrement, puis accède au menu « Commande système ». Le clonage offre un second chemin : cloner le compte admin duplique ses droits — et son solde, ce qui crée de l'argent à volonté.

**Impact** : élévation de privilèges, fraude (création de monnaie).

####  Correction implémentée
Un compte créé par le self-service est toujours non-admin :

```c
u->admin_flag = 0;   // un nouveau compte n'est JAMAIS admin
u->balance = 100;
```

Le clone recopie l'empreinte et le sel, mais ni les droits ni l'argent :

```c
memcpy(u->salt, users[source_id].salt, SALT_LEN);
memcpy(u->password_hash, users[source_id].password_hash, sizeof(u->password_hash));
u->admin_flag = 0;   // pas d'héritage de privilèges
u->balance = 0;      // pas de duplication d'argent
```

####  Justification de sécurité
L'attribution des droits d'administration ne dépend plus d'une entrée utilisateur. Le solde d'un nouveau compte est fixé par le programme, ce qui ferme la fabrique de monnaie par clonage.

---

### Correction #9 : Logique métier du transfert

####  Vulnérabilité originale
**Fonction concernée** : `transfer_money` (120-124)

```c
scanf("%d", &amount);           // aucune validation
/* ... */
users[from_user].balance -= amount;   // pas de contrôle du solde
users[i].balance += amount;
```

####  Attaque possible
Deux abus immédiats. Un montant négatif inverse le sens du transfert : « envoyer -1000 » à une victime revient à se les créditer. Un montant supérieur au solde met le compte en négatif sans limite, l'argent étant crédité au destinataire. Rien n'empêche non plus de se transférer de l'argent à soi-même.

**Impact** : fraude, vol de fonds.

####  Correction implémentée
```c
int to = find_user(to_username);
if (to < 0)          { printf("Utilisateur destinataire introuvable\n"); return; }
if (to == from_user) { printf("Transfert vers soi-même interdit\n");     return; }

if (read_long("Montant: ", &amount, 1, users[from_user].balance) != 0) {
    printf("Montant invalide (1..%ld)\n", users[from_user].balance);
    return;
}
users[from_user].balance -= amount;
users[to].balance += amount;
```

`read_long` impose un intervalle `[1, solde]`. Le champ `balance` est passé en `long` pour écarter tout débordement d'entier.

####  Justification de sécurité
Le montant est nécessairement positif et inférieur ou égal au solde de l'émetteur : ni transfert négatif, ni découvert. Le destinataire doit exister et être distinct de l'émetteur. Le test avec `-100` renvoie bien « Montant invalide » (section 3.4).

---

### Correction #10 : Path traversal et fuite de données (backup / restore)

####  Vulnérabilité originale
**Fonctions concernées** : `backup_user_data` (139-147), `restore_user_data` (160-170)

```c
scanf("%s", filename);
fp = fopen(filename, "w");                 // chemin arbitraire, en écriture
fprintf(fp, "%s:%s:%d:%d\n", ..., users[user_id].password, ...);  // mot de passe en clair
```

Et en lecture :

```c
scanf("%s", filename);
fp = fopen(filename, "r");                 // chemin arbitraire, en lecture
```

####  Attaque possible
En écriture, un chemin comme `../../.bashrc` écrase des fichiers hors du dossier de travail, avec en prime le mot de passe de l'utilisateur écrit en clair. En lecture, `../../../etc/passwd` affiche le contenu de n'importe quel fichier lisible par le processus — la fonction de restauration devient un lecteur de fichiers arbitraire. De plus, la restauration ne demande aucune authentification.

**Impact** : fuite d'informations, écrasement de fichiers, lecture arbitraire.

####  Correction implémentée
Un nom de fichier validé, confiné dans un sous-dossier dédié :

```c
static int valid_filename(const char *f) {
    size_t len = strlen(f);
    if (len == 0 || len > FILENAME_MAX_LEN) return 0;
    if (f[0] == '.')      return 0;   // pas de nom caché ni relatif
    if (strstr(f, ".."))  return 0;   // pas de remontée
    for (size_t i = 0; i < len; i++) {
        char c = f[i];
        if (!(isalnum((unsigned char)c) || c=='_' || c=='-' || c=='.')) return 0;
    }
    return 1;
}
/* ... */
snprintf(path, sizeof(path), "%s/%s", BACKUP_DIR, filename);
```

Le backup n'écrit plus que des données non sensibles (`username`, `balance`, `admin`) — jamais l'empreinte ni le sel.

> ⚠️ Point partiel : le **path traversal** est corrigé (backup et restore), mais l'exigence d'**authentification** avant restauration (V#20) n'est pas encore en place — voir la section « Vulnérabilités non corrigées ».

####  Justification de sécurité
Le nom ne peut contenir ni `/` ni `..`, et il est systématiquement préfixé par `backups/`. Il est donc impossible de sortir de ce dossier. Les tests montrent que `../../etc/passwd` est rejeté à l'écriture comme à la lecture (section 3.4). Aucune donnée d'authentification ne transite plus par les fichiers.

---

### Correction #11 : Injection de commande (`system_command`)

####  Vulnérabilité originale
**Fonction concernée** : `system_command` (181-184)

```c
gets(cmd);
sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
system(full_cmd);        // shell complet, entrée concaténée
```

####  Attaque possible
`system` lance `/bin/sh -c`. Tout ce que l'utilisateur saisit est interprété par le shell : `; rm -rf ~`, `&& cat /etc/passwd`, `$(...)`. C'est une exécution de commande arbitraire directe. Le garde-fou « réservé aux admins » ne protège pas grand-chose, puisque n'importe qui pouvait justement devenir admin (correction #8).

**Impact** : exécution de commande arbitraire, compromission de la machine.

####  Correction implémentée
La fonctionnalité d'exécution de shell est retirée. À la place, un affichage d'informations fixes, sans aucun appel à `system` :

```c
static void system_status(void) {
    time_t now = time(NULL);
    /* ... horodatage ... */
    printf("=== STATUT SYSTÈME ===\n");
    printf("Heure serveur          : %s\n", ts);
    printf("Utilisateurs enregistrés: %d / %d\n", user_count, MAX_USERS);
    printf("(Exécution de commandes shell désactivée pour raisons de sécurité)\n");
}
```

####  Justification de sécurité
Sans appel à `system` ni à un shell, il n'y a plus de surface d'injection. Le programme n'expose que des données qu'il contrôle entièrement. Quand un besoin légitime d'exécuter un programme externe existe, la bonne approche est `execve` avec un tableau d'arguments (jamais de chaîne concaténée passée à un shell) ; ici, aucun besoin de ce genre n'était réel, donc la fonction est neutralisée.

---

### Correction #12 : Gestion mémoire et fuites

####  Vulnérabilité originale
**Fonctions concernées** : `register_user` (77), `main` (314)

Chaque utilisateur reçoit un `token` alloué par `malloc`, mais aucun `free` ne lui correspond. Le clone, lui, n'allouait rien du tout, laissant un pointeur incohérent.

####  Attaque possible
Fuite mémoire à chaque enregistrement. Sur un service à longue durée de vie, la consommation croît sans borne — un déni de service à petit feu.

**Impact** : déni de service (épuisement mémoire).

####  Correction implémentée
Une fonction de nettoyage unique, enregistrée pour s'exécuter à la sortie du programme :

```c
static void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}
/* dans main : */
atexit(cleanup);
```

Le clone alloue désormais son propre token comme les autres comptes.

####  Justification de sécurité
`atexit(cleanup)` garantit la libération quelle que soit la porte de sortie (choix « 0 », fin d'entrée, `return`). Valgrind confirme : `0 bytes in use at exit`, `0 errors` (section 3.3).

---

### Correction #13 : Robustesse du menu et validations diverses

####  Vulnérabilité originale
**Fonctions concernées** : `main` (320), `compute_stats` (247), `show_profile` (96)

```c
scanf("%d", &choice);   // retour ignoré
```

Si l'entrée n'est pas un nombre (ou en cas d'EOF), `scanf` échoue, `choice` garde son ancienne valeur et le caractère fautif reste dans le tampon : la boucle tourne indéfiniment. Par ailleurs, `compute_stats` divise par `user_count` sans vérifier qu'il est non nul, et `show_profile` fait confiance à un `user_id` non borné.

####  Attaque possible
Une entrée non numérique (ou une redirection de fichier qui se termine) fige le programme dans une boucle infinie consommant 100 % de CPU. C'est un déni de service trivial à déclencher.

**Impact** : déni de service.

####  Correction implémentée
La lecture du choix distingue explicitement l'entrée invalide de la fin de flux :

```c
int r = read_long("Choix: ", &choice, 0, 12);
if (r == -2) { printf("\nEntrée terminée, au revoir!\n"); break; }  // EOF -> sortie
if (r == -1) { printf("Choix invalide\n"); continue; }
```

`compute_stats` protège la division (`if (user_count <= 0)`), et `show_profile` valide son indice (`if (user_id < 0 || user_id >= user_count)`).

####  Justification de sécurité
Sur EOF, le programme sort proprement au lieu de boucler ; sur entrée invalide, il redemande. Plus aucune division par zéro ni accès hors bornes du tableau `users`.

---

### Correction #14 : Identifiants admin codés en dur

####  Vulnérabilité originale
**Fonction concernée** : `main` (310-315)

```c
strcpy(users[0].username, "admin");
strcpy(users[0].password, "admin123");   // identifiants par défaut connus
```

####  Attaque possible
`admin` / `admin123` est un couple d'identifiants trivial et présent dans le code source. Toute personne ayant lu le binaire — ou simplement deviné — se connecte en administrateur.

**Impact** : accès administrateur non autorisé.

####  Correction implémentée
Le mot de passe admin est tiré aléatoirement au démarrage et affiché une seule fois :

```c
char admin_pass[24];
gen_random_password(admin_pass, sizeof(admin_pass));
set_password(&users[0], admin_pass);
printf("[INIT] Compte admin créé. Mot de passe temporaire: %s\n\n", admin_pass);
```

####  Justification de sécurité
Il n'y a plus de mot de passe prévisible dans le code. Chaque exécution génère un secret différent via `RAND_bytes`, communiqué à l'opérateur au lancement — le même principe que le mot de passe admin initial affiché par Jenkins au premier démarrage, ou que `mysql_secure_installation`.

---

### Vulnérabilités non corrigées (manque de temps)

Les trois points suivants ont été **identifiés et localisés** mais n'ont pas pu être corrigés dans le temps imparti, une fois traités le Critique et le Haut. Ils sont repérés par des commentaires `TODO` dans `secure.c` et rappelés en tête de `test_inputs.txt`.

- **V#9 — Comparaison non à temps constant (`login_user` / `change_password`).** `check_password()` compare les empreintes avec `strcmp`, qui s'arrête au premier octet différent. Un attaquant mesurant finement le temps de réponse pourrait, en théorie, reconstituer l'empreinte octet par octet (*timing attack*). Correctif prévu : une comparaison qui parcourt toujours tous les octets (accumulation de `a[i] ^ b[i]`). Gravité moyenne, exploitation difficile en pratique — d'où la priorité basse.
- **V#20 — `restore_user_data` sans authentification.** Le path traversal est corrigé (accès confiné à `backups/`), mais la fonction reste appelable sans être connecté. Correctif prévu : la même garde `if (logged_user >= 0)` que les autres actions sensibles, dans `main` (case 6).
- **V#37 — `list_users` sans contrôle d'accès.** La liste (soldes et drapeaux admin compris) reste visible par tous. Le scénario de `test_inputs.txt` le montre : après connexion en tant qu'`alice` (non-admin), le choix 9 affiche quand même tous les comptes. Correctif prévu : réserver l'affichage complet aux administrateurs.

Les **bonus** du barème n'ont pas été implémentés pour la même raison : limitation des tentatives de connexion, comparaison à temps constant (= V#9), et journal de sécurité horodaté.

---

## 3. Tests de validation <a name="tests"></a>

### 3.1 Compilation

```bash
gcc -Wall -Wextra -g -fstack-protector-all -D_FORTIFY_SOURCE=2 \
    -o secure secure.c -lcrypto
```

**Résultat** : compilation réussie, **0 warning, 0 erreur**. La variante durcie passe aussi :

```bash
gcc -Wall -Wextra -g -fstack-protector-all -D_FORTIFY_SOURCE=2 \
    -fPIE -pie -Wl,-z,relro,-z,now -o secure secure.c -lcrypto
# === HARDENED BUILD OK ===
```

À titre de comparaison, l'éditeur de liens refusait déjà à moitié le code d'origine : *« the `gets' function is dangerous and should not be used »*.

### 3.2 Tests fonctionnels

Scénario complet rejoué depuis `test_inputs.txt` (enregistrement, connexion, profil, transfert, statistiques, recherche, clonage, backup, restauration, changement de mot de passe).

| Fonctionnalité | Test effectué | Résultat |
|----------------|---------------|----------|
| Création utilisateur | nom valide + confirmation correcte | ☑ OK |
| Connexion | identifiants corrects puis incorrects | ☑ OK |
| Transfert | 50 € vers `admin`, solde mis à jour | ☑ OK |
| Statistiques | somme et moyenne sur 2 comptes | ☑ OK (pas de division par zéro) |
| Clonage | clone créé sans droits ni argent hérités | ☑ OK |
| Liste utilisateurs | affichée à un compte non-admin | ⚠ Affichée (V#37 non corrigée) |
| Backup / restore | fichier `sauvegarde_alice` dans `backups/` | ☑ OK, sans identifiants |

### 3.3 Analyse mémoire (Valgrind)

```bash
valgrind --leak-check=full --show-leak-kinds=all --error-exitcode=99 \
    ./secure < test_inputs.txt
```

**Résultat** :

```
==17317==     in use at exit: 0 bytes in 0 blocks
==17317== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
valgrind exit=0
```

**Fuites détectées : 0 octet. Blocs non libérés : 0. Erreurs : 0.**

### 3.4 Tests de sécurité

**Test 1 — Format string**
Entrée sur le champ « message d'affichage » : `Bonjour %s%s%s%n <- test format string`.
Résultat attendu : la chaîne s'affiche littéralement, sans interprétation ni crash.
Résultat obtenu :

```
Message d'affichage personnalisé: Bonjour %s%s%s%n <- test format string
```

**Test 2 — Path traversal**
Entrées : `../../etc/passwd` (backup) puis `../../../etc/passwd` (restore).
Résultat obtenu :

```
Nom du fichier de backup: Nom de fichier invalide
Fichier à restaurer: Nom de fichier invalide
```

**Test 3 — Transfert malveillant**
Entrée : montant `-100`.
Résultat obtenu :

```
Montant: Montant invalide (1..50)
```

**Test 4 — Contrôle d'accès de la liste (V#37, non corrigée)**
Après connexion en tant qu'`alice` (non-admin), choix 9.
Résultat obtenu — la liste s'affiche quand même, ce qui confirme ce point non corrigé :

```
=== LISTE UTILISATEURS ===
0. admin (Balance: 10050€, Admin: 1)
1. alice (Balance: 50€, Admin: 0)
2. alice_clone (Balance: 0€, Admin: 0)
```

Le binaire vulnérable, pour mémoire, plantait ou exécutait la charge sur les entrées des tests 1 à 3.

---

## 4. Conclusion <a name="conclusion"></a>

### 4.1 Résumé des corrections

- Vulnérabilités **critiques** corrigées : 11 / 11
- Vulnérabilités **hautes** corrigées : 15 / 15
- Vulnérabilités **moyennes** corrigées : 4 / 6 (V#9 et V#20 différées)
- Vulnérabilités **faibles** corrigées : 4 / 5 (V#37 différée)
- **Total : 34 / 37** — les 3 restantes sont moyennes/faibles et documentées

Toutes les vulnérabilités les plus graves (Critique et Haute) sont donc corrigées ; ce qui reste ouvert est de gravité limitée.

Les changements structurants :

1. Une seule fonction de lecture bornée (`read_line`) remplace tous les `gets` et `scanf("%s")` du programme, doublée d'une validation par type d'entrée (nom, mot de passe, nom de fichier, montant).
2. Le stockage des mots de passe passe au SHA-256 salé, avec suppression de la porte dérobée.
3. Les deux surfaces système les plus dangereuses sont fermées : plus d'appel `system`, et les accès fichiers sont confinés à un sous-dossier après validation.

### 4.2 Difficultés rencontrées

**Concilier « 0 warning » et l'API OpenSSL.** Le sujet impose `SHA256()`, marquée dépréciée dans OpenSSL 3.0. Sur la VM (paquet 3.0.2 d'Ubuntu), la fonction compile sans avertissement sous `-Wall -Wextra` ; je l'ai donc conservée telle quelle. Sur une chaîne plus stricte qui signalerait la dépréciation, l'alternative serait l'API `EVP` (`EVP_Digest`).

**Warning `-Wformat-truncation`.** La construction du chemin de backup déclenchait un avertissement parce que le compilateur raisonne sur la taille maximale du tampon d'entrée (256), sans connaître la limite runtime de 64 imposée par la validation. Dimensionner le tampon de destination sur la taille réelle du tampon source a suffi à le lever proprement, sans masquer le diagnostic.

### 4.3 Améliorations possibles

- Remplacer SHA-256 par Argon2 (ou bcrypt/scrypt) pour le stockage des mots de passe : une fonction lente et paramétrable résiste bien mieux à la force brute hors ligne.
- Chiffrer les données sensibles au repos et gérer de vraies sessions avec expiration. La structure `Session` existe dans le code mais n'est jamais utilisée : elle attend une implémentation.
- Découpler les rôles : une véritable séparation admin / utilisateur avec un mécanisme d'attribution contrôlé, plutôt qu'un simple drapeau entier.
- Masquer la saisie du mot de passe au clavier (désactivation de l'écho via `termios`).

### 4.4 Apprentissages clés

La plupart des failles de ce programme viennent d'un même réflexe : faire confiance à l'entrée. Une fois posée une brique de lecture sûre et une validation systématique, la moitié du tableau tombe d'un coup. L'autre enseignement concerne les failles de logique — montant négatif, clonage qui duplique l'argent, backdoor — qui ne déclenchent aucun avertissement du compilateur et ne se voient qu'en lisant le code avec un œil d'attaquant. Enfin, l'outillage (avertissements du compilateur, Valgrind) rend un service concret mais ne remplace pas la relecture : `gets` était signalé par l'éditeur de liens, l'injection `system` ne l'était pas.

### 4.5 Auto-évaluation

| Critère | Note estimée /20 | Justification |
|---------|------------------|---------------|
| Analyse | 6 / 6 | 37 vulnérabilités identifiées, localisées et classées par gravité (y compris les 3 non corrigées) |
| Corrections | 7 / 10 | 34/37 corrigées (tout le Critique/Haut), compile sans warning, 0 fuite Valgrind ; 3 items moyens/faibles et les bonus non traités |
| Documentation | 3 / 4 | Corrections majeures détaillées (origine, attaque, avant/après, justification) ; toutes les failles ne sont pas rédigées une par une |
| **TOTAL** | **~16 / 20** | Rendu partiel faute de temps ; limites documentées et justifiées |

---

## Annexes

### Annexe A : Checklist de vérification finale

- [x] Tous les `gets()` remplacés par une lecture bornée (`fgets`)
- [x] Tous les `scanf("%s")` remplacés par `read_line` + validation
- [x] Tous les `strcpy()` remplacés par `strncpy()` + terminaison explicite
- [x] Tous les `sprintf()` remplacés par `snprintf()`
- [x] Cryptographie : SHA-256 (OpenSSL) avec sel
- [x] Aucun mot de passe en clair (mémoire ni disque)
- [x] Aucune backdoor
- [x] Tous les indices de tableaux validés
- [x] Tous les `malloc()` vérifiés et libérés (`atexit(cleanup)`)
- [x] 0 fuite mémoire (Valgrind)
- [x] 0 warning de compilation
- [x] Validation stricte des noms de fichiers (anti path traversal)
- [x] Protection contre l'injection de commande (`system` supprimé)

Points non traités (manque de temps) :

- [ ] Contrôle d'accès sur `list_users` (V#37)
- [ ] Authentification requise pour `restore_user_data` (V#20)
- [ ] Comparaison des empreintes à temps constant (V#9)
- [ ] Bonus : limitation des tentatives de connexion, logs de sécurité

### Annexe B : Références utilisées

1. Manuels : `man fgets`, `man snprintf`, `man strncpy`, `man 3 RAND_bytes`.
2. Documentation OpenSSL — SHA-256 et génération d'aléa.
3. OWASP Top 10 (contrôle d'accès, injection, cryptographie).
4. CWE : CWE-120 (buffer overflow), CWE-134 (format string), CWE-78 (injection de commande), CWE-22 (path traversal), CWE-798 (identifiants codés en dur).

---

**Fin du rapport**
