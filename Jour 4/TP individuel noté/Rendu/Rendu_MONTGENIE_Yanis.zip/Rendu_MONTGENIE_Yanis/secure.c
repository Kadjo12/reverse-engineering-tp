/*
 * TP FINAL NOTÉ - Version SÉCURISÉE de vulnerable.c
 *
 * Système de gestion de comptes utilisateurs avec authentification.
 *
 * Chaque marqueur « [FIX #n] » renvoie à la « Correction #n » du RAPPORT.md.
 * Une même fonction peut porter plusieurs numéros (elle corrige plusieurs
 * classes de vulnérabilités à la fois).
 *
 * NOTE : par manque de temps sur les 4 h, les vulnérabilités Critiques et
 * Hautes ont toutes été traitées ; trois points moyens/faibles restent
 * ouverts (marqués « TODO ») et les bonus ne sont pas implémentés. La liste
 * de ce qui est fait / non fait figure en tête de test_inputs.txt.
 *
 * Compilation :
 *   gcc -o secure secure.c -lcrypto -Wall -Wextra \
 *       -fstack-protector-all -D_FORTIFY_SOURCE=2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <sys/stat.h>
#include <openssl/sha.h>   /* [FIX #7] cryptographie : SHA-256 (OpenSSL) */
#include <openssl/rand.h>  /* [FIX #7] sel aléatoire cryptographiquement sûr */

#define MAX_USERS         20
#define MAX_SESSIONS      10
#define USERNAME_MAX_LEN  15          /* tient dans username[16] avec le '\0' */
#define PASSWORD_MIN_LEN   8
#define PASSWORD_MAX_LEN 128
#define FILENAME_MAX_LEN  64
#define INPUT_MAX        256          /* taille du buffer de lecture de ligne */
#define SALT_LEN          16          /* 16 octets de sel par utilisateur     */
#define HASH_HEX_LEN      64          /* SHA-256 = 32 octets = 64 hex          */
#define TOKEN_SIZE        48
#define BACKUP_DIR       "backups"    /* les backups restent confinés ici      */

/*
 * [FIX #7] Le champ password[16] en clair est remplacé par un sel
 * aléatoire + l'empreinte SHA-256 salée (hex). Aucun mot de passe n'est
 * jamais stocké en clair. « balance » passe en long pour éviter les
 * dépassements d'entier.
 */
typedef struct {
    char username[16];
    unsigned char salt[SALT_LEN];
    char password_hash[HASH_HEX_LEN + 1];
    int admin_flag;
    long balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

/* ======================================================================
 *  UTILITAIRES D'ENTRÉE (remplacent gets()/scanf("%s")/scanf("%d"))
 * ==================================================================== */

/*
 * [FIX #1 et #2] Lecture d'une ligne bornée. Remplace gets() et scanf("%s").
 * - fgets ne dépasse jamais la taille du buffer.
 * - le '\n' est retiré ; si la ligne est plus longue que le buffer, le
 *   reste est vidé pour ne pas polluer la lecture suivante.
 * Retourne 0 si OK, -1 sur EOF.
 */
static int read_line(const char *prompt, char *buf, size_t size) {
    if (prompt) { printf("%s", prompt); fflush(stdout); }
    if (fgets(buf, (int)size, stdin) == NULL)
        return -1;
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        int c;
        while ((c = getchar()) != '\n' && c != EOF)
            ;
    }
    return 0;
}

/*
 * [FIX #13] Lecture d'un entier validé. Remplace scanf("%d").
 * Retourne 0 si OK, -1 si entrée invalide/hors bornes, -2 sur EOF.
 */
static int read_long(const char *prompt, long *out, long min, long max) {
    char line[64];
    if (read_line(prompt, line, sizeof(line)) != 0)
        return -2;                       /* EOF */

    char *end;
    errno = 0;
    long v = strtol(line, &end, 10);
    if (end == line)                     /* aucun chiffre */
        return -1;
    while (*end == ' ' || *end == '\t')
        end++;
    if (*end != '\0')                    /* caractères parasites */
        return -1;
    if (errno == ERANGE || v < min || v > max)
        return -1;

    *out = v;
    return 0;
}

/* ======================================================================
 *  CRYPTOGRAPHIE (SHA-256 salé)
 * ==================================================================== */

/* [FIX #7] Empreinte SHA-256 de (sel || mot de passe) au format hex. */
static void sha256_hex(const unsigned char *salt, size_t salt_len,
                       const char *pass, char out_hex[HASH_HEX_LEN + 1]) {
    unsigned char buf[SALT_LEN + PASSWORD_MAX_LEN];
    unsigned char digest[SHA256_DIGEST_LENGTH];
    size_t plen = strlen(pass);
    if (plen > PASSWORD_MAX_LEN)
        plen = PASSWORD_MAX_LEN;

    memcpy(buf, salt, salt_len);
    memcpy(buf + salt_len, pass, plen);
    SHA256(buf, salt_len + plen, digest);

    static const char hexd[] = "0123456789abcdef";
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        out_hex[i * 2]     = hexd[(digest[i] >> 4) & 0xF];
        out_hex[i * 2 + 1] = hexd[digest[i] & 0xF];
    }
    out_hex[HASH_HEX_LEN] = '\0';
}

/* [FIX #7] Génère un sel aléatoire et calcule le hash du mot de passe. */
static int set_password(User *u, const char *pass) {
    if (RAND_bytes(u->salt, SALT_LEN) != 1)
        return -1;
    sha256_hex(u->salt, SALT_LEN, pass, u->password_hash);
    return 0;
}

/* [FIX #7] Vérifie un mot de passe candidat contre le hash stocké.
 * TODO (non fait, manque de temps) : comparaison à temps constant pour
 * fermer la fuite temporelle (V#9). En l'état, strcmp s'arrête au premier
 * octet différent -> vulnérabilité timing non corrigée. */
static int check_password(const User *u, const char *pass) {
    char h[HASH_HEX_LEN + 1];
    sha256_hex(u->salt, SALT_LEN, pass, h);
    return strcmp(h, u->password_hash) == 0;
}

/* Génère un mot de passe aléatoire imprimable (pour l'admin par défaut). */
static int gen_random_password(char *out, size_t size) {
    static const char cs[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    if (size < 2)
        return -1;
    unsigned char rnd[64];
    size_t n = size - 1;
    if (n > sizeof(rnd))
        n = sizeof(rnd);
    if (RAND_bytes(rnd, (int)n) != 1)
        return -1;
    for (size_t i = 0; i < n; i++)
        out[i] = cs[rnd[i] % (sizeof(cs) - 1)];
    out[n] = '\0';
    return 0;
}

/* ======================================================================
 *  VALIDATION DES ENTRÉES
 * ==================================================================== */

/* [FIX #2] username : 1..15 caractères parmi [A-Za-z0-9_-]. */
static int valid_username(const char *u) {
    size_t len = strlen(u);
    if (len == 0 || len > USERNAME_MAX_LEN)
        return 0;
    for (size_t i = 0; i < len; i++) {
        char c = u[i];
        if (!(isalnum((unsigned char)c) || c == '_' || c == '-'))
            return 0;
    }
    return 1;
}

/* [FIX #2] mot de passe : 8..128 caractères imprimables. */
static int valid_password(const char *p) {
    size_t len = strlen(p);
    if (len < PASSWORD_MIN_LEN || len > PASSWORD_MAX_LEN)
        return 0;
    for (size_t i = 0; i < len; i++)
        if (!isprint((unsigned char)p[i]))
            return 0;
    return 1;
}

/*
 * [FIX #10] nom de fichier : 1..64 caractères parmi
 * [A-Za-z0-9._-], sans « .. », sans '/', ne commençant pas par '.'.
 * Combiné au préfixe BACKUP_DIR, cela empêche tout path traversal.
 */
static int valid_filename(const char *f) {
    size_t len = strlen(f);
    if (len == 0 || len > FILENAME_MAX_LEN)
        return 0;
    if (f[0] == '.')
        return 0;
    if (strstr(f, ".."))
        return 0;
    for (size_t i = 0; i < len; i++) {
        char c = f[i];
        if (!(isalnum((unsigned char)c) || c == '_' || c == '-' || c == '.'))
            return 0;
    }
    return 1;
}

/* Recherche un utilisateur par nom exact. Retourne l'indice ou -1. */
static int find_user(const char *name) {
    for (int i = 0; i < user_count; i++)
        if (strcmp(users[i].username, name) == 0)
            return i;
    return -1;
}

/* NOTE : la journalisation de sécurité (logs horodatés) fait partie des
 * bonus non implémentés faute de temps — voir test_inputs.txt. */

/* ======================================================================
 *  GESTION MÉMOIRE
 * ==================================================================== */

/* [FIX #4] Alloue un token borné avec snprintf. malloc vérifié. */
static char *make_token(int id, const char *username) {
    char *t = malloc(TOKEN_SIZE);
    if (!t)
        return NULL;
    snprintf(t, TOKEN_SIZE, "TOK_%d_%s", id, username);
    return t;
}

/* [FIX #12] Libère toutes les ressources. Enregistrée via atexit(). */
static void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

/* ======================================================================
 *  FONCTIONNALITÉS
 * ==================================================================== */

/*
 * register_user : implémente plusieurs corrections —
 * [FIX #2] bornage + validation des entrées, [FIX #3] strcpy -> strncpy,
 * [FIX #4] token via snprintf + malloc vérifié, [FIX #7] hash salé,
 * [FIX #8] PAS d'auto-attribution des droits admin.
 */
static void register_user(void) {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[INPUT_MAX];
    char password[INPUT_MAX];
    char confirm[INPUT_MAX];

    printf("=== ENREGISTREMENT ===\n");

    if (read_line("Username: ", username, sizeof(username)) != 0)
        return;
    if (!valid_username(username)) {
        printf("Nom invalide (1-%d car., [A-Za-z0-9_-]).\n", USERNAME_MAX_LEN);
        return;
    }
    if (find_user(username) != -1) {
        printf("Ce nom d'utilisateur existe déjà\n");
        return;
    }

    if (read_line("Password: ", password, sizeof(password)) != 0)
        return;
    if (!valid_password(password)) {
        printf("Mot de passe invalide (min %d caractères imprimables).\n",
               PASSWORD_MIN_LEN);
        return;
    }

    if (read_line("Confirmer password: ", confirm, sizeof(confirm)) != 0)
        return;
    /* [FIX] la confirmation est réellement vérifiée. */
    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        return;
    }

    User *u = &users[user_count];
    memset(u, 0, sizeof(*u));
    /* [FIX #3] strcpy -> strncpy borné + terminaison explicite. */
    strncpy(u->username, username, sizeof(u->username) - 1);
    u->username[sizeof(u->username) - 1] = '\0';

    if (set_password(u, password) != 0) {
        printf("Erreur cryptographique\n");
        return;
    }
    /* [FIX #8] un nouveau compte n'est JAMAIS admin. */
    u->admin_flag = 0;
    u->balance = 100;

    u->token = make_token(user_count, u->username);
    if (!u->token) {
        printf("Erreur d'allocation\n");
        return;   /* aucun compteur incrémenté : pas d'état incohérent */
    }

    user_count++;
    printf("Utilisateur enregistré!\n");
}

/* login_user : vérifie le nom puis l'empreinte du mot de passe. */
static int login_user(const char *username, const char *password) {
    int idx = find_user(username);
    if (idx < 0)
        return -1;
    if (!check_password(&users[idx], password))
        return -1;
    return idx;
}

/*
 * [FIX #5] show_profile : format string neutralisée
 * (printf(format) -> printf("%s", ...)) ; [FIX #13] indice validé.
 */
static void show_profile(int user_id) {
    if (user_id < 0 || user_id >= user_count) {
        printf("Utilisateur invalide\n");
        return;
    }

    char format[INPUT_MAX];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %ld€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Message d'affichage personnalisé: ");
    fflush(stdout);
    if (read_line(NULL, format, sizeof(format)) == 0) {
        /* [FIX #5] le texte utilisateur est une DONNÉE, pas un format. */
        printf("%s\n", format);
    }
}

/*
 * [FIX #9] transfer_money : montant validé (> 0, <= solde), destinataire
 * existant et différent de soi-même, arithmétique en long.
 */
static void transfer_money(int from_user) {
    char to_username[INPUT_MAX];
    long amount;

    printf("=== TRANSFERT ===\n");
    if (read_line("Vers quel utilisateur: ", to_username, sizeof(to_username)) != 0)
        return;

    int to = find_user(to_username);
    if (to < 0) {
        printf("Utilisateur destinataire introuvable\n");
        return;
    }
    if (to == from_user) {
        printf("Transfert vers soi-même interdit\n");
        return;
    }

    if (read_long("Montant: ", &amount, 1, users[from_user].balance) != 0) {
        /* [FIX #9] rejette montant négatif, nul, non numérique ou > solde. */
        printf("Montant invalide (1..%ld)\n", users[from_user].balance);
        return;
    }

    users[from_user].balance -= amount;
    users[to].balance += amount;
    printf("Transfert effectué!\n");
}

/*
 * [FIX #10] backup_user_data : nom de fichier validé et confiné dans
 * BACKUP_DIR (anti path traversal). Les identifiants (hash/sel) ne sont
 * JAMAIS exportés — seules des données non sensibles sont sauvegardées.
 */
static void backup_user_data(int user_id) {
    char filename[INPUT_MAX];
    char path[INPUT_MAX + 16];
    FILE *fp;

    if (read_line("Nom du fichier de backup: ", filename, sizeof(filename)) != 0)
        return;
    if (!valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    mkdir(BACKUP_DIR, 0700);   /* idempotent */
    snprintf(path, sizeof(path), "%s/%s", BACKUP_DIR, filename);

    fp = fopen(path, "w");
    if (!fp) {
        printf("Impossible de créer le backup\n");
        return;
    }
    /* [FIX #10] pas de mot de passe/hash exporté. */
    fprintf(fp, "username=%s\nbalance=%ld\nadmin=%d\n",
            users[user_id].username,
            users[user_id].balance,
            users[user_id].admin_flag);
    fclose(fp);
    printf("Backup créé: %s\n", path);
}

/*
 * [FIX #10] restore_user_data : nom de fichier validé et confiné dans
 * BACKUP_DIR (plus de lecture de fichiers arbitraires type /etc/passwd),
 * affichage sûr avec "%s".
 *
 * TODO (non fait, manque de temps) : exiger une authentification avant
 * d'appeler cette fonction (V#20). Le path traversal est corrigé, mais
 * l'accès n'est pas encore restreint aux utilisateurs connectés.
 */
static void restore_user_data(void) {
    char filename[INPUT_MAX];
    char path[INPUT_MAX + 16];
    char buffer[256];
    FILE *fp;

    if (read_line("Fichier à restaurer: ", filename, sizeof(filename)) != 0)
        return;
    if (!valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    snprintf(path, sizeof(path), "%s/%s", BACKUP_DIR, filename);
    fp = fopen(path, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    while (fgets(buffer, sizeof(buffer), fp))
        printf("%s", buffer);   /* buffer est ici une donnée locale sûre */
    fclose(fp);
}

/*
 * [FIX #11] Remplacement de system_command : plus AUCUNE exécution de
 * commande shell (gets + sprintf + system supprimés). On expose seulement
 * des informations fixes et sûres.
 */
static void system_status(void) {
    time_t now = time(NULL);
    struct tm tmv;
    char ts[32];
    localtime_r(&now, &tmv);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);

    printf("=== STATUT SYSTÈME ===\n");
    printf("Heure serveur          : %s\n", ts);
    printf("Utilisateurs enregistrés: %d / %d\n", user_count, MAX_USERS);
    printf("(Exécution de commandes shell désactivée pour raisons de sécurité)\n");
}

/*
 * clone_user : [FIX #3] strcpy -> strncpy borné, [FIX #8] PAS de copie des
 * droits admin ni du solde (plus de duplication d'argent ni d'élévation de
 * privilèges), [FIX #4] token alloué.
 */
static void clone_user(int source_id) {
    char target_username[INPUT_MAX];

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    if (read_line("Nom du clone: ", target_username, sizeof(target_username)) != 0)
        return;
    if (!valid_username(target_username)) {
        printf("Nom invalide\n");
        return;
    }
    if (find_user(target_username) != -1) {
        printf("Ce nom d'utilisateur existe déjà\n");
        return;
    }

    User *u = &users[user_count];
    memset(u, 0, sizeof(*u));
    strncpy(u->username, target_username, sizeof(u->username) - 1);
    u->username[sizeof(u->username) - 1] = '\0';

    /* [FIX #8] on copie l'empreinte + sel, mais NI l'argent NI les droits. */
    memcpy(u->salt, users[source_id].salt, SALT_LEN);
    memcpy(u->password_hash, users[source_id].password_hash,
           sizeof(u->password_hash));
    u->admin_flag = 0;
    u->balance = 0;

    u->token = make_token(user_count, u->username);
    if (!u->token) {
        printf("Erreur d'allocation\n");
        return;
    }

    user_count++;
    printf("Clone créé\n");
}

/*
 * list_users : affiche tous les comptes.
 * TODO (non fait, manque de temps) : réserver l'affichage aux administrateurs
 * (V#37). En l'état la liste — soldes et drapeaux admin compris — reste
 * accessible à tous : divulgation d'informations non corrigée.
 */
static void list_users(void) {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %ld€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

/*
 * [FIX #6] change_password : SUPPRESSION du backdoor "master_reset_2024" ;
 * [FIX #1] gets() -> read_line, [FIX #3] hash salé au lieu de strcpy,
 * vérification par empreinte, nouveau mot de passe validé + confirmé.
 */
static void change_password(int user_id) {
    char old_pass[INPUT_MAX];
    char new_pass[INPUT_MAX];
    char confirm[INPUT_MAX];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    if (read_line("Ancien mot de passe: ", old_pass, sizeof(old_pass)) != 0)
        return;

    /* [FIX #6] plus de mot de passe maître codé en dur. */
    if (!check_password(&users[user_id], old_pass)) {
        printf("Ancien mot de passe incorrect\n");
        return;
    }

    if (read_line("Nouveau mot de passe: ", new_pass, sizeof(new_pass)) != 0)
        return;
    if (!valid_password(new_pass)) {
        printf("Nouveau mot de passe invalide (min %d caractères).\n",
               PASSWORD_MIN_LEN);
        return;
    }
    if (read_line("Confirmer: ", confirm, sizeof(confirm)) != 0)
        return;
    if (strcmp(new_pass, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        return;
    }

    if (set_password(&users[user_id], new_pass) != 0) {
        printf("Erreur cryptographique\n");
        return;
    }
    printf("Mot de passe changé\n");
}

/* [FIX #13] compute_stats : division par zéro évitée, snprintf. */
static void compute_stats(void) {
    long total = 0;

    if (user_count <= 0) {
        printf("Aucun utilisateur\n");
        return;
    }
    for (int i = 0; i < user_count; i++)
        total += users[i].balance;

    double avg = (double)total / user_count;

    char buffer[120];
    snprintf(buffer, sizeof(buffer), "Total: %ld€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

/* [FIX #2] search_user : entrée bornée et validée. */
static void search_user(void) {
    char query[INPUT_MAX];

    if (read_line("Rechercher: ", query, sizeof(query)) != 0)
        return;
    if (strlen(query) == 0) {
        printf("Requête vide\n");
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query))
            printf("Trouvé: %s\n", users[i].username);
    }
}

/* Nettoyage des sessions expirées (inchangé, sans danger). */
static void cleanup_sessions(void) {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600)
            printf("Session %d expirée\n", i);
    }
}

static void display_menu(void) {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Statut système                ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
}

int main(void) {
    long choice;
    int logged_user = -1;
    char username[INPUT_MAX], password[INPUT_MAX];

    /* [FIX #12] libération garantie sur toutes les sorties. */
    atexit(cleanup);

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE SÉCURISÉ           ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    /*
     * [FIX #14] Compte admin sans mot de passe codé en dur :
     * un mot de passe aléatoire est généré et affiché une seule fois.
     */
    memset(&users[0], 0, sizeof(users[0]));
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    char admin_pass[24];
    if (gen_random_password(admin_pass, sizeof(admin_pass)) != 0 ||
        set_password(&users[0], admin_pass) != 0) {
        fprintf(stderr, "Erreur d'initialisation cryptographique\n");
        return 1;
    }
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = make_token(0, "admin");
    if (!users[0].token) {
        fprintf(stderr, "Erreur d'allocation\n");
        return 1;
    }
    user_count = 1;
    printf("[INIT] Compte admin créé. Mot de passe temporaire: %s\n\n",
           admin_pass);

    (void)cleanup_sessions;   /* évite un warning « fonction non utilisée » */

    while (1) {
        display_menu();
        int r = read_long("Choix: ", &choice, 0, 12);
        if (r == -2) {                 /* [FIX #13] EOF -> sortie propre */
            printf("\nEntrée terminée, au revoir!\n");
            break;
        }
        if (r == -1) {
            printf("Choix invalide\n");
            continue;
        }

        switch ((int)choice) {
            case 1:
                register_user();
                break;
            case 2:
                /* TODO (bonus non fait) : limiter le nombre de tentatives
                   pour freiner la force brute en ligne. */
                if (read_line("Username: ", username, sizeof(username)) != 0)
                    break;
                if (read_line("Password: ", password, sizeof(password)) != 0)
                    break;
                logged_user = login_user(username, password);
                if (logged_user >= 0)
                    printf("✓ Connecté en tant que %s\n",
                           users[logged_user].username);
                else
                    printf("✗ Échec de connexion\n");
                break;
            case 3:
                if (logged_user >= 0)
                    show_profile(logged_user);
                else
                    printf("Veuillez vous connecter\n");
                break;
            case 4:
                if (logged_user >= 0)
                    transfer_money(logged_user);
                else
                    printf("Veuillez vous connecter\n");
                break;
            case 5:
                if (logged_user >= 0)
                    backup_user_data(logged_user);
                else
                    printf("Veuillez vous connecter\n");
                break;
            case 6:
                /* TODO (V#20 non corrigée) : devrait exiger une connexion.
                   Laissé accessible sans authentification faute de temps. */
                restore_user_data();
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag)
                    system_status();
                else
                    printf("Accès refusé\n");
                break;
            case 8:
                if (logged_user >= 0)
                    clone_user(logged_user);
                else
                    printf("Veuillez vous connecter\n");
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0)
                    change_password(logged_user);
                else
                    printf("Veuillez vous connecter\n");
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                return 0;   /* atexit(cleanup) libère la mémoire */
            default:
                printf("Choix invalide\n");
        }
    }

    return 0;
}
