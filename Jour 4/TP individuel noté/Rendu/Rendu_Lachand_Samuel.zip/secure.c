/*
 * TP FINAL NOTÉ - Version sécurisée de vulnerable.c
 *
 * 37 vulnérabilités identifiées (voir RAPPORT.md), 10 corrigées ici : les
 * critiques et celles que les consignes exigent nommément. Les vulnérabilités
 * restantes sont listées dans le rapport, section 4.3.
 *
 * Les commentaires renvoient aux numéros de ligne de vulnerable.c.
 *
 * gcc -Wall -Wextra -g -O2 -fstack-protector-all -D_FORTIFY_SOURCE=2 \
 *     -o secure secure.c -lcrypto
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <openssl/crypto.h> /* CRYPTO_memcmp() */

#define MAX_USERS 20
#define MAX_SESSIONS 10

#define MAX_NOM 15
#define MAX_MDP 63
#define TAILLE_SEL 16
#define TAILLE_HASH 32      /* SHA-256 */
#define TAILLE_TOKEN 33     /* 32 caractères hexa + '\0' */
#define MAX_ECHECS 3

#define LECTURE_OK 1
#define LECTURE_INVALIDE 0
#define LECTURE_EOF (-1)

typedef struct {
    char username[MAX_NOM + 1];
    /* ligne 21 : le mot de passe était stocké en clair dans password[16].
     * On ne garde plus que le sel et le condensé. */
    unsigned char sel[TAILLE_SEL];
    unsigned char hash[TAILLE_HASH];
    int admin_flag;
    int balance;
    int echecs;             /* bonus : tentatives de connexion ratées */
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;


/* ==================== Correction 1 : saisie ==================== */

/* memset() sur un tampon en fin de vie est supprimé par l'optimiseur à -O2. */
void effacer_memoire(void *p, size_t n) {
    volatile unsigned char *v = p;
    while(n--) *v++ = 0;
}

/*
 * Remplace les 4 gets() (lignes 105, 181, 224, 229) et les 10 scanf("%s").
 * Aucun des deux ne reçoit la taille du tampon, et tous deux laissaient le '\n'
 * dans stdin - le getchar() de la ligne 321 n'en consommait qu'un seul.
 */
int lire_ligne(const char *invite, char *dst, size_t taille) {
    size_t n;
    int c;

    printf("%s", invite);       /* jamais printf(invite), cf. show_profile() */
    fflush(stdout);

    if(fgets(dst, (int)taille, stdin) == NULL) {
        dst[0] = '\0';
        return LECTURE_EOF;
    }
    n = strcspn(dst, "\n");
    if(dst[n] == '\n') {
        dst[n] = '\0';
        return LECTURE_OK;
    }
    /* ligne trop longue : on purge le reste, sinon il serait lu comme
     * réponse à la question suivante */
    while((c = getchar()) != '\n' && c != EOF) { ; }
    printf("Saisie trop longue (%zu caractères maximum)\n", taille - 1);
    return LECTURE_INVALIDE;
}

/*
 * Remplace les scanf("%d") des lignes 70, 120 et 320. scanf ne signalait pas
 * l'échec : la variable gardait sa valeur et la saisie fautive restait dans
 * stdin, ce qui rejouait l'action précédente du menu.
 */
int lire_entier(const char *invite, long min, long max, long *valeur) {
    char ligne[32];
    char *fin = NULL;
    long v;
    int r = lire_ligne(invite, ligne, sizeof(ligne));

    if(r != LECTURE_OK) return r;

    errno = 0;
    v = strtol(ligne, &fin, 10);
    if(fin == ligne || *fin != '\0' || errno == ERANGE || v < min || v > max) {
        printf("Valeur invalide (attendu : %ld à %ld)\n", min, max);
        return LECTURE_INVALIDE;
    }
    *valeur = v;
    return LECTURE_OK;
}


/* ==================== Validation des entrées ==================== */

/* Liste blanche. Refuse ':' (séparateur du backup), '%' (format string),
 * '/' et '.' (chemins). */
int nom_valide(const char *nom) {
    size_t i, n = strlen(nom);

    if(n < 3 || n > MAX_NOM) return 0;
    for(i = 0; i < n; i++)
        if(!isalnum((unsigned char)nom[i]) && nom[i] != '_') return 0;
    return 1;
}

/* Correction 7 : le '.' et le '/' sont interdits, donc "../../etc/passwd" et
 * "/etc/shadow" sont impossibles à écrire. */
int fichier_valide(const char *nom) {
    size_t i, n = strlen(nom);

    if(n < 1 || n > 32) return 0;
    for(i = 0; i < n; i++)
        if(!isalnum((unsigned char)nom[i]) && nom[i] != '_' && nom[i] != '-') return 0;
    return 1;
}


/* ==================== Correction 5 : cryptographie ==================== */

/*
 * Remplace la DJB2 maison des lignes 39-45 (32 bits, sans sel, non
 * cryptographique, et jamais appelée). SHA256() est la forme one-shot :
 * SHA256_Init/Update/Final sont dépréciés depuis OpenSSL 3.0.
 */
void hash_password(const unsigned char *sel, const char *mdp, unsigned char *sortie) {
    unsigned char tampon[TAILLE_SEL + MAX_MDP];
    size_t n = strlen(mdp);

    if(n > MAX_MDP) n = MAX_MDP;
    memcpy(tampon, sel, TAILLE_SEL);
    memcpy(tampon + TAILLE_SEL, mdp, n);
    SHA256(tampon, TAILLE_SEL + n, sortie);
    effacer_memoire(tampon, sizeof(tampon));
}

/*
 * Remplace les strcmp() sur mot de passe en clair des lignes 88 et 226.
 * BONUS timing : CRYPTO_memcmp parcourt toujours les 32 octets, alors que
 * strcmp s'arrêtait au premier octet différent - sa durée révélait la longueur
 * du préfixe commun.
 */
int verifier_mdp(int id, const char *mdp) {
    unsigned char candidat[TAILLE_HASH];
    int ok;

    hash_password(users[id].sel, mdp, candidat);
    ok = (CRYPTO_memcmp(candidat, users[id].hash, TAILLE_HASH) == 0);
    effacer_memoire(candidat, sizeof(candidat));
    return ok;
}

/*
 * Correction 9 : remplace sprintf(token, "TOK_%d_%s", ...) dans un malloc(32)
 * (lignes 77-78), où un nom de 28 caractères débordait le bloc.
 */
char *generer_token(void) {
    static const char hex[] = "0123456789abcdef";
    unsigned char alea[16];
    char *token = malloc(TAILLE_TOKEN);
    int i;

    if(token == NULL) return NULL;          /* jamais testé dans vulnerable.c */
    if(RAND_bytes(alea, (int)sizeof(alea)) != 1) {
        free(token);
        return NULL;
    }
    for(i = 0; i < 16; i++) {
        token[i * 2] = hex[alea[i] >> 4];
        token[i * 2 + 1] = hex[alea[i] & 0x0F];
    }
    token[TAILLE_TOKEN - 1] = '\0';
    return token;
}

/* Correction 6 : supprime le couple admin/admin123 codé en dur (lignes
 * 310-311), que "strings vulnerable" révélait immédiatement. */
void generer_mdp_aleatoire(char *dst, size_t taille) {
    static const char alpha[] =
        "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    unsigned char alea[64];
    size_t i;

    dst[0] = '\0';
    if(taille < 2 || taille - 1 > sizeof(alea)) return;
    if(RAND_bytes(alea, (int)(taille - 1)) != 1) return;
    for(i = 0; i < taille - 1; i++)
        dst[i] = alpha[alea[i] % (sizeof(alpha) - 1)];
    dst[taille - 1] = '\0';
}


/* ==================== Gestion des comptes ==================== */

int chercher_user(const char *nom) {
    int i;

    for(i = 0; i < user_count; i++)
        if(strncmp(users[i].username, nom, MAX_NOM + 1) == 0) return i;
    return -1;
}

/*
 * Correction 9 : point d'entrée unique pour l'allocation du jeton, avec test du
 * retour de malloc(). vulnerable.c allouait aux lignes 77 et 314 sans vérifier,
 * et clone_user() (ligne 199) ne renseignait pas le champ du tout.
 */
int creer_compte(const char *nom, const char *mdp, int admin, int solde) {
    char *token;

    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return -1;
    }
    if((token = generer_token()) == NULL) {
        printf("Erreur interne : allocation impossible\n");
        return -1;
    }
    if(RAND_bytes(users[user_count].sel, TAILLE_SEL) != 1) {
        free(token);
        printf("Erreur interne : générateur aléatoire indisponible\n");
        return -1;
    }

    /* Correction 4 : snprintf et pas strcpy, et pas strncpy non plus - celle-ci
     * n'écrit pas le '\0' si la source remplit la destination. */
    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", nom);
    hash_password(users[user_count].sel, mdp, users[user_count].hash);
    users[user_count].admin_flag = admin;   /* fixé par l'appelant, jamais par l'utilisateur */
    users[user_count].balance = solde;
    users[user_count].echecs = 0;
    users[user_count].token = token;
    return user_count++;
}

/*
 * Correction 9 : vulnerable.c ne libérait jamais les jetons (malloc lignes 77
 * et 314) et quittait par un return au milieu de main(). On parcourt MAX_USERS :
 * un jeton peut avoir été alloué sans que le compteur soit incrémenté.
 */
void cleanup(void) {
    int i;

    for(i = 0; i < MAX_USERS; i++) {
        free(users[i].token);
        users[i].token = NULL;      /* pas de double-free si cleanup() est rappelée */
        effacer_memoire(users[i].sel, TAILLE_SEL);
        effacer_memoire(users[i].hash, TAILLE_HASH);
    }
}


/* ==================== Fonctionnalités ==================== */

// Enregistrement d'un nouvel utilisateur
void register_user(void) {
    char username[64], password[128], confirm[128];

    printf("=== ENREGISTREMENT ===\n");
    if(lire_ligne("Username: ", username, sizeof(username)) != LECTURE_OK) return;
    if(!nom_valide(username)) {
        printf("Nom invalide : 3 à %d caractères, lettres, chiffres et '_'\n", MAX_NOM);
        return;
    }
    if(lire_ligne("Password: ", password, sizeof(password)) != LECTURE_OK) return;
    if(lire_ligne("Confirmer password: ", confirm, sizeof(confirm)) != LECTURE_OK) return;

    /* Correction 6 : vulnerable.c demandait "Droits admin (1=oui, 0=non)"
     * (lignes 69-74) et recopiait la réponse dans admin_flag. */
    if(creer_compte(username, password, 0, 100) >= 0)
        printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(const char *username, const char *password) {
    int id = chercher_user(username);

    if(id < 0) return -1;

    /* BONUS anti-bruteforce : vulnerable.c (lignes 327-337) autorisait un
     * nombre illimité de tentatives, un script pouvait donc essayer des
     * milliers de mots de passe sans jamais être ralenti. */
    if(users[id].echecs >= MAX_ECHECS) {
        printf("Compte verrouillé après %d échecs\n", MAX_ECHECS);
        return -1;
    }
    if(!verifier_mdp(id, password)) {
        users[id].echecs++;
        return -1;
    }
    users[id].echecs = 0;
    return id;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    if(lire_ligne("Format d'affichage personnalisé: ", format, sizeof(format)) != LECTURE_OK)
        return;
    /* Correction 2 - ligne 106 : printf(format) laissait l'utilisateur fournir
     * la chaîne de format elle-même ; %p lisait la pile et %n y écrivait. */
    printf("%s\n", format);
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[64];
    long amount = 0;
    int to_user;

    printf("=== TRANSFERT ===\n");
    if(lire_ligne("Vers quel utilisateur: ", to_username, sizeof(to_username)) != LECTURE_OK)
        return;
    if((to_user = chercher_user(to_username)) < 0) {
        printf("Utilisateur destinataire introuvable\n");
        return;
    }

    /* Correction 8 - ligne 120 : le montant n'était pas contrôlé. Un montant
     * négatif inversait le sens du transfert et vidait le compte visé. */
    if(lire_entier("Montant: ", 1, 1000000, &amount) != LECTURE_OK) return;
    if(users[from_user].balance < amount) {
        printf("Solde insuffisant\n");
        return;
    }

    users[from_user].balance -= (int)amount;
    users[to_user].balance += (int)amount;
    printf("Transfert effectué!\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char nom[64], chemin[128];
    FILE *fp;

    if(lire_ligne("Nom du fichier de backup: ", nom, sizeof(nom)) != LECTURE_OK) return;
    /* Correction 7 - ligne 139 : le nom allait tel quel dans fopen(), donc
     * "../../.ssh/authorized_keys" écrasait n'importe quel fichier accessible. */
    if(!fichier_valide(nom)) {
        printf("Nom de fichier invalide : lettres, chiffres, '_' et '-' uniquement\n");
        return;
    }

    /* préfixe et suffixe constants : l'écriture reste dans le répertoire courant */
    snprintf(chemin, sizeof(chemin), "backup_%s.txt", nom);
    if((fp = fopen(chemin, "w")) == NULL) {
        printf("Impossible de créer le backup\n");
        return;
    }
    /* Correction 5 - ligne 145 : le mot de passe en clair était écrit ici */
    fprintf(fp, "%s:%d:%d\n", users[user_id].username,
            users[user_id].admin_flag, users[user_id].balance);
    fclose(fp);
    printf("Backup créé : %s\n", chemin);
}

// Restauration des données
void restore_user_data(void) {
    char nom[64], chemin[128], buffer[256];
    FILE *fp;

    if(lire_ligne("Fichier à restaurer: ", nom, sizeof(nom)) != LECTURE_OK) return;
    /* Correction 7 - ligne 160 : n'importe quel chemin était accepté, donc
     * "../../../etc/passwd" était affiché sur la sortie standard. */
    if(!fichier_valide(nom)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    snprintf(chemin, sizeof(chemin), "backup_%s.txt", nom);
    if((fp = fopen(chemin, "r")) == NULL) {
        printf("Fichier introuvable\n");
        return;
    }
    while(fgets(buffer, sizeof(buffer), fp)) printf("%s", buffer);
    fclose(fp);
}

// Exécution de commandes système
void system_command(void) {
    long choix = 0;
    int r = 0;

    printf("=== COMMANDE SYSTÈME ===\n");
    printf("1. Date du système\n2. Espace disque\n0. Annuler\n");
    if(lire_entier("Choix: ", 0, 2, &choix) != LECTURE_OK) return;

    /* Correction 3 - ligne 183 : la saisie était concaténée dans la commande
     * passée au shell, donc "x ; cat /etc/passwd" s'exécutait. Ici les
     * commandes sont des constantes, avec un chemin absolu pour ignorer $PATH. */
    switch(choix) {
        case 1: r = system("/bin/date"); break;
        case 2: r = system("/bin/df -h"); break;
        default: return;
    }
    if(r != 0) printf("La commande s'est terminée anormalement\n");  /* ligne 184 */
}

// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[MAX_NOM + 1];  /* taille du champ de destination */
    char *token;

    if(lire_ligne("Nom du clone: ", target_username, sizeof(target_username)) != LECTURE_OK)
        return;
    if(!nom_valide(target_username)) {
        printf("Nom invalide\n");
        return;
    }
    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    /* Correction 9 : vulnerable.c laissait le champ token non initialisé ici
     * (lignes 199-204), ce qui devient un free() invalide dès qu'on libère. */
    if((token = generer_token()) == NULL) {
        printf("Erreur interne : allocation impossible\n");
        return;
    }

    snprintf(users[user_count].username, sizeof(users[user_count].username),
             "%s", target_username);
    memcpy(users[user_count].sel, users[source_id].sel, TAILLE_SEL);
    memcpy(users[user_count].hash, users[source_id].hash, TAILLE_HASH);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;
    users[user_count].echecs = 0;
    users[user_count].token = token;

    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users(void) {
    int i;

    printf("\n=== LISTE UTILISATEURS ===\n");
    for(i = 0; i < user_count; i++)
        printf("%d. %s (Balance: %d€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[128], new_pass[128];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    if(lire_ligne("Ancien mot de passe: ", old_pass, sizeof(old_pass)) != LECTURE_OK) return;

    /* Correction 6 - ligne 226 : "master_reset_2024" était accepté à la place
     * du mot de passe. La porte dérobée est supprimée. */
    if(!verifier_mdp(user_id, old_pass)) {
        printf("Ancien mot de passe incorrect\n");
        return;
    }
    if(lire_ligne("Nouveau mot de passe: ", new_pass, sizeof(new_pass)) != LECTURE_OK) return;

    /* Correction 4 - ligne 230 : strcpy() copiait jusqu'à 80 octets dans un
     * champ de 16. password commençant à l'offset 16 de la structure, 17
     * caractères suffisaient à écrire dans admin_flag (offset 32) et à ouvrir
     * le menu 7. Nouveau sel, sinon deux mots de passe identiques donneraient
     * le même condensé. */
    if(RAND_bytes(users[user_id].sel, TAILLE_SEL) != 1) {
        printf("Erreur interne : générateur aléatoire indisponible\n");
        return;
    }
    hash_password(users[user_id].sel, new_pass, users[user_id].hash);
    printf("Mot de passe changé\n");
}

// Calculer statistiques
void compute_stats(void) {
    int total = 0;
    double avg;
    char buffer[120];
    int i;

    for(i = 0; i < user_count; i++) total += users[i].balance;
    avg = (double)total / user_count;

    /* ligne 249 : sprintf ne débordait pas ici (50 octets au maximum pour un
     * tampon de 120), mais snprintf borne l'écriture quoi qu'il arrive. */
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user(void) {
    char query[100];
    int i;

    if(lire_ligne("Rechercher: ", query, sizeof(query)) != LECTURE_OK) return;

    for(i = 0; i < user_count; i++)
        if(strstr(users[i].username, query))
            printf("Trouvé: %s\n", users[i].username);
}

// Nettoyer les sessions
void cleanup_sessions(void) {
    time_t now = time(NULL);
    int i;

    for(i = 0; i < session_count; i++)
        if(now - sessions[i].created > 3600)
            printf("Session %d expirée\n", i);
}

// Afficher menu
void display_menu(void) {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main(void) {
    long choice = 0;
    int logged_user = -1, running = 1, r;
    char username[64], password[128], mdp_admin[13];

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - VERSION SÉCURISÉE       ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    // Compte admin par défaut
    /* Correction 6 - lignes 310-311 : "admin" / "admin123" étaient écrits en
     * dur, donc visibles dans le binaire avec un simple `strings`. */
    generer_mdp_aleatoire(mdp_admin, sizeof(mdp_admin));
    if(creer_compte("admin", mdp_admin, 1, 10000) < 0) {
        cleanup();
        return 1;
    }
    printf("Compte administrateur : admin / %s\n", mdp_admin);
    printf("Changez-le via le menu 10.\n");
    effacer_memoire(mdp_admin, sizeof(mdp_admin));

    while(running) {
        display_menu();

        /* Correction 10 - ligne 320 : scanf("%d") sans contrôle du retour. Sur
         * stdin fermé ou redirigé, il échouait sans rien écrire et la boucle
         * while(1) tournait indéfiniment. */
        r = lire_entier("", 0, 12, &choice);
        if(r == LECTURE_EOF) {
            printf("\nFin d'entrée, fermeture\n");
            running = 0;
            continue;
        }
        if(r != LECTURE_OK) continue;

        switch((int)choice) {
            case 1:
                register_user();
                break;
            case 2:
                if(lire_ligne("Username: ", username, sizeof(username)) != LECTURE_OK) break;
                if(lire_ligne("Password: ", password, sizeof(password)) != LECTURE_OK) break;
                logged_user = login_user(username, password);
                effacer_memoire(password, sizeof(password));
                if(logged_user >= 0) printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                else printf("✗ Échec de connexion\n");
                break;
            case 3:
                if(logged_user >= 0) show_profile(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 4:
                if(logged_user >= 0) transfer_money(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 5:
                if(logged_user >= 0) backup_user_data(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) system_command();
                else printf("Accès refusé\n");
                break;
            case 8:
                if(logged_user >= 0) clone_user(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) change_password(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                running = 0;
                break;
            default:
                printf("Choix invalide\n");
                break;
        }
    }

    /* Correction 9 : point de sortie unique. vulnerable.c faisait return 0
     * depuis le switch (ligne 394), sans jamais libérer les jetons. */
    cleanup();
    return 0;
}
