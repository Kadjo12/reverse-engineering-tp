/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Version sécurisée : secure.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10
#define HASH_STR_LEN 65

typedef struct {
    char username[32];
    char password_hash[HASH_STR_LEN];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// Nettoyage du buffer de saisie stdin
void clear_stdin() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Lecture sécurisée d'une chaîne depuis stdin sans saut de ligne final
void read_input(char *buf, size_t size) {
    if (fgets(buf, size, stdin) != NULL) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
        } else {
            clear_stdin();
        }
    } else {
        buf[0] = '\0';
    }
}

// Validation d'un nom d'utilisateur (alphanumérique uniquement)
int is_valid_username(const char *name) {
    size_t len = strlen(name);
    if (len < 3 || len >= 32) return 0;
    for (size_t i = 0; i < len; i++) {
        if (!isalnum((unsigned char)name[i]) && name[i] != '_') {
            return 0;
        }
    }
    return 1;
}

// Validation basique de nom de fichier (empécher path traversal)
int is_valid_filename(const char *filename) {
    size_t len = strlen(filename);
    if (len == 0 || len > 50) return 0;
    if (strstr(filename, "..") != NULL || strchr(filename, '/') != NULL || strchr(filename, '\\') != NULL) {
        return 0;
    }
    return 1;
}

// Hashage SHA-256 avec OpenSSL
void hash_password_sha256(const char *pass, char *output_hex) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char*)pass, strlen(pass), hash);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(output_hex + (i * 2), "%02x", hash[i]);
    }
    output_hex[64] = '\0';
}

// Libération de la mémoire allouée dynamiquement
void cleanup_all() {
    for (int i = 0; i < user_count; i++) {
        if (users[i].token != NULL) {
            free(users[i].token);
            users[i].token = NULL;
        }
    }
}

// Enregistrement d'un utilisateur
void register_user() {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint.\n");
        return;
    }
    
    char username[64];
    char password[64];
    char confirm[64];
    char admin_str[16];
    char hash_buf[HASH_STR_LEN];
    int admin = 0;
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username (alphanumérique, 3-31 car.): ");
    read_input(username, sizeof(username));
    
    if (!is_valid_username(username)) {
        printf("Erreur : Nom d'utilisateur invalide.\n");
        return;
    }
    
    // Vérification unicité du nom d'utilisateur
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            printf("Erreur : Nom d'utilisateur déjà pris.\n");
            return;
        }
    }
    
    printf("Password: ");
    read_input(password, sizeof(password));
    
    printf("Confirmer password: ");
    read_input(confirm, sizeof(confirm));
    
    if (strcmp(password, confirm) != 0) {
        printf("Erreur : Mots de passe non identiques.\n");
        return;
    }
    
    printf("Droits admin (1=oui, 0=non): ");
    read_input(admin_str, sizeof(admin_str));
    admin = atoi(admin_str);
    if (admin != 0 && admin != 1) admin = 0;
    
    strncpy(users[user_count].username, username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    
    hash_password_sha256(password, hash_buf);
    strncpy(users[user_count].password_hash, hash_buf, sizeof(users[user_count].password_hash) - 1);
    users[user_count].password_hash[sizeof(users[user_count].password_hash) - 1] = '\0';
    
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;
    
    users[user_count].token = malloc(64);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, username);
    }
    
    user_count++;
    printf("Utilisateur enregistré avec succès !\n");
}

// Connexion utilisateur
int login_user(const char *username, const char *password) {
    char hash_buf[HASH_STR_LEN];
    hash_password_sha256(password, hash_buf);
    
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 && 
            strcmp(users[i].password_hash, hash_buf) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    printf("Token: %s\n", users[user_id].token ? users[user_id].token : "N/A");
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    if (from_user < 0 || from_user >= user_count) return;
    
    char to_username[64];
    char amount_str[32];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    read_input(to_username, sizeof(to_username));
    
    printf("Montant: ");
    read_input(amount_str, sizeof(amount_str));
    amount = atoi(amount_str);
    
    if (amount <= 0) {
        printf("Erreur : Le montant doit être strictement positif.\n");
        return;
    }
    
    if (users[from_user].balance < amount) {
        printf("Erreur : Solde insuffisant.\n");
        return;
    }
    
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            if (i == from_user) {
                printf("Erreur : Impossible de transférer à soi-même.\n");
                return;
            }
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué avec succès !\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable.\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;
    
    char filename[64];
    FILE *fp;
    
    printf("Nom du fichier de backup (caractères simples, pas de chemin): ");
    read_input(filename, sizeof(filename));
    
    if (!is_valid_filename(filename)) {
        printf("Erreur : Nom de fichier invalide ou dangereux.\n");
        return;
    }
    
    fp = fopen(filename, "w");
    if (fp) {
        fprintf(fp, "%s:%s:%d:%d\n", 
                users[user_id].username,
                users[user_id].password_hash,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé avec succès.\n");
    } else {
        printf("Erreur lors de la création du fichier.\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[64];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    read_input(filename, sizeof(filename));
    
    if (!is_valid_filename(filename)) {
        printf("Erreur : Nom de fichier invalide.\n");
        return;
    }
    
    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable ou inaccessible.\n");
        return;
    }
    
    printf("--- Contenu du fichier ---\n");
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commande (remplacée par une action interne sécurisée)
void system_command() {
    printf("=== MAINTENANCE SYSTÈME ===\n");
    printf("Exécution des vérifications système de routine...\n");
    printf("État système: OK. Mémoire allouée nettoyée.\n");
}

// Copie de données utilisateur
void clone_user(int source_id) {
    if (source_id < 0 || source_id >= user_count) return;
    
    if (user_count >= MAX_USERS) {
        printf("Limite d'utilisateurs atteinte.\n");
        return;
    }
    
    char target_username[64];
    printf("Nom du clone: ");
    read_input(target_username, sizeof(target_username));
    
    if (!is_valid_username(target_username)) {
        printf("Erreur : Nom de clone invalide.\n");
        return;
    }
    
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, target_username) == 0) {
            printf("Erreur : Ce nom est déjà pris.\n");
            return;
        }
    }
    
    strncpy(users[user_count].username, target_username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    
    strncpy(users[user_count].password_hash, users[source_id].password_hash, sizeof(users[user_count].password_hash) - 1);
    users[user_count].password_hash[sizeof(users[user_count].password_hash) - 1] = '\0';
    
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;
    
    users[user_count].token = malloc(64);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, target_username);
    }
    
    user_count++;
    printf("Clone créé avec succès !\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    if (user_id < 0 || user_id >= user_count) return;
    
    char old_pass[64];
    char new_pass[64];
    char old_hash[HASH_STR_LEN];
    char new_hash[HASH_STR_LEN];
    
    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    read_input(old_pass, sizeof(old_pass));
    
    hash_password_sha256(old_pass, old_hash);
    
    if (strcmp(users[user_id].password_hash, old_hash) == 0) {
        printf("Nouveau mot de passe: ");
        read_input(new_pass, sizeof(new_pass));
        
        hash_password_sha256(new_pass, new_hash);
        strncpy(users[user_id].password_hash, new_hash, sizeof(users[user_id].password_hash) - 1);
        users[user_id].password_hash[sizeof(users[user_id].password_hash) - 1] = '\0';
        
        printf("Mot de passe changé avec succès.\n");
    } else {
        printf("Ancien mot de passe incorrect.\n");
    }
}

// Calculer statistiques
void compute_stats() {
    if (user_count == 0) {
        printf("Aucun utilisateur enregistre.\n");
        return;
    }
    
    long total = 0;
    double avg;
    char buffer[128];
    
    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    snprintf(buffer, sizeof(buffer), "Total: %ld€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[64];
    
    printf("Rechercher: ");
    read_input(query, sizeof(query));
    
    if (strlen(query) == 0) return;
    
    int found = 0;
    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
            found = 1;
        }
    }
    if (!found) {
        printf("Aucun utilisateur ne correspond à la recherche.\n");
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Maintenance système           ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    char input_buf[16];
    int choice;
    int logged_user = -1;
    char username[64], password[64];
    char admin_hash[HASH_STR_LEN];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║       SYSTÈME SECURISE ET CORRIGE        ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    // Initialisation sécurisée du compte admin
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    users[0].username[sizeof(users[0].username) - 1] = '\0';
    
    hash_password_sha256("admin123", admin_hash);
    strncpy(users[0].password_hash, admin_hash, sizeof(users[0].password_hash) - 1);
    users[0].password_hash[sizeof(users[0].password_hash) - 1] = '\0';
    
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(64);
    if (users[0].token != NULL) {
        strncpy(users[0].token, "ADMIN_TOKEN_SECURE", 63);
        users[0].token[63] = '\0';
    }
    user_count = 1;
    
    while (1) {
        display_menu();
        read_input(input_buf, sizeof(input_buf));
        choice = atoi(input_buf);
        
        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                read_input(username, sizeof(username));
                printf("Password: ");
                read_input(password, sizeof(password));
                logged_user = login_user(username, password);
                if (logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion (identifiants incorrects)\n");
                }
                break;
            case 3:
                if (logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter.\n");
                }
                break;
            case 4:
                if (logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter.\n");
                }
                break;
            case 5:
                if (logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter.\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé.\n");
                }
                break;
            case 8:
                if (logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter.\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter.\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir !\n");
                cleanup_all();
                return 0;
            default:
                printf("Choix invalide.\n");
        }
    }
    
    cleanup_all();
    return 0;
}