# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : OLIVIER Maxence  
**Date** : 30/07/2026 
**Durée** : 4 heures

---

## TABLE DES MATIÈRES
1. [Synthèse des vulnérabilités](#synthèse)
2. [Corrections détaillées](#corrections)
3. [Tests de validation](#tests)
4. [Conclusion](#conclusion)

---

## 1. SYNTHÈSE DES VULNÉRABILITÉS <a name="synthèse"></a>

### Tableau récapitulatif

| # | Fonction | Ligne(s) | Type | Gravité | Corrigée |
|---|----------|----------|------|---------|----------|
| 1 | hash_password() | 39-44 | Algorithme de hashage personnalisée et non cryptographique | Haute | X Oui ☐ Non |
| 2 | register_user() | 61, 64, 67 | Entrées non limitées avec scanf("%s") | Haute | X Oui ☐ Non |
| 3 | register_user() | 72-73 | Copies sans limite de taille avec strcpy() | Critique | X Oui ☐ Non |
| 4 | register_user() | 78 | Construction sans limite de taille avec sprintf() | Haute | X Oui ☐ Non |
| 5 | show_profile() | 105 | Lecture sans limite de taille avec gets() | Critique | X Oui ☐ Non |
| 6 | transfer_money() | 117 | Entrée non limitée avec scanf("%s") | Haute | ☐ Oui ☐ Non |
| 7 | backup_user_data() | 139 | Entrée non limitée avec scanf("%s") | Haute | ☐ Oui ☐ Non |
| 8 | restore_user_data() | 160 | Entrée non limitée avec scanf("%s") | Haute | ☐ Oui ☐ Non |
| 9 | system_command() | 181 | Lecture sans limite de taille avec gets() | Critique | X Oui ☐ Non |
| 10 | system_command() | 183 | Construction sans limite de taille avec sprintf() | Haute | ☐ Oui ☐ Non |
| 11 | system_command() | 184 | Injection de commandes via system() | Critique | ☐ Oui ☐ Non |
| 12 | clone_user() | 192 | Entrée non limitée avec scanf("%s") | Haute | ☐ Oui ☐ Non |
| 13 | clone_user() | 199-200 | Copies sans limite de taille avec strcpy() | Critique | ☐ Oui ☐ Non |
| 14 | change_password() | 224, 229 | Lectures sans limite de taille avec gets() | Critique | X Oui ☐ Non |
| 15 | change_password() | 230 | Copie sans limite de taille avec strcpy() | Critique | ☐ Oui ☐ Non |
| 16 | compute_stats() | 249 | Construction sans limite de taille avec sprintf() | Moyenne | ☐ Oui ☐ Non |
| 17 | search_user() | 258 | Entrée non limitée avec scanf("%s") | Haute | ☐ Oui ☐ Non |
| 18 | main() | 310, 311, 315 | Copies sans limite de taille avec strcpy() | Haute | ☐ Oui ☐ Non |
| 19 | main() | 329, 331 | Entrées de connexion non limitées avec scanf("%s") | Critique | ☐ Oui ☐ Non |
| 20 | transfer_money() | 119-125 | Montant négatif accepté lors d’un transfert | Critique | X Oui ☐ Non |
| 21 | register_user()  | 69-70 | Ajout de droit admin pour chaque création de compte | Critique | X Oui ☐ Non |


**Total de vulnérabilités identifiées** : 21

---

## 2. CORRECTIONS DÉTAILLÉES <a name="corrections"></a>

> Chaque correction doit contenir les 4 sections obligatoires.

---

### Correction #1 : hashage personnalisée

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `hash_password()`  
**Ligne(s)** : 39-44

**Description** :
```
La fonction utilise un algorithme de hashage personnalisé qui n’est pas
adapté à la protection des mots de passe. Le résultat est stocké dans un
simple unsigned int et l’algorithme est très rapide, ce qui facilite les
attaques par dictionnaire ou par force brute.

De plus, les mots de passe étaient initialement stockés en clair dans la
structure User au lieu de stocker uniquement leur empreinte.
```

**Code vulnérable** :
```c
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;

    while ((c = *pass++))
        h = h * 33 + c;

    return h;
}
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```
Si un attaquant récupère les "hash" des mots de passe, il peut reproduire
très facilement cet algorithme et tester une wordlist.

Par exemple, il peut calculer successivement les "hash" de "admin",
"admin123", "password" ou "123456" jusqu'à trouver une valeur correspondante.

Comme le résultat est limité à la taille d'un unsigned int, plusieurs mots de
passe différents peuvent également produire la même valeur. La découverte du
mot de passe d'un administrateur pourrait permettre la compromission de son
compte.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service (crash)
- [ ] Élévation de privilèges
- [X] Fuite d'informations
- [X] Autre : compromission des mots de passe

#### ✅ Correction implémentée

**Code corrigé** :
```c
#include <openssl/sha.h>
#include <string.h>

void hash_password(const char *password,
                   unsigned char hash[SHA256_DIGEST_LENGTH]) {
    SHA256((const unsigned char *)password, strlen(password), hash);
}
```

**À l’inscription, le mot de passe est hashé avant son stockage :**

```c
hash_password(password, users[user_count].password_hash);
```

**À la connexion, le hash du mot de passe saisi est calculé puis comparé au hash enregistré :**

```c
unsigned char entered_hash[SHA256_DIGEST_LENGTH];

hash_password(password, entered_hash);

if (strcmp(users[i].username, username) == 0 &&
    memcmp(users[i].password_hash,
           entered_hash,
           SHA256_DIGEST_LENGTH) == 0) {
    return i;
}
```

**Modifications effectuées** :
1. Remplacement de l’algorithme personnalisé par SHA-256.
2. Modification de la structure `User` pour stocker une empreinte de 32 octets.
3. Hashage du mot de passe lors de l’inscription.
4. Comparaison des empreintes lors de la connexion.
5. Suppression du stockage direct du mot de passe en clair.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```
SHA-256 produit une empreinte de 256 bits et offre une meilleure résistance
aux collisions que l’ancien algorithme personnalisé.

Le mot de passe n’est plus stocké directement dans la structure User.
Lors d’une connexion, le programme calcule l’empreinte du mot de passe saisi
et la compare à l’empreinte enregistrée.

La bibliothèque OpenSSL fournit une implémentation standard de SHA-256,
ce qui évite d’utiliser un algorithme cryptographique inventé dans le programme.
```

**Tests effectués** :
```bash
# Compilation avec la bibliothèque OpenSSL
gcc -Wall -Wextra -o secure secure.c -lcrypto

# Vérification de l’utilisation de SHA-256
grep -n "SHA256" secure.c

# Vérification de la suppression de l’ancien algorithme
grep -n 'h = h \* 33' secure.c

# Test fonctionnel
./secure
```

---

### Correction #2 : Entrées non limitées avec scanf("%s")

#### 🔴 Vulnérabilité originale
**Fonction concernée** : register_user()
**Ligne(s)** : 61, 64, 67

**Description** :
```text
Les trois appels à scanf("%s") lisent les données sans préciser de taille
maximale. Un utilisateur peut donc saisir une chaîne plus grande que les
tableaux username, password ou confirm.

Cela peut provoquer un dépassement de tampon, modifier d’autres données en
mémoire ou faire planter le programme.
```

**Code vulnérable** :
```c
printf("Username: ");
scanf("%s", username);

printf("Password: ");
scanf("%s", password);

printf("Confirmer password: ");
scanf("%s", confirm);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```text
Un attaquant peut saisir une chaîne contenant plusieurs centaines de
caractères à la place du nom d’utilisateur ou du mot de passe.

Par exemple :

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

Comme scanf("%s") ne contrôle pas la quantité de caractères copiés, la saisie
peut dépasser la taille du tableau et corrompre la mémoire du programme.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption de la mémoire 

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("Username: ");
if (scanf("%99s", username) != 1) {
    printf("Erreur de saisie\n");
    return;
}

printf("Password: ");
if (scanf("%99s", password) != 1) {
    printf("Erreur de saisie\n");
    return;
}

printf("Confirmer password: ");
if (scanf("%99s", confirm) != 1) {
    printf("Erreur de saisie\n");
    return;
}
```

**Modifications effectuées** :
1. Ajout d’une largeur maximale de 99 caractères aux trois appels à `scanf()`.
2. Conservation d’un octet disponible pour le caractère de fin `\0`.
3. Vérification de la valeur retournée par `scanf()`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```text
Les tableaux username, password et confirm possèdent une taille de 100
caractères. Le format "%99s" limite la saisie à 99 caractères et réserve le
dernier octet pour le caractère nul de fin de chaîne.

La saisie ne peut donc plus dépasser la capacité de ces tableaux. La valeur
retournée par scanf() est également vérifiée afin de détecter une erreur de
lecture.
```

**Tests effectués** :
```bash
# Compilation
gcc -Wall -Wextra -o secure secure.c -lcrypto

# Lancement du programme
./secure

# Test avec une entrée très longue
python3 -c 'print("A" * 200)'
```

---

### Correction #3 : Copies sans contrôle de taille avec strcpy()

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`  
**Ligne(s)** : 72-73

**Description** :
```text
La fonction strcpy() copie toute la chaîne source sans vérifier la taille
du tableau de destination.

Les champs username et password de la structure User avaient une taille de
16 octets. Une entrée trop longue pouvait donc dépasser ces tableaux et
écraser d’autres données en mémoire.
```

**Code vulnérable** :
```c
strcpy(users[user_count].username, username);
strcpy(users[user_count].password, password);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```text
Un attaquant peut saisir un nom d’utilisateur contenant plus de 15 caractères.

Par exemple :
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

strcpy() tente de copier toute la chaîne dans le tableau username[16].
Les caractères supplémentaires sont écrits en dehors du tableau, ce qui peut
corrompre la mémoire ou provoquer l’arrêt du programme.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption de la mémoire

#### ✅ Correction implémentée

**Code corrigé** :
```c
if (strlen(username) >= sizeof(users[user_count].username)) {
    printf("Nom d'utilisateur trop long\n");
    return;
}

strncpy(users[user_count].username,
        username,
        sizeof(users[user_count].username) - 1);

users[user_count].username[
    sizeof(users[user_count].username) - 1
] = '\0';

hash_password(password, users[user_count].password_hash);
```

**Modifications effectuées** :
1. Vérification de la longueur du nom d’utilisateur avant la copie.
2. Remplacement de `strcpy()` par `strncpy()` avec une taille maximale.
3. Ajout manuel du caractère de fin de chaîne `'\0'`.
4. Remplacement de la copie du mot de passe par le stockage de son hash.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```text
La longueur du nom est vérifiée avant la copie. Un nom trop long est donc
refusé.

strncpy() copie au maximum 15 caractères dans le tableau username[16].
La dernière case est explicitement remplie avec '\0', ce qui garantit que
le nom reste une chaîne C valide.

Le mot de passe n’est plus copié dans un petit tableau de caractères. Son
empreinte SHA-256 est calculée et stockée dans password_hash.
```

**Tests effectués** :
```bash
gcc -Wall -Wextra -o secure secure.c -lcrypto
./secure
```

```text
Test 1 : nom de 15 caractères → inscription acceptée.
Test 2 : nom de plus de 15 caractères → inscription refusée.
Test 3 : programme stable, sans dépassement de tampon.
```

---

### Correction #4 : Construction du token sans limite de taille

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `register_user()`  
**Ligne(s)** : 77-78

**Description** :
```text
La fonction sprintf() construit le token sans connaître la taille de la zone
mémoire de destination.

La mémoire réservée au token contient seulement 32 octets. Si le texte généré
dépasse cette taille, sprintf() continue d’écrire au-delà de la zone allouée,
ce qui peut provoquer un dépassement de tampon.

De plus, le résultat de malloc() n’était pas vérifié avant l’utilisation du
pointeur.
```

**Code vulnérable** :
```c
users[user_count].token = malloc(32);
sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```text
Un attaquant peut fournir un nom d’utilisateur suffisamment long pour que le
token généré dépasse les 32 octets disponibles.

sprintf() écrit alors après la zone mémoire allouée, ce qui peut corrompre la
mémoire ou provoquer l’arrêt du programme.

Si malloc() échoue, le pointeur vaut NULL. L’utilisation directe de ce pointeur
par sprintf() peut également provoquer un crash.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption de la mémoire

#### ✅ Correction implémentée

**Code corrigé** :
```c
#define TOKEN_SIZE 32

users[user_count].token = malloc(TOKEN_SIZE);

if (users[user_count].token == NULL) {
    printf("Erreur d'allocation mémoire\n");
    return;
}

int result = snprintf(users[user_count].token,
                      TOKEN_SIZE,
                      "TOK_%d_%s",
                      user_count,
                      username);

if (result < 0 || result >= TOKEN_SIZE) {
    printf("Erreur : token trop long\n");

    free(users[user_count].token);
    users[user_count].token = NULL;

    return;
}
```

**Fonction de nettoyage ajoutée** :
```c
void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}
```

**Appel du nettoyage avant la fermeture du programme** :
```c
case 0:
    cleanup();
    printf("Au revoir!\n");
    return 0;
```

**Modifications effectuées** :
1. Remplacement de `sprintf()` par `snprintf()`.
2. Limitation de l’écriture à `TOKEN_SIZE`, soit 32 octets.
3. Vérification du résultat de `malloc()`.
4. Vérification d’une erreur ou d’une troncature avec le retour de `snprintf()`.
5. Libération immédiate de la mémoire si la création du token échoue.
6. Ajout de `cleanup()` pour libérer les tokens à la fermeture du programme.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```text
snprintf() connaît la taille de la zone mémoire de destination. Elle ne peut
donc pas écrire au-delà des 32 octets alloués.

La valeur retournée permet de détecter une erreur ou un token trop long. Dans
ce cas, la mémoire précédemment allouée est immédiatement libérée avec free().

Lorsque la création réussit, le token doit rester disponible pendant
l’utilisation du compte. Il n’est donc pas libéré immédiatement. Il est libéré
à la fermeture du programme par la fonction cleanup().

La mise à NULL du pointeur après free() évite de conserver un pointeur vers une
zone mémoire qui n’est plus valide.
```

**Tests effectués** :
```bash
# Compilation
gcc -Wall -Wextra -o secure secure.c -lcrypto

# Vérification de la suppression de sprintf()
grep -n "sprintf" secure.c

# Vérification de l’utilisation de snprintf()
grep -n "snprintf" secure.c

# Vérification des allocations et libérations
grep -nE "malloc|free" secure.c

# Test du programme
./secure

# Vérification des fuites mémoire
valgrind --leak-check=full --show-leak-kinds=all ./secure
```

---

### Par manque de temps je vais regrouper les corrections par chaque appel

### Correction #5 : Lectures sans limite de taille avec gets()

#### 🔴 Vulnérabilité originale
**Fonctions concernées** : `show_profile()`, `system_command()`, `change_password()`  
**Ligne(s)** : 105, 181, 224, 229

**Description** :
```text
La fonction gets() lit une entrée utilisateur sans connaître la taille du
tableau de destination.

Si l’utilisateur entre plus de caractères que le tableau ne peut en contenir,
gets() écrit en dehors du tableau. Cela provoque un dépassement de tampon et
peut corrompre la mémoire ou faire planter le programme.
```

**Code vulnérable** :
```c
gets(format);
gets(cmd);
gets(old_pass);
gets(new_pass);
```

#### 💥 Attaque possible

**Scénario d'exploitation** :
```text
Un attaquant peut saisir une chaîne contenant plusieurs centaines de
caractères dans l’un des champs concernés.

Par exemple :

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

Comme gets() ne limite pas la taille de la saisie, les caractères peuvent être
écrits au-delà du tableau prévu et modifier d’autres données en mémoire.
```

**Impact** :
- [x] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [x] Déni de service (crash)
- [ ] Élévation de privilèges
- [ ] Fuite d'informations
- [x] Autre : corruption de la mémoire

#### ✅ Correction implémentée

**Code corrigé dans `show_profile()`** :
```c
if (fgets(format, sizeof(format), stdin) == NULL) {
    return;
}

format[strcspn(format, "\n")] = '\0';
printf("%s", format);
```

**Code corrigé dans `system_command()`** :
```c
if (fgets(cmd, sizeof(cmd), stdin) == NULL) {
    return;
}

cmd[strcspn(cmd, "\n")] = '\0';
```

**Code corrigé dans `change_password()` pour l’ancien mot de passe** :
```c
if (fgets(old_pass, sizeof(old_pass), stdin) == NULL) {
    return;
}
old_pass[strcspn(old_pass, "\n")] = '\0';
```

**Code corrigé dans `change_password()` pour le nouveau mot de passe** :
```c
if (fgets(new_pass, sizeof(new_pass), stdin) == NULL) {
return;
}
new_pass[strcspn(new_pass, "\n")] = '\0';
```

**Modifications effectuées** :
1. Remplacement des quatre appels à `gets()` par `fgets()`.
2. Utilisation de `sizeof()` pour limiter la quantité de caractères lus.
3. Vérification du retour de `fgets()`.
4. Suppression du caractère de retour à la ligne `\n`.
5. Remplacement de `printf(format)` par `printf("%s", format)` dans `show_profile()`.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```text
fgets() reçoit la taille du tableau de destination. Elle lit donc au maximum
la taille du tableau moins un caractère, puis ajoute automatiquement le
caractère de fin de chaîne '\0'.

Elle ne peut donc pas écrire en dehors du tableau.

strcspn() permet de retrouver le retour à la ligne ajouté par fgets() et de le
remplacer par '\0'.

Dans show_profile(), printf("%s", format) empêche également l’utilisateur de
contrôler le format utilisé par printf().
```

**Tests effectués** :
```bash
# Vérifier qu’il ne reste aucun véritable gets()
grep -nE '(^|[^[:alnum:]_])gets[[:space:]]*\(' secure.c

# Compiler
gcc -Wall -Wextra -o secure secure.c -lcrypto

# Lancer le programme
./secure
```

---


### Correction #6 : Validation du montant lors d’un transfert

#### 🔴 Vulnérabilité originale
**Fonction concernée** : `transfer_money()`  
**Ligne(s)** : 119-125

**Description** :
```text
Le montant saisi par l’utilisateur n’est pas vérifié avant d’être utilisé.

Le programme accepte notamment les montants négatifs. Comme le montant est
soustrait au solde de l’expéditeur, soustraire un nombre négatif augmente son
solde au lieu de le diminuer.
```

**Code vulnérable** :
```c
printf("Montant: ");
scanf("%d", &amount);

for (int i = 0; i < user_count; i++) {
    if (strcmp(users[i].username, to_username) == 0) {
        users[from_user].balance -= amount;
        users[i].balance += amount;
        printf("Transfert effectué!\n");
        return;
    }
}
```

#### 💥 Attaque possible
**Scénario d'exploitation** :
```text
Un utilisateur saisit un montant négatif, par exemple -100.

Le calcul effectué devient :

balance_expéditeur = balance_expéditeur - (-100)

Cela revient à ajouter 100 au solde de l’expéditeur. Le compte destinataire
perd également 100, car le programme lui ajoute un montant négatif.
```

**Impact** :
- [ ] Exécution de code arbitraire
- [ ] Lecture de mémoire
- [ ] Déni de service
- [ ] Élévation de privilèges
- [ ] Fuite d’informations
- [x] Autre : modification frauduleuse des soldes

#### ✅ Correction implémentée

**Code corrigé** :
```c
printf("Montant: ");

if (scanf("%d", &amount) != 1) {
    printf("Montant invalide\n");
    return;
}

if (amount <= 0) {
    printf("Le montant doit être strictement positif\n");
    return;
}

if (users[from_user].balance < amount) {
    printf("Solde insuffisant\n");
    return;
}

for (int i = 0; i < user_count; i++) {
    if (strcmp(users[i].username, to_username) == 0) {
        users[from_user].balance -= amount;
        users[i].balance += amount;

        printf("Transfert effectué!\n");
        return;
    }
}
```

**Modifications effectuées** :
1. Vérification du résultat retourné par `scanf()`.
2. Refus des montants négatifs ou nuls.
3. Vérification que l’expéditeur possède suffisamment d’argent.
4. Modification des soldes uniquement après toutes les validations.

#### 🛡️ Justification de sécurité

**Pourquoi cette correction est sûre** :
```text
Le montant doit maintenant être un entier strictement positif.

Un utilisateur ne peut donc plus augmenter son solde en saisissant un montant
négatif. Le contrôle du solde empêche également d’effectuer un transfert
supérieur à l’argent disponible.

Les soldes ne sont modifiés qu’après la validation complète du montant.
```

**Tests effectués** :
```bash
gcc -Wall -Wextra -o secure secure.c -lcrypto
./secure
```

```text
Test 1 : montant -100
Résultat attendu : "Le montant doit être strictement positif"

Test 2 : montant 0
Résultat attendu : "Le montant doit être strictement positif"

Test 3 : montant supérieur au solde
Résultat attendu : "Solde insuffisant"

Test 4 : montant positif inférieur au solde
Résultat attendu : "Transfert effectué!"
```

---


## 3. TESTS DE VALIDATION <a name="tests"></a>

### 3.1 Compilation

**Commande utilisée** :
```bash
gcc -o secure secure.c -lcrypto -Wall -Wextra
```

**Résultat** :
```
Rien à signaler, compilation réussie sans warnings ni erreurs.
```

**Nombre de warnings** : 0  
**Nombre d'erreurs** : 0

---

### 3.2 Tests fonctionnels

| Fonctionnalité | Test effectué | Résultat |
|---------------|---------------|----------|
| Création utilisateur | Tentative avec nom très long | X OK ☐ KO |
| Connexion | Login avec mauvais credentials | X OK ☐ KO |
| Transfert | Montant négatif | X OK ☐ KO |
| Backup | Nom de fichier avec `../` | ☐ OK ☐ KO |
| Commande système | Injection avec `;` | ☐ OK ☐ KO |

---

### 3.3 Analyse mémoire (Valgrind)

**Commande** :
```bash
valgrind --leak-check=full --show-leak-kinds=all ./secure
```

**Résultat** :
```
==23867== HEAP SUMMARY:
==23867==     in use at exit: 0 bytes in 0 blocks
==23867==   total heap usage: 4,856 allocs, 4,856 frees, 359,370 bytes allocated
==23867==
==23867== All heap blocks were freed -- no leaks are possible
==23867==
==23867== For lists of detected and suppressed errors, rerun with: -s
==23867== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

**Fuites détectées** : 0 bytes  
**Blocs non libérés** : 0

---

### 3.4 Tests de sécurité

**Test 1 - Buffer Overflow**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

**Test 2 - Format String**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

**Test 3 - Command Injection**
```bash
# Entrée testée :
# Résultat attendu :
# Résultat obtenu :
```

---

## 4. CONCLUSION <a name="conclusion"></a>

### 4.1 Résumé des corrections

**Statistiques** :
- Vulnérabilités CRITIQUES corrigées : 5
- Vulnérabilités HAUTES corrigées : 3
- Vulnérabilités MOYENNES corrigées : 0
- Total de lignes modifiées : ~ ????

**Principaux changements** :
1. Remplacement de l’algorithme de hashage personnalisé par SHA-256 avec OpenSSL et stockage des empreintes à la place des mots de passe en clair.
2. Remplacement des fonctions dangereuses `gets()`, `strcpy()` et `sprintf()` par des fonctions "bornées" (avec limite de taille) comme `fgets()`, `strncpy()` et `snprintf()`.
3. Ajout de validations sur les entrées utilisateur, notamment la longueur des chaînes, les montants de transfert et la gestion des allocations mémoire.

---

### 4.2 Difficultés rencontrées

**Problème 1** :
```
La cryptographie, j'ai "perdu" beaucoup de temps à comprendre comment utiliser / faire la partie concernant OpenSSL pour le hashage des mots de passe.

```

---

### 4.3 Améliorations possibles

**Sécurité** :
- [ ] Implémenter un système de salage pour les mots de passe
- [ ] Ajouter des logs de sécurité
- [ ] Limiter le nombre de tentatives de connexion
- [ ] Implémenter un système de sessions avec timeout
- [ ] Autre : _______________

**Fonctionnalité** :
- [ ] Chiffrement des données sensibles
- [ ] Audit trail complet
- [ ] Protection contre les timing attacks
- [ ] Autre : ajouter une fonction de déconnexion et une confirmation avant les opérations sensibles.

---

### 4.4 Apprentissages clés

**Ce que j'ai appris** :
1. J’ai appris à repérer les fonctions dangereuses en C, comme `gets()`, `strcpy()`, `sprintf()` et `system()`, ainsi que les risques de dépassement de tampon et d’injection.
2. J’ai appris à sécuriser les entrées utilisateur avec des fonctions limitées comme `fgets()`, `strncpy()` et `snprintf()`, et à vérifier les valeurs saisies.
3. J’ai appris à mieux gérer les mots de passe et la mémoire en utilisant SHA-256 (openssl), en vérifiant les retours de `malloc()` et en libérant la mémoire avec `free()`.

**Compétences développées** :
- [ ] Identification de vulnérabilités
- [ ] Utilisation de fonctions sécurisées
- [ ] Validation d'entrées
- [ ] Gestion mémoire rigoureuse
- [ ] Cryptographie appliquée

---

### 4.5 Auto-évaluation

| Critère | Note estimée /20 | Justification |
|---------|------------------|---------------|
| Analyse | 5 / 6 | |
| Corrections | 7 / 10 | |
| Documentation | 3,5 / 4 | |
| **TOTAL** | 15,5 /20 | |

---

## ANNEXES

### Annexe A : Checklist de vérification finale

- [X] Tous les `gets()` remplacés par `fgets()`
- [40%] Tous les `scanf("%s")` sécurisés avec taille maximale. Exemp,le : `scanf("%19s", buffer)` pour un buffer de 20 bytes
- [ ] Tous les `strcpy()` remplacés par `strncpy()`
- [ ] Tous les `strcat()` remplacés par `strncat()`
- [ ] Tous les `sprintf()` remplacés par `snprintf()`
- [X] Cryptographie utilise SHA-256
- [ ] Pas de mots de passe en clair
- [ ] Pas de backdoors
- [ ] Tous les indices de tableaux validés
- [X] Tous les `malloc()` ont un `free()` correspondant
- [X] 0 fuites mémoire (valgrind)
- [X] 0 warnings de compilation
- [ ] Validation stricte des noms de fichiers
- [ ] Protection contre command injection

### Annexe B : Références utilisées

1. 
2. 
3. 

---

**FIN DU RAPPORT**
