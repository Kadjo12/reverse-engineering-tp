/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Durée : 4 heures
 * 
 * CONSIGNE : Ce programme contient de NOMBREUSES vulnérabilités.
 * Vous devez les identifier, les corriger et documenter chaque correction.
 * 
 * Système de gestion de comptes utilisateurs avec authentification
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10
#define TOKEN_SIZE 32

typedef struct {
    char username[16];
    unsigned char password_hash[SHA256_DIGEST_LENGTH];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// Fonction de hashage personnalisée
void hash_password(const char *password,
                   unsigned char hash[SHA256_DIGEST_LENGTH]) {
    SHA256((const unsigned char *)password, strlen(password), hash);
}

// Enregistrement d'un nouvel utilisateur
void register_user() {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    
    char username[100];
    char password[100];
    char confirm[100];
    int admin;
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    if (scanf("%99s", username) != 1) {
        printf("Erreur de saisie\n");
        return;
    }

    printf("Password: ");
    if (scanf("%99s", password) != 1) {
        printf("Erreur de saisie\n");
        return;
    }

    printf("Confirmer password: ");
    if (scanf("%99s", confirm) != 1) {
        printf("Erreur de saisie\n");
        return;
    }
    
    printf("Droits admin (1=oui, 0=non): ");
    scanf("%d", &admin);
    
    if (strlen(username) >= sizeof(users[user_count].username)) {
        printf("Nom d'utilisateur trop long\n");
        return;
    }

    strncpy(users[user_count].username,
            username,
            sizeof(users[user_count].username) - 1);

    users[user_count].username[
        sizeof(users[user_count].username) - 1
    ] = '\0';

    hash_password(password, users[user_count].password_hash);

    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;
    
    users[user_count].token = malloc(TOKEN_SIZE);

    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation mémoire\n");
        return;
    }

    int result = snprintf(users[user_count].token,
                        TOKEN_SIZE,
                        "TOK_%d_%s",
                        user_count,
                        username);

    if (result < 0 || result >= TOKEN_SIZE) {
        printf("Erreur : token trop long\n");

        free(users[user_count].token);
        users[user_count].token = NULL;

        return;
    }
    
    user_count++;
    printf("Utilisateur enregistré!\n");
}

void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    unsigned char entered_hash[SHA256_DIGEST_LENGTH];

    hash_password(password, entered_hash);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 &&
            memcmp(users[i].password_hash,
                   entered_hash,
                   SHA256_DIGEST_LENGTH) == 0) {
            return i;
        }
    }

    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    
    printf("Format d'affichage personnalisé: ");
    if (fgets(format, sizeof(format), stdin) == NULL) {
        return;
    }
    format[strcspn(format, "\n")] = '\0';
    printf("%s", format);
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    scanf("%s", to_username);
    
    printf("Montant: ");

    if (scanf("%d", &amount) != 1) {
        printf("Montant invalide\n");
        return;
    }

    if (amount <= 0) {
        printf("Le montant doit être strictement positif\n");
        return;
    }

    if (users[from_user].balance < amount) {
        printf("Solde insuffisant\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;

            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;
    
    printf("Nom du fichier de backup: ");
    scanf("%s", filename);
    
    fp = fopen(filename, "w");
    if(fp) {
        fprintf(fp, "%s:%d:%d\n", 
                users[user_id].username,
                //users[user_id].password,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    scanf("%s", filename);
    
    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    char full_cmd[200];
    
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    
    if (fgets(cmd, sizeof(cmd), stdin) == NULL) {
    return;
    }

    cmd[strcspn(cmd, "\n")] = '\0';
    
    sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
    system(full_cmd);
}

// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[30];
    
    printf("Nom du clone: ");
    scanf("%s", target_username);
    
    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    
    strcpy(users[user_count].username, target_username);
    memcpy(users[user_count].password_hash, users[source_id].password_hash, SHA256_DIGEST_LENGTH);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;
    
    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[80];
    char new_pass[80];
    unsigned char old_hash[SHA256_DIGEST_LENGTH];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");

    printf("Ancien mot de passe: ");
    if (fgets(old_pass, sizeof(old_pass), stdin) == NULL) {
        return;
    }
    old_pass[strcspn(old_pass, "\n")] = '\0';

    hash_password(old_pass, old_hash);

    if (memcmp(users[user_id].password_hash,
               old_hash,
               SHA256_DIGEST_LENGTH) == 0) {

        printf("Nouveau mot de passe: ");
        if (fgets(new_pass, sizeof(new_pass), stdin) == NULL) {
            return;
        }
        new_pass[strcspn(new_pass, "\n")] = '\0';

        hash_password(new_pass, users[user_id].password_hash);

        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];
    
    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    sprintf(buffer, "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];
    
    printf("Rechercher: ");
    scanf("%s", query);
    
    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for(int i = 0; i < session_count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    // Compte admin par défaut
    strcpy(users[0].username, "admin");
    hash_password("admin123", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(TOKEN_SIZE);
    strcpy(users[0].token, "ADMIN_TOKEN");
    user_count = 1;
    
    while(1) {
        display_menu();
        scanf("%d", &choice);
        getchar();
        
        switch(choice) {
            
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                scanf("%s", username);
                printf("Password: ");
                scanf("%s", password);
                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                cleanup();
                printf("Au revoir!\n");
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }
    
    return 0;
}
