/*
 * TP FINAL NOTÉ - Version Sécurisée (secure.c)
 * 
 * Corrections appliquées :
 * 1. Utilisation de SHA-256 (OpenSSL) pour le hashage des mots de passe.
 * 2. Suppression de la fonction système dangereuse system() et des vulnérabilités d'injection.
 * 3. Remplacement de gets() et scanf("%s") par read_line() (saisie sécurisée sans buffer overflow).
 * 4. Protection contre la vulnérabilité Format String dans show_profile.
 * 5. Sanitisation des noms de fichiers (Path Traversal protection) pour backup/restore.
 * 6. Suppression de la porte dérobée (backdoor "master_reset_2024").
 * 7. Libération correcte de la mémoire dynamique (token) pour garantir 0 fuite mémoire Valgrind.
 * 8. Validation métier : vérification du solde négatif/débordement et protection contre division par zéro.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>
#include <errno.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

#define USERNAME_LEN 32
#define PASSWORD_HASH_LEN 65 // 64 caractères hexadécimaux + '\0'
#define TOKEN_LEN 64

typedef struct {
    char username[USERNAME_LEN];
    char password_hash[PASSWORD_HASH_LEN];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

/* Fonction utilitaire de saisie sécurisée */
static void read_line(char *buf, size_t size) {
    if (fgets(buf, (int)size, stdin) != NULL) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
        } else {
            // Vider le buffer d'entrée si la saisie dépasse la taille du buffer
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
        }
    } else {
        buf[0] = '\0';
    }
}

/* Fonction utilitaire pour calculer le hash SHA-256 d'une chaîne */
static void hash_password_sha256(const char *pass, char *output_hex) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char *)pass, strlen(pass), hash);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(output_hex + (i * 2), "%02x", hash[i]);
    }
    output_hex[64] = '\0';
}

/* Vérification des caractères autorisés pour un nom de fichier (anti path-traversal) */
static int is_valid_filename(const char *filename) {
    if (filename == NULL || strlen(filename) == 0 || strlen(filename) > 60) return 0;
    for (size_t i = 0; i < strlen(filename); i++) {
        if (!isalnum((unsigned char)filename[i]) && filename[i] != '_' && filename[i] != '-') {
            return 0; // Seuls les caractères alfanumériques, _ et - sont autorisés
        }
    }
    return 1;
}

/* Libération globale de la mémoire avant d'exécuter l'arrêt */
static void cleanup_memory() {
    for (int i = 0; i < user_count; i++) {
        if (users[i].token != NULL) {
            free(users[i].token);
            users[i].token = NULL;
        }
    }
}

// Enregistrement d'un nouvel utilisateur
void register_user() {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[USERNAME_LEN];
    char password[64];
    char confirm[64];

    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    read_line(username, sizeof(username));

    if (strlen(username) == 0) {
        printf("Erreur : Nom d'utilisateur invalide.\n");
        return;
    }

    // Vérification si l'utilisateur existe déjà
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            printf("Erreur : Cet utilisateur existe déjà.\n");
            return;
        }
    }

    printf("Password: ");
    read_line(password, sizeof(password));

    printf("Confirmer password: ");
    read_line(confirm, sizeof(confirm));

    if (strcmp(password, confirm) != 0) {
        printf("Erreur : Les mots de passe ne correspondent pas.\n");
        return;
    }

    // Copie sécurisée du nom d'utilisateur
    strncpy(users[user_count].username, username, USERNAME_LEN - 1);
    users[user_count].username[USERNAME_LEN - 1] = '\0';

    // Stockage du hash SHA-256 du mot de passe
    hash_password_sha256(password, users[user_count].password_hash);

    // Tous les nouveaux comptes sont créés sans privilèges administrateur
    users[user_count].admin_flag = 0;
    users[user_count].balance = 100;

    // Allocation sécurisée du token
    users[user_count].token = malloc(TOKEN_LEN);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation mémoire.\n");
        return;
    }

    snprintf(users[user_count].token,
             TOKEN_LEN,
             "TOK_%d_%s",
             user_count,
             users[user_count].username);

    user_count++;
    printf("Utilisateur enregistré avec succès !\n");
}

// Connexion utilisateur
int login_user(const char *username, const char *password) {
    char pass_hash[PASSWORD_HASH_LEN];
    hash_password_sha256(password, pass_hash);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 &&
            strcmp(users[i].password_hash, pass_hash) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Format d'affichage personnalisé: ");
    read_line(format, sizeof(format));
    
    // Correction de la vulnérabilité Format String (évite printf(format))
    printf("%s\n", format);
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[USERNAME_LEN];
    char amount_str[20];
    int amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    read_line(to_username, sizeof(to_username));

    if (strcmp(users[from_user].username, to_username) == 0) {
        printf("Impossible de transférer de l'argent à soi-même.\n");
        return;
    }

    printf("Montant: ");
    read_line(amount_str, sizeof(amount_str));
    amount = atoi(amount_str);

    if (amount <= 0) {
        printf("Montant invalide.\n");
        return;
    }

    if (users[from_user].balance < amount) {
        printf("Solde insuffisant.\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données (Sécurisé contre le Path Traversal)
void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;

    printf("Nom du fichier de backup (caractères alphanumériques uniquement): ");
    read_line(filename, sizeof(filename));

    if (!is_valid_filename(filename)) {
        printf("Erreur : Nom de fichier invalide ou potentiellement dangereux.\n");
        return;
    }

    fp = fopen(filename, "w");
    if (fp) {
        fprintf(fp, "%s:%s:%d:%d\n",
                users[user_id].username,
                users[user_id].password_hash,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé avec succès.\n");
    } else {
        printf("Erreur lors de la création du fichier.\n");
    }
}

// Restauration des données (Sécurisé contre le Path Traversal)
void restore_user_data() {
    char filename[100];
    char buffer[256];
    FILE *fp;

    printf("Fichier à restaurer (caractères alphanumériques uniquement): ");
    read_line(filename, sizeof(filename));

    if (!is_valid_filename(filename)) {
        printf("Erreur : Nom de fichier invalide.\n");
        return;
    }

    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable.\n");
        return;
    }

    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Module sécurisé : Suppression de system() dangereux
void system_command() {
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("[SÉCURITÉ] L'exécution de commandes système arbitraires via shell a été désactivée.\n");
}

// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[USERNAME_LEN];

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }

    printf("Nom du clone: ");
    read_line(target_username, sizeof(target_username));

    if (strlen(target_username) == 0) {
        printf("Nom invalide.\n");
        return;
    }

    // Vérification d'unicité
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, target_username) == 0) {
            printf("Erreur : Nom d'utilisateur déjà pris.\n");
            return;
        }
    }

    strncpy(users[user_count].username, target_username, USERNAME_LEN - 1);
    users[user_count].username[USERNAME_LEN - 1] = '\0';

    strcpy(users[user_count].password_hash, users[source_id].password_hash);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;

    users[user_count].token = malloc(TOKEN_LEN);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, TOKEN_LEN, "TOK_%d_%s", user_count, users[user_count].username);
    }

    user_count++;
    printf("Clone créé avec succès !\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe (Suppression de la backdoor "master_reset_2024")
void change_password(int user_id) {
    char old_pass[64];
    char new_pass[64];
    char old_pass_hash[PASSWORD_HASH_LEN];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    read_line(old_pass, sizeof(old_pass));

    hash_password_sha256(old_pass, old_pass_hash);

    // Vérification stricte du hash (Sans la backdoor "master_reset_2024")
    if (strcmp(users[user_id].password_hash, old_pass_hash) == 0) {
        printf("Nouveau mot de passe: ");
        read_line(new_pass, sizeof(new_pass));

        if (strlen(new_pass) == 0) {
            printf("Mot de passe invalide.\n");
            return;
        }

        hash_password_sha256(new_pass, users[user_id].password_hash);
        printf("Mot de passe changé avec succès.\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques (Protection contre la division par zéro)
void compute_stats() {
    if (user_count == 0) {
        printf("Aucun utilisateur disponible pour le calcul des statistiques.\n");
        return;
    }

    long total = 0;
    double avg;
    char buffer[120];

    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }

    avg = (double)total / user_count;

    snprintf(buffer, sizeof(buffer), "Total: %ld€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[USERNAME_LEN];

    printf("Rechercher: ");
    read_line(query, sizeof(query));

    if (strlen(query) == 0) return;

    int count = 0;
    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
            count++;
        }
    }
    if (count == 0) {
        printf("Aucun utilisateur trouvé.\n");
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE     ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                   ║\n");
    printf("║ 2. Se connecter                   ║\n");
    printf("║ 3. Voir profil                    ║\n");
    printf("║ 4. Transférer argent              ║\n");
    printf("║ 5. Backup données                 ║\n");
    printf("║ 6. Restaurer données              ║\n");
    printf("║ 7. Commande système               ║\n");
    printf("║ 8. Cloner utilisateur             ║\n");
    printf("║ 9. Liste utilisateurs             ║\n");
    printf("║ 10. Changer mot de passe          ║\n");
    printf("║ 11. Statistiques                  ║\n");
    printf("║ 12. Rechercher utilisateur        ║\n");
    printf("║ 0. Quitter                        ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    char choice_str[10];
    int choice = -1;
    int logged_user = -1;
    char username[USERNAME_LEN], password[64];

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║   TP FINAL NOTÉ - CODE SÉCURISÉ          ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    // Compte admin par défaut avec mot de passe hashé
    strncpy(users[0].username, "admin", USERNAME_LEN - 1);
    users[0].username[USERNAME_LEN - 1] = '\0';
    hash_password_sha256("admin123", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    
    users[0].token = malloc(TOKEN_LEN);
    if (users[0].token != NULL) {
        strncpy(users[0].token, "ADMIN_TOKEN", TOKEN_LEN - 1);
        users[0].token[TOKEN_LEN - 1] = '\0';
    }
    user_count = 1;

    while (1) {
        display_menu();
        read_line(choice_str, sizeof(choice_str));

        char *endptr;
        choice = strtol(choice_str, &endptr, 10);

        if (*endptr != '\0') {
        printf("Choix invalide\n");
        continue;
        }

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                read_line(username, sizeof(username));
                printf("Password: ");
                read_line(password, sizeof(password));
                logged_user = login_user(username, password);
                if (logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if (logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if (logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if (logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                cleanup_memory();
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    cleanup_memory();
    return 0;
}
