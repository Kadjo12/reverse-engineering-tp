# RAPPORT DE SÉCURITÉ - TP FINAL
**Étudiant** : PLACZEK Bastien  
**Date** : 30/07/2026  
**Durée** : 4 heures  
**Environnement** : Ubuntu / Linux x86_64 (Vagrant RE-Lab)

---

# Table des matières

1. Synthèse des vulnérabilités
2. Corrections détaillées
3. Tests de validation
4. Conclusion
5. Annexes

---

# 1. Synthèse des vulnérabilités

## 1.1 Présentation du système & Surface d'attaque

Le système étudié est une application de gestion bancaire et d'utilisateurs développée en **C**.

L'application interagit avec l'utilisateur via le flux standard **stdin** :

- noms d'utilisateurs ;
- mots de passe ;
- montants ;
- noms de fichiers ;
- chaînes de formatage.

---

## 1.2 Tableau récapitulatif

| ID | Fonction | Vulnérabilité / Risque | Code avant (Vulnérable) | Code après (Sécurisé) |
|----|----------|------------------------|--------------------------|------------------------|
| VULN-01 | register_user | Buffer Overflow sur username (**CRITIQUE**) | `scanf("%s", username);` | `read_string(username, sizeof(username));` |
| VULN-02 | register_user | Buffer Overflow sur password (**CRITIQUE**) | `scanf("%s", password);` | `read_string(password, sizeof(password));` |
| VULN-03 | register_user | Buffer Overflow sur confirm (**CRITIQUE**) | `scanf("%s", confirm);` | `read_string(confirm, sizeof(confirm));` |
| VULN-04 | register_user | Structure Overflow username (**CRITIQUE**) | `strcpy(users[idx].username, username);` | `strncpy(users[idx].username, username, USERNAME_LEN - 1);` |
| VULN-05 | register_user | Structure Overflow password (**CRITIQUE**) | `strcpy(users[idx].password, password);` | `hash_password_sha256(password, ...);` |
| VULN-06 | register_user | Élévation de privilèges Admin (**CRITIQUE**) | `scanf("%d", &admin);` | `users[user_count].admin_flag = 0;` |
| VULN-07 | register_user | Heap Overflow via `sprintf` (**ÉLEVÉ**) | `sprintf(users[idx].token, "TOK_%d_%s", ...);` | `snprintf(users[idx].token, TOKEN_LEN, ...);` |
| VULN-08 | show_profile | Buffer Overflow via `gets()` (**CRITIQUE**) | `gets(format);` | `read_string(format, sizeof(format));` |
| VULN-09 | show_profile | Format String Vulnerability (**CRITIQUE**) | `printf(format);` | `printf("%s\n", format);` |
| VULN-10 | transfer_money | Buffer Overflow sur `to_username` (**ÉLEVÉ**) | `scanf("%s", to_username);` | `read_string(to_username, sizeof(to_username));` |
| VULN-11 | transfer_money | Solde négatif autorisé (**ÉLEVÉ**) | `users[from].balance -= amount;` | `if (users[from].balance < amount) return;` |
| VULN-12 | transfer_money | Montant négatif (Vol d'argent) (**CRITIQUE**) | `scanf("%d", &amount);` | `if (amount <= 0) return;` |
| VULN-13 | backup_user_data | Buffer Overflow filename (**ÉLEVÉ**) | `scanf("%s", filename);` | `read_string(filename, sizeof(filename));` |
| VULN-14 | restore_user_data | Buffer Overflow filename (**ÉLEVÉ**) | `scanf("%s", filename);` | `read_string(filename, sizeof(filename));` |
| VULN-15 | backup_user_data | Path Traversal (`../`) (**CRITIQUE**) | `fp = fopen(filename, "w");` | `if (is_invalid_path(filename)) return;` |
| VULN-16 | restore_user_data | Path Traversal (`/etc/passwd`) (**CRITIQUE**) | `fp = fopen(filename, "r");` | `if (is_invalid_path(filename)) return;` |
| VULN-17 | backup_user_data | Fuite de mot de passe en clair (**ÉLEVÉ**) | `fprintf(fp, "%s:%s:...", pass);` | `fprintf(fp, "%s:%s:...", hash);` |
| VULN-18 | system_command | Injection de commande Shell (**CRITIQUE**) | `system(full_cmd);` | Fonction supprimée |
| VULN-19 | clone_user | Buffer Overflow target_username (**ÉLEVÉ**) | `scanf("%s", target_username);` | `read_string(target_username, sizeof(...));` |
| VULN-20 | clone_user | Structure Overflow `strcpy` (**ÉLEVÉ**) | `strcpy(users[user_count].username, target_username);` | `strncpy(users[user_count].username, target_username, USERNAME_LEN - 1);` |
| VULN-21 | change_password | Backdoor `master_reset_2024` (**CRITIQUE**) | `strcmp(...,"master_reset_2024")==0` | Condition supprimée |
| VULN-22 | change_password | Buffer Overflow (**ÉLEVÉ**) | `gets(old_pass); gets(new_pass);` | `read_string(old_pass,sizeof(...));` |
| VULN-23 | compute_stats | Division par zéro (**ÉLEVÉ**) | `avg = (double)total / user_count;` | `if (user_count == 0) return;` |
| VULN-24 | search_user | Buffer Overflow query (**MOYEN**) | `scanf("%s", query);` | `read_string(query, sizeof(query));` |
| VULN-25 | Structure User | Mot de passe en clair (**CRITIQUE**) | `char password[16];` | `char password_hash[65];` |
| VULN-26 | register_user | Retour malloc non vérifié (**MOYEN**) | `users[idx].token = malloc(32);` | Vérification `if (users[user_count].token == NULL)` |
| VULN-27 | main | Identifiants Admin par défaut (**ÉLEVÉ**) | `strcpy(users[0].password,"admin123");` | Hash SHA-256 au démarrage |
| VULN-28 | Global | Absence de `free()` (**MOYEN**) | Aucun `free(token)` | `cleanup_memory();` |
| VULN-29 | main | Buffer Overflow connexion (**ÉLEVÉ**) | `scanf("%s", username);` | `read_string(username,sizeof(username));` |
| VULN-30 | hash_password | Hash DJB2 faible (**FAIBLE**) | Algorithme maison | SHA-256 OpenSSL |

**Total des vulnérabilités identifiées : 30**

---

# 2. Corrections détaillées

## Correction n°1 — Buffer Overflows (`gets()` et `scanf("%s")`)

### Vulnérabilité

**Fonctions concernées**

- `register_user()`
- `show_profile()`
- `transfer_money()`
- `change_password()`
- `main()`
- `backup_user_data()`

**Description**

Utilisation des fonctions non sécurisées `gets()` et `scanf("%s")`, ne limitant pas la taille des données saisies.

### Code vulnérable

```c
scanf("%s", username);
gets(format);
```

### Attaque possible

Un attaquant saisit une chaîne dépassant la taille du buffer, provoquant un **Stack Overflow**.

**Impact**

- ✅ Exécution de code arbitraire
- ✅ Déni de service (Crash)

### Correction

```c
static void read_string(char *buf, size_t size)
{
    if (fgets(buf, (int)size, stdin) != NULL)
    {
        size_t len = strlen(buf);

        if (len > 0 && buf[len - 1] == '\n')
        {
            buf[len - 1] = '\0';
        }
        else
        {
            int c;

            while ((c = getchar()) != '\n' && c != EOF);
        }
    }
    else
    {
        buf[0] = '\0';
    }
}
```

### Modifications

- Implémentation de `read_string()`
- Utilisation de `fgets()`
- Nettoyage du buffer `stdin`
- Suppression complète de `gets()` et `scanf("%s")`

### Justification

La taille des copies est désormais bornée avec `sizeof()`.

### Test

```bash
# Entrée :
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

# Résultat :
Lecture limitée à la taille du buffer.
Aucun dépassement mémoire détecté.
```

---

## Correction n°2 — Format String (VULN-09)

### Code vulnérable

```c
printf(format);
```

### Correction

```c
printf("%s\n", format);
```

### Justification

La chaîne utilisateur n'est plus interprétée comme une chaîne de format.

### Test

```bash
Entrée :
%p %p %p

Résultat :
Affichage littéral de la chaîne.
```

---

## Correction n°3 — Injection de commande (VULN-18)

### Code vulnérable

```c
sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
system(full_cmd);
```

### Correction

```c
/* Fonction supprimée */
```

### Justification

Suppression complète du vecteur d'attaque.

### Test

```bash
Menu 7

Résultat :
Impossible d'exécuter une commande shell.
```

---

## Correction n°4 — Path Traversal (VULN-15 & VULN-16)

### Code vulnérable

```c
fp = fopen(filename, "w");
```

### Correction

```c
static int is_invalid_path(const char *filename)
{
    if (filename == NULL || strlen(filename) == 0 || strlen(filename) > 60)
        return 1;

    for (size_t i = 0; i < strlen(filename); i++)
    {
        if (!isalnum((unsigned char)filename[i]) &&
            filename[i] != '_' &&
            filename[i] != '-')
        {
            return 1;
        }
    }

    return 0;
}
```

### Justification

Les caractères `.` et `/` sont interdits.

### Test

```bash
Nom :
../test

Résultat :
Rejet immédiat.
```

---

## Correction n°5 — Cryptographie et Backdoor

### Vulnérabilité

- mots de passe stockés en clair ;
- présence d'une backdoor (`master_reset_2024`).

### Code vulnérable

```c
if(strcmp(old_pass,"master_reset_2024")==0)
```

### Correction

```c
#include <openssl/sha.h>

/* Utilisation de SHA256()
   Suppression de la backdoor */
```

### Modifications

- intégration d'OpenSSL ;
- hash SHA-256 ;
- suppression du mot de passe maître.

### Test

```bash
Les mots de passe apparaissent
comme une empreinte hexadécimale
de 64 caractères.
```

---

# 3. Tests de validation

## 3.1 Compilation

Commande :

```bash
gcc -Wall -Wextra -std=c11 secure.c -o secure -lcrypto
```

Résultat :

```text
Compilation de la version SÉCURISÉE...

✓ secure compilé avec succès

Warnings : 0
Erreurs : 0
Aucun warning affiché lors de la compilation avec -Wall -Wextra.
```

---

## 3.2 Tests fonctionnels

| Fonction | Test | Résultat |
|----------|------|----------|
| Création utilisateur | Nom très long | ✅ OK |
| Connexion | Mauvais identifiants | ✅ OK |
| Transfert | Montant négatif | ✅ OK |
| Backup | Nom avec `../` | ✅ OK |
| Commande système | `; ls` | ✅ OK |

---

## 3.3 Analyse mémoire (Valgrind)

Commande

```bash
valgrind --leak-check=full --show-leak-kinds=all ./secure
```

Résultat

```text
==3766== HEAP SUMMARY:
==3766==     in use at exit: 0 bytes in 0 blocks

==3766== All heap blocks were freed -- no leaks are possible

==3766== ERROR SUMMARY: 0 errors from 0 contexts
```

- **Fuites mémoire :** 0
- **Blocs non libérés :** 0

---

## 3.4 Tests de sécurité

### Test 1 — Buffer Overflow

```bash
Entrée :
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

Résultat attendu :
Rejet de l'excès de caractères ou limitation à la taille du buffer.

Résultat obtenu :
Lecture limitée à la taille du buffer.
Les caractères supplémentaires sont supprimés et aucun dépassement mémoire n'est observé.
```

---

### Test 2 — Format String

```bash
Entrée :
%x %x %x %p

Résultat attendu :
Affichage littéral de la chaîne saisie.

Résultat obtenu :
%x %x %x %p
```

---

### Test 3 — Command Injection

```bash
Entrée :
; cat /etc/passwd

Résultat attendu :
Refus

Résultat obtenu :
Fonction désactivée.
```

---

# 4. Conclusion

## 4.1 Résumé des corrections

### Statistiques

- Vulnérabilités **CRITIQUES corrigées** : 12 occurrences
- Vulnérabilités **ÉLEVÉES corrigées** : 12 occurrences
- Vulnérabilités **MOYENNES / FAIBLES corrigées** : 6 occurrences

**Total : 30 occurrences de vulnérabilités traitées**

### Principaux changements

- remplacement global des fonctions de saisie par `read_line()`;
- hashage SHA-256 via OpenSSL ;
- correction des transferts négatifs ;
- correction de la division par zéro.

---

## 4.2 Difficultés rencontrées

### Problème n°1

Vidage du buffer après `fgets()`.

**Solution**

Utilisation de :

```c
while ((c = getchar()) != '\n' && c != EOF);
```

### Problème n°2

Mémoire dynamique non libérée.

**Solution**

Implémentation de :

```c
cleanup_memory();
```

---

## 4.3 Améliorations possibles

### Sécurité

- ✅ Ajouter un salage (salt) des mots de passe
- ✅ Ajouter des logs de sécurité
- ✅ Limiter les tentatives de connexion
- ⬜ Implémenter un système de session avec expiration

---

## 4.4 Apprentissages

### Ce que j'ai appris

- exploitation des Buffer Overflows ;
- détection des Memory Leaks avec Valgrind ;
- sécurisation avancée en langage C.

### Compétences développées

- ✅ Identification des vulnérabilités
- ✅ Utilisation de fonctions sécurisées
- ✅ Validation des entrées
- ✅ Gestion mémoire
- ✅ Cryptographie

---

# Annexes

## Annexe A — Checklist finale

- [x] Tous les `gets()` remplacés
- [x] Tous les `scanf("%s")` sécurisés
- [x] Suppression des `strcpy()` dangereux sur les entrées utilisateur
- [x] SHA-256 utilisé
- [x] Aucun mot de passe en clair
- [x] Aucune backdoor
- [x] Validation des entrées utilisateur
- [x] Tous les `malloc()` possèdent un `free()`
- [x] 0 fuite mémoire (Valgrind)
- [x] 0 warning de compilation
- [x] Validation stricte des noms de fichiers
- [x] Protection contre les injections de commandes

---