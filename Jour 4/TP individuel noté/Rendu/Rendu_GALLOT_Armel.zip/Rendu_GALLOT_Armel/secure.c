/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Durée : 4 heures
 * 
 * CONSIGNE : Ce programme contient de NOMBREUSES vulnérabilités.
 * Vous devez les identifier, les corriger et documenter chaque correction.
 * 
 * Système de gestion de comptes utilisateurs avec authentification
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

typedef struct {
    char username[16];
    char password[16];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

static int read_input(char *buffer, size_t size) {
    int c;
    char *newline;

    if (fgets(buffer, (int)size, stdin) == NULL) {
        buffer[0] = '\0';
        return 0;
    }

    newline = strchr(buffer, '\n');
    if (newline != NULL) {
        *newline = '\0';
        return 1;
    }

    while ((c = getchar()) != '\n' && c != EOF) {
    }
    return 0;
}

static int read_int_input(int *value) {
    char line[64];
    if (!read_input(line, sizeof(line))) {
        return 0;
    }
    return sscanf(line, "%d", value) == 1;
}

static int is_safe_command(const char *cmd) {
    const unsigned char *p;

    if (cmd == NULL || *cmd == '\0') {
        return 0;
    }

    for (p = (const unsigned char *)cmd; *p != '\0'; ++p) {
        unsigned char ch = *p;
        if (isalnum(ch) || ch == ' ' || ch == '-' || ch == '_' || ch == '.' || ch == '/' || ch == '\\') {
            continue;
        }
        return 0;
    }

    return 1;
}

// Fonction de hashage personnalisée
unsigned int hash_password(char *pass) {
    unsigned int h = 5381;
    int c;
    while ((c = *pass++))
        h = h * 33 + c;
    return h;
}

// Enregistrement d'un nouvel utilisateur
void register_user(int logged_user) {
    if(user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }
    
    char username[100];
    char password[100];
    char confirm[100];
    int admin;
    
    printf("=== ENREGISTREMENT ===\n");
    printf("Username: ");
    if (!read_input(username, sizeof(username))) {
        printf("Nom d'utilisateur trop long ou invalide\n");
        return;
    }
    if (strlen(username) < 3 || strlen(username) > 15) {
        printf("Nom d'utilisateur invalide\n");
        return;
    }
    
    printf("Password: ");
    if (!read_input(password, sizeof(password))) {
        printf("Mot de passe trop long\n");
        return;
    }
    
    printf("Confirmer password: ");
    if (!read_input(confirm, sizeof(confirm))) {
        printf("Confirmation trop longue\n");
        return;
    }
    
    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        return;
    }
    
    if(logged_user >= 0 && users[logged_user].admin_flag) {
        printf("Droits admin (1=oui, 0=non): ");
        if (!read_int_input(&admin) || (admin != 0 && admin != 1)) {
            printf("Valeur d'admin invalide\n");
            return;
        }
    } else {
        admin = 0;
    }
    
    strncpy(users[user_count].username, username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    strncpy(users[user_count].password, password, sizeof(users[user_count].password) - 1);
    users[user_count].password[sizeof(users[user_count].password) - 1] = '\0';
    users[user_count].admin_flag = admin;
    users[user_count].balance = 100;
    
    users[user_count].token = malloc(64);
    if (users[user_count].token != NULL) {
        snprintf(users[user_count].token, 64, "TOK_%d_%s", user_count, username);
    }
    
    user_count++;
    printf("Utilisateur enregistré!\n");
}

// Connexion utilisateur
int login_user(char *username, char *password) {
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, username) == 0 && 
           strcmp(users[i].password, password) == 0) {
            return i;
        }
    }
    return -1;
}

// Afficher profil utilisateur
void show_profile(int user_id) {
    char format[80];
    
    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    
    printf("Format d'affichage personnalisé: ");
    read_input(format, sizeof(format));
    printf("%s\n", format);
}

// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    read_input(to_username, sizeof(to_username));
    
    printf("Montant: ");
    if (!read_int_input(&amount) || amount <= 0) {
        printf("Montant invalide\n");
        return;
    }
    
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données
void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;
    
    printf("Nom du fichier de backup: ");
    read_input(filename, sizeof(filename));
    
    fp = fopen(filename, "w");
    if(fp) {
        fprintf(fp, "%s:%s:%d:%d\n", 
                users[user_id].username,
                users[user_id].password,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup créé\n");
    }
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    read_input(filename, sizeof(filename));
    
    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    char full_cmd[200];
    
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    read_input(cmd, sizeof(cmd));

    if (!is_safe_command(cmd)) {
        printf("Commande invalide : caractères non autorisés\n");
        return;
    }
    
    snprintf(full_cmd, sizeof(full_cmd), "echo 'Exécution:' && %s", cmd);
    system(full_cmd);
}


// Copie de données utilisateur
void clone_user(int source_id) {
    char target_username[30];
    
    printf("Nom du clone: ");
    read_input(target_username, sizeof(target_username));
    
    if(user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    
    strncpy(users[user_count].username, target_username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';
    strncpy(users[user_count].password, users[source_id].password, sizeof(users[user_count].password) - 1);
    users[user_count].password[sizeof(users[user_count].password) - 1] = '\0';
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;
    
    user_count++;
    printf("Clone créé\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe
void change_password(int user_id) {
    char old_pass[80];
    char new_pass[80];
    
    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    read_input(old_pass, sizeof(old_pass));
    
    if(strcmp(users[user_id].password, old_pass) == 0 || 
       strcmp(old_pass, "master_reset_2024") == 0) {
        printf("Nouveau mot de passe: ");
        read_input(new_pass, sizeof(new_pass));
        strncpy(users[user_id].password, new_pass, sizeof(users[user_id].password) - 1);
        users[user_id].password[sizeof(users[user_id].password) - 1] = '\0';
        printf("Mot de passe changé\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];
    
    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    snprintf(buffer, sizeof(buffer), "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];
    
    printf("Rechercher: ");
    read_input(query, sizeof(query));
    
    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for(int i = 0; i < session_count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[50], password[50];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
    // Compte admin par défaut
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    users[0].username[sizeof(users[0].username) - 1] = '\0';
    strncpy(users[0].password, "admin123", sizeof(users[0].password) - 1);
    users[0].password[sizeof(users[0].password) - 1] = '\0';
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(64);
    if (users[0].token != NULL) {
        snprintf(users[0].token, 64, "ADMIN_TOKEN");
    }
    user_count = 1;
    
    int running = 1;
    while(running) {
        char choice_input[64];
        display_menu();
        if (!read_input(choice_input, sizeof(choice_input))) {
            printf("\nFin de saisie\n");
            break;
        }

        if (choice_input[0] == '\0') {
            printf("Choix invalide\n");
            continue;
        }

        if (sscanf(choice_input, "%d", &choice) != 1 || choice < 0 || choice > 12) {
            printf("Choix invalide\n");
            continue;
        }
        
        switch(choice) {
            case 1:
                register_user(logged_user);
                break;
            case -1:
                printf("Choix invalide\n");
                break;
            case 2:
                printf("Username: ");
                read_input(username, sizeof(username));
                printf("Password: ");
                read_input(password, sizeof(password));
                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                running = 0;
                break;
            default:
                printf("Choix invalide\n");
        }
    }
    
    return 0;
}
