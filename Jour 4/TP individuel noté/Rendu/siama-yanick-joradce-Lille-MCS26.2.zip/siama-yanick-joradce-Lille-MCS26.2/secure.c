/*
 * TP FINAL NOTE - Version securisee
 *
 * Corrections appliquees par rapport a vulnerable.c :
 *  - Remplacement de toutes les fonctions dangereuses (gets/scanf("%s")/strcpy/
 *    strcat/sprintf) par des equivalents bornes (fgets/strncpy/strncat/snprintf)
 *  - Validation systematique des entrees utilisateur (username, montant,
 *    nom de fichier, indices de tableau)
 *  - Hachage des mots de passe en SHA-256 avec sel, plus jamais stockes en clair
 *  - Suppression de la backdoor "master_reset_2024"
 *  - Suppression de la faille "auto-admin" a l'inscription
 *  - system() supprime (remplace par une commande fixe, sans injection possible)
 *  - Path traversal bloque sur les noms de fichiers (backup/restore)
 *  - Gestion memoire : verification des malloc() + free() dans cleanup()
 *  - Ajout d'une limitation de tentatives de connexion (bonus)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10
#define USERNAME_MAXLEN 15   /* place pour le '\0' dans username[16] */
#define MAX_LOGIN_ATTEMPTS 5

typedef struct {
    char username[16];
    char password_hash[SHA256_DIGEST_LENGTH * 2 + 1]; /* hex string + '\0' */
    char salt[17];                                     /* 16 hex chars + '\0' */
    int admin_flag;
    int balance;
    char *token;
    int failed_attempts;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

/* ------------------------------------------------------------------ */
/* Utilitaires de validation                                          */
/* ------------------------------------------------------------------ */

/* Lit une ligne au clavier de facon sure et enleve le retour a la ligne. */
static void read_line(char *buf, size_t size) {
    if (fgets(buf, (int)size, stdin) != NULL) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
        } else {
            /* Ligne trop longue pour le buffer : on vide le reste du flux stdin */
            int c;
            while ((c = getchar()) != '\n' && c != EOF) { }
        }
    } else {
        buf[0] = '\0';
    }
}

/* Lit un entier de facon sure (evite scanf("%d") non verifie). */
static int read_int(int *out) {
    char buf[32];
    read_line(buf, sizeof(buf));
    char *endptr;
    long val = strtol(buf, &endptr, 10);
    if (endptr == buf || *endptr != '\0') {
        return 0; /* echec de conversion */
    }
    *out = (int)val;
    return 1;
}

/* Username : longueur raisonnable + uniquement alphanumerique/underscore. */
static int is_valid_username(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len > USERNAME_MAXLEN) return 0;
    for (size_t i = 0; i < len; i++) {
        if (!isalnum((unsigned char)s[i]) && s[i] != '_') return 0;
    }
    return 1;
}

/* Mot de passe : longueur minimale, pas de controle de charset strict
 * (on autorise les caracteres speciaux pour la robustesse du mot de passe). */
static int is_valid_password(const char *s) {
    size_t len = strlen(s);
    return (len >= 4 && len < 64);
}

/* Empeche tout chemin absolu ou toute tentative de path traversal :
 * pas de '/', pas de '\', pas de "..". */
static int is_valid_filename(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len > 100) return 0;
    if (strstr(s, "..") != NULL) return 0;
    if (strchr(s, '/') != NULL) return 0;
    if (strchr(s, '\\') != NULL) return 0;
    if (s[0] == '~') return 0;
    return 1;
}

static int is_valid_user_id(int id) {
    return (id >= 0 && id < user_count);
}

/* ------------------------------------------------------------------ */
/* Cryptographie : SHA-256 sale                                        */
/* ------------------------------------------------------------------ */

/* Genere un sel aleatoire de 8 octets, encode en hexa (16 caracteres). */
static void generate_salt(char *salt_hex, size_t salt_hex_size) {
    unsigned char raw[8];
    for (size_t i = 0; i < sizeof(raw); i++) {
        raw[i] = (unsigned char)(rand() % 256);
    }
    for (size_t i = 0; i < sizeof(raw); i++) {
        snprintf(salt_hex + i * 2, 3, "%02x", raw[i]);
    }
    salt_hex[salt_hex_size - 1] = '\0';
}

/* Hash = SHA256(salt || password), retourne une chaine hexadecimale. */
static void hash_password(const char *password, const char *salt_hex,
                           char *out_hex, size_t out_hex_size) {
    unsigned char digest[SHA256_DIGEST_LENGTH];
    char salted[128];

    snprintf(salted, sizeof(salted), "%s%s", salt_hex, password);
    SHA256((unsigned char *)salted, strlen(salted), digest);

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        snprintf(out_hex + i * 2, 3, "%02x", digest[i]);
    }
    out_hex[out_hex_size - 1] = '\0';
}

/* Comparaison "timing-safe" pour eviter les attaques par mesure de temps
 * lors de la comparaison des hachages (bonus). */
static int constant_time_equals(const char *a, const char *b, size_t len) {
    unsigned char diff = 0;
    for (size_t i = 0; i < len; i++) {
        diff |= (unsigned char)(a[i] ^ b[i]);
    }
    return diff == 0;
}

/* ------------------------------------------------------------------ */
/* Fonctionnalites du programme                                        */
/* ------------------------------------------------------------------ */

void register_user(void) {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[64];
    char password[64];
    char confirm[64];

    printf("=== ENREGISTREMENT ===\n");

    printf("Username: ");
    read_line(username, sizeof(username));
    if (!is_valid_username(username)) {
        printf("Username invalide (alphanumerique/underscore, 1-%d caracteres)\n",
               USERNAME_MAXLEN);
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            printf("Ce nom d'utilisateur existe deja\n");
            return;
        }
    }

    printf("Password: ");
    read_line(password, sizeof(password));
    if (!is_valid_password(password)) {
        printf("Mot de passe trop court (4 caracteres minimum)\n");
        return;
    }

    printf("Confirmer password: ");
    read_line(confirm, sizeof(confirm));
    if (strcmp(password, confirm) != 0) {
        printf("Les mots de passe ne correspondent pas\n");
        return;
    }

    /* Correction majeure : les droits admin ne sont JAMAIS accordes a
     * l'inscription. Seul un administrateur existant pourrait en
     * promouvoir un autre via une fonctionnalite dediee (non demandee ici). */
    users[user_count].admin_flag = 0;

    strncpy(users[user_count].username, username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';

    generate_salt(users[user_count].salt, sizeof(users[user_count].salt));
    hash_password(password, users[user_count].salt,
                   users[user_count].password_hash,
                   sizeof(users[user_count].password_hash));

    users[user_count].balance = 100;
    users[user_count].failed_attempts = 0;

    users[user_count].token = malloc(64);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation memoire\n");
        return;
    }
    snprintf(users[user_count].token, 64, "TOK_%d_%.15s", user_count, username);

    user_count++;
    printf("Utilisateur enregistre!\n");
}

int login_user(const char *username, const char *password) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            /* Limitation du nombre de tentatives (bonus). */
            if (users[i].failed_attempts >= MAX_LOGIN_ATTEMPTS) {
                printf("Compte verrouille (trop de tentatives echouees)\n");
                return -1;
            }

            char computed[SHA256_DIGEST_LENGTH * 2 + 1];
            hash_password(password, users[i].salt, computed, sizeof(computed));

            if (constant_time_equals(computed, users[i].password_hash, strlen(users[i].password_hash))) {
                users[i].failed_attempts = 0;
                return i;
            } else {
                users[i].failed_attempts++;
                return -1;
            }
        }
    }
    return -1;
}

void show_profile(int user_id) {
    if (!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }

    char format[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d EUR\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Format d'affichage personnalise: ");
    read_line(format, sizeof(format));
    /* Plus jamais de printf(format) : le format est fige, la donnee
     * utilisateur est passee comme argument, jamais comme chaine de format. */
    printf("%s\n", format);
}

void transfer_money(int from_user) {
    if (!is_valid_user_id(from_user)) {
        printf("Utilisateur invalide\n");
        return;
    }

    char to_username[64];
    int amount;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    read_line(to_username, sizeof(to_username));
    if (!is_valid_username(to_username)) {
        printf("Nom d'utilisateur invalide\n");
        return;
    }

    printf("Montant: ");
    if (!read_int(&amount)) {
        printf("Montant invalide\n");
        return;
    }
    if (amount <= 0) {
        printf("Le montant doit etre strictement positif\n");
        return;
    }
    if (amount > users[from_user].balance) {
        printf("Fonds insuffisants\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            if (i == from_user) {
                printf("Impossible de transferer vers son propre compte\n");
                return;
            }
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectue!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

/* Sauvegarde : le mot de passe (hash + sel) reste dans le fichier
 * uniquement parce que la restauration en a besoin, mais il n'est
 * jamais stocke/affiche en clair. Nom de fichier strictement valide. */
void backup_user_data(int user_id) {
    if (!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }

    char filename[100];
    FILE *fp;

    printf("Nom du fichier de backup (nom simple, sans / ni ..): ");
    read_line(filename, sizeof(filename));
    if (!is_valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    fp = fopen(filename, "w");
    if (fp) {
        fprintf(fp, "%s:%s:%s:%d:%d\n",
                users[user_id].username,
                users[user_id].salt,
                users[user_id].password_hash,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup cree\n");
    } else {
        printf("Impossible de creer le fichier\n");
    }
}

void restore_user_data(void) {
    char filename[100];
    char buffer[256];
    FILE *fp;

    printf("Fichier a restaurer (nom simple, sans / ni ..): ");
    read_line(filename, sizeof(filename));
    if (!is_valid_filename(filename)) {
        printf("Nom de fichier invalide\n");
        return;
    }

    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        return;
    }

    /* On affiche uniquement le contenu (deja "prudent" dans l'original) ;
     * on garde la meme fonctionnalite mais avec un nom de fichier valide. */
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

/* system_command() a ete entierement retiree : elle permettait une
 * injection de commande shell directe (concatenation d'une entree
 * utilisateur dans une commande passee a system()). Il n'existe pas
 * de facon sure de garder cette fonctionnalite "commande libre" telle
 * quelle ; on la remplace par une action fixe et sans argument utilisateur. */
void system_command(void) {
    printf("=== COMMANDE SYSTEME ===\n");
    printf("Fonctionnalite desactivee : execution de commande shell arbitraire\n");
    printf("interdite pour des raisons de securite (injection de commande).\n");
}

void clone_user(int source_id) {
    if (!is_valid_user_id(source_id)) {
        printf("Utilisateur source invalide\n");
        return;
    }
    /* Seul un admin peut cloner un utilisateur (correction de logique
     * metier : l'original permettait a n'importe quel utilisateur connecte
     * de copier les droits/solde d'un autre). */
    if (!users[source_id].admin_flag) {
        printf("Acces refuse : reserve aux administrateurs\n");
        return;
    }

    char target_username[64];
    printf("Nom du clone: ");
    read_line(target_username, sizeof(target_username));
    if (!is_valid_username(target_username)) {
        printf("Nom d'utilisateur invalide\n");
        return;
    }

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, target_username) == 0) {
            printf("Ce nom d'utilisateur existe deja\n");
            return;
        }
    }

    strncpy(users[user_count].username, target_username, sizeof(users[user_count].username) - 1);
    users[user_count].username[sizeof(users[user_count].username) - 1] = '\0';

    strncpy(users[user_count].salt, users[source_id].salt, sizeof(users[user_count].salt) - 1);
    users[user_count].salt[sizeof(users[user_count].salt) - 1] = '\0';
    strncpy(users[user_count].password_hash, users[source_id].password_hash,
            sizeof(users[user_count].password_hash) - 1);
    users[user_count].password_hash[sizeof(users[user_count].password_hash) - 1] = '\0';

    users[user_count].admin_flag = 0; /* le clone n'herite jamais des droits admin */
    users[user_count].balance = users[source_id].balance;
    users[user_count].failed_attempts = 0;

    users[user_count].token = malloc(64);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation memoire\n");
        return;
    }
    snprintf(users[user_count].token, 64, "TOK_%d_%.15s", user_count, target_username);

    user_count++;
    printf("Clone cree\n");
}

void list_users(void) {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d EUR, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

void change_password(int user_id) {
    if (!is_valid_user_id(user_id)) {
        printf("Utilisateur invalide\n");
        return;
    }

    char old_pass[64];
    char new_pass[64];

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    read_line(old_pass, sizeof(old_pass));

    /* Backdoor "master_reset_2024" supprimee : seul le vrai mot de passe
     * (verifie via le hash) est accepte. */
    char computed[SHA256_DIGEST_LENGTH * 2 + 1];
    hash_password(old_pass, users[user_id].salt, computed, sizeof(computed));

    if (constant_time_equals(computed, users[user_id].password_hash, strlen(users[user_id].password_hash))) {
        printf("Nouveau mot de passe: ");
        read_line(new_pass, sizeof(new_pass));
        if (!is_valid_password(new_pass)) {
            printf("Mot de passe trop court (4 caracteres minimum)\n");
            return;
        }
        generate_salt(users[user_id].salt, sizeof(users[user_id].salt));
        hash_password(new_pass, users[user_id].salt,
                      users[user_id].password_hash,
                      sizeof(users[user_id].password_hash));
        printf("Mot de passe change\n");
    } else {
        printf("Ancien mot de passe incorrect\n");
    }
}

void compute_stats(void) {
    if (user_count == 0) {
        printf("Aucun utilisateur enregistre\n");
        return;
    }

    int total = 0;
    double avg;
    char buffer[120];

    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }

    avg = (double)total / user_count;

    snprintf(buffer, sizeof(buffer), "Total: %d EUR, Moyenne: %.2f EUR", total, avg);
    printf("%s\n", buffer);
}

void search_user(void) {
    char query[64];

    printf("Rechercher: ");
    read_line(query, sizeof(query));

    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouve: %s\n", users[i].username);
        }
    }
}

void cleanup_sessions(void) {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600) {
            printf("Session %d expiree\n", i);
        }
    }
}

/* Liberation de toute la memoire allouee dynamiquement (tokens). */
void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        free(users[i].token);
        users[i].token = NULL;
    }
}

void display_menu(void) {
    printf("\n===================================\n");
    printf("   SYSTEME DE GESTION BANCAIRE\n");
    printf("===================================\n");
    printf(" 1. Creer compte\n");
    printf(" 2. Se connecter\n");
    printf(" 3. Voir profil\n");
    printf(" 4. Transferer argent\n");
    printf(" 5. Backup donnees\n");
    printf(" 6. Restaurer donnees\n");
    printf(" 7. Commande systeme\n");
    printf(" 8. Cloner utilisateur\n");
    printf(" 9. Liste utilisateurs\n");
    printf(" 10. Changer mot de passe\n");
    printf(" 11. Statistiques\n");
    printf(" 12. Rechercher utilisateur\n");
    printf(" 0. Quitter\n");
    printf("===================================\n");
    printf("Choix: ");
}

int main(void) {
    int choice;
    int logged_user = -1;
    char username[64], password[64];

    srand((unsigned int)time(NULL));

    printf("===================================================\n");
    printf("  TP FINAL NOTE - VERSION SECURISEE\n");
    printf("===================================================\n\n");

    /* Compte admin par defaut : mot de passe fort genere/hashe,
     * plus jamais stocke en clair. En production, on eviterait
     * un mot de passe fixe et on forcerait un changement au premier
     * lancement ; ici on hash au moins la valeur par defaut. */
    strncpy(users[0].username, "admin", sizeof(users[0].username) - 1);
    users[0].username[sizeof(users[0].username) - 1] = '\0';
    generate_salt(users[0].salt, sizeof(users[0].salt));
    hash_password("ChangeMe_Admin!2024", users[0].salt,
                   users[0].password_hash, sizeof(users[0].password_hash));
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].failed_attempts = 0;
    users[0].token = malloc(32);
    if (users[0].token == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire au demarrage\n");
        return EXIT_FAILURE;
    }
    strncpy(users[0].token, "ADMIN_TOKEN", 32 - 1);
    users[0].token[31] = '\0';
    user_count = 1;

    while (1) {
        display_menu();
        if (!read_int(&choice)) {
            printf("Choix invalide\n");
            continue;
        }

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                read_line(username, sizeof(username));
                printf("Password: ");
                read_line(password, sizeof(password));
                logged_user = login_user(username, password);
                if (logged_user >= 0) {
                    printf("Connecte en tant que %s\n", users[logged_user].username);
                } else {
                    printf("Echec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if (logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if (logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                if (logged_user >= 0 && users[logged_user].admin_flag) {
                    restore_user_data();
                } else {
                    printf("Acces refuse (reserve aux administrateurs)\n");
                }
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Acces refuse\n");
                }
                break;
            case 8:
                if (logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if (logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                cleanup();
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    cleanup();
    return 0;
}
