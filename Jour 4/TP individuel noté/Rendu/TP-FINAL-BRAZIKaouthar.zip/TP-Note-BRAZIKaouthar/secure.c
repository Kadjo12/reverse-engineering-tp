/*
 * TP FINAL NOTÉ - Sécurisation de code vulnérable
 * Durée : 4 heures
 * 
 * CONSIGNE : Ce programme contient de NOMBREUSES vulnérabilités.
 * Vous devez les identifier, les corriger et documenter chaque correction.
 * 
 * Système de gestion de comptes utilisateurs avec authentification
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//Correction
#include <ctype.h>
#include <limits.h>
#include <openssl/sha.h>
#include <errno.h>
#include <sys/stat.h>


#define MAX_USERS 20
#define MAX_SESSIONS 10

//Correction
#define USERNAME_SIZE 16
#define PASSWORD_SIZE 128
#define PASSWORD_HASH_SIZE 65
#define TOKEN_SIZE 64
#define INPUT_SIZE 256

typedef struct {
    char username[USERNAME_SIZE];
    char password_hash[PASSWORD_HASH_SIZE];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

// Remplacement du maus hash par SHA-256
static int hash_password(const char *password,
                         char output[PASSWORD_HASH_SIZE])
{
    unsigned char digest[SHA256_DIGEST_LENGTH];

    if (password == NULL || output == NULL) {
        return 0;
    }

    if (SHA256((const unsigned char *)password,
               strlen(password),
               digest) == NULL) {
        return 0;
    }

    for (size_t index = 0; index < SHA256_DIGEST_LENGTH; index++) {
        snprintf(output + (index * 2),
                 PASSWORD_HASH_SIZE - (index * 2),
                 "%02x",
                 digest[index]);
    }

    output[PASSWORD_HASH_SIZE - 1] = '\0';
    return 1;
}

//Ajout d'une politique minimale de mot de passe
static int is_valid_password(const char *password)
{
    int has_uppercase = 0;
    int has_lowercase = 0;
    int has_digit = 0;
    size_t length;

    if (password == NULL) {
        return 0;
    }

    length = strlen(password);

    if (length < 8 || length >= PASSWORD_SIZE) {
        return 0;
    }

    for (size_t index = 0; index < length; index++) {
        unsigned char character = (unsigned char)password[index];

        if (isupper(character)) {
            has_uppercase = 1;
        } else if (islower(character)) {
            has_lowercase = 1;
        } else if (isdigit(character)) {
            has_digit = 1;
        }
    }

    return has_uppercase && has_lowercase && has_digit;
}



//Ajout des fonctions de saisie sécurisée
//Cette fonction remplacera tous les gets() et scanf("%s")
static int read_line(char *buffer, size_t size)
{
    if (buffer == NULL || size == 0) {
        return 0;
    }

    if (fgets(buffer, size, stdin) == NULL) {
        return 0;
    }

    size_t length = strlen(buffer);

    if (length > 0 && buffer[length - 1] == '\n') {
        buffer[length - 1] = '\0';
    } else {
        int character;

        /* Purger le reste d'une entrée trop longue. */
        while ((character = getchar()) != '\n' && character != EOF) {
        }
    }

    return 1;
}

//lire un entier correctement
/*static int read_integer(const char *prompt, int *value)
{
    char input[INPUT_SIZE];
    char *end_pointer;
    long parsed_value;

    if (prompt != NULL) {
        printf("%s", prompt);
    }

    if (!read_line(input, sizeof(input))) {
        return 0;
    }

    end_pointer = NULL;
    parsed_value = strtol(input, &end_pointer, 10);

    if (end_pointer == input || *end_pointer != '\0') {
        return 0;
    }

    if (parsed_value < INT_MIN || parsed_value > INT_MAX) {
        return 0;
    }

    *value = (int)parsed_value;
    return 1;
}*/

//Valider les noms d’utilisateur
static int is_valid_username(const char *username)
{
    size_t length;

    if (username == NULL) {
        return 0;
    }

    length = strlen(username);

    if (length < 3 || length >= USERNAME_SIZE) {
        return 0;
    }

    for (size_t index = 0; index < length; index++) {
        unsigned char character = (unsigned char)username[index];

        if (!isalnum(character) &&
            character != '_' &&
            character != '-') {
            return 0;
        }
    }

    return 1;
}

//vérifier qu’un nom n’existe pas déjà
static int find_user_by_name(const char *username)
{
    for (int index = 0; index < user_count; index++) {
        if (strcmp(users[index].username, username) == 0) {
            return index;
        }
    }

    return -1;
}

// Correction complete de la fonction
void register_user(void)
{
    char username[USERNAME_SIZE];
    char password[PASSWORD_SIZE];
    char confirmation[PASSWORD_SIZE];
    char password_hash[PASSWORD_HASH_SIZE];
    char token_buffer[TOKEN_SIZE];
    int token_length;

    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint.\n");
        return;
    }

    printf("=== ENREGISTREMENT ===\n");

    printf("Username : ");
    if (!read_line(username, sizeof(username))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (!is_valid_username(username)) {
        printf("Nom invalide : 3 à 15 caractères "
               "alphanumériques, '-' ou '_'.\n");
        return;
    }

    if (find_user_by_name(username) >= 0) {
        printf("Ce nom d'utilisateur existe déjà.\n");
        return;
    }

    printf("Password : ");
    if (!read_line(password, sizeof(password))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (!is_valid_password(password)) {
        printf("Le mot de passe doit contenir au moins "
               "8 caractères, une majuscule, une minuscule "
               "et un chiffre.\n");
        return;
    }

    printf("Confirmer password : ");
    if (!read_line(confirmation, sizeof(confirmation))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (strcmp(password, confirmation) != 0) {
        printf("Les mots de passe ne correspondent pas.\n");
        return;
    }

    if (!hash_password(password, password_hash)) {
        printf("Erreur lors du hachage du mot de passe.\n");
        return;
    }

    /*
     * Un nouvel utilisateur ne doit jamais pouvoir
     * s'attribuer lui-même les privilèges administrateur.
     */
    users[user_count].admin_flag = 0;
    users[user_count].balance = 100;

    snprintf(users[user_count].username,
             sizeof(users[user_count].username),
             "%s",
             username);

    snprintf(users[user_count].password_hash,
             sizeof(users[user_count].password_hash),
             "%s",
             password_hash);

    token_length = snprintf(token_buffer,
                            sizeof(token_buffer),
                            "TOK_%d_%s_%ld",
                            user_count,
                            username,
                            (long)time(NULL));

    if (token_length < 0 ||
        (size_t)token_length >= sizeof(token_buffer)) {
        printf("Impossible de générer le token.\n");
        return;
    }

    users[user_count].token = malloc(strlen(token_buffer) + 1);

    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation mémoire.\n");
        return;
    }

    memcpy(users[user_count].token,
           token_buffer,
           strlen(token_buffer) + 1);

    user_count++;

    /* Réduire le temps de présence des secrets en mémoire. */
    memset(password, 0, sizeof(password));
    memset(confirmation, 0, sizeof(confirmation));
    memset(password_hash, 0, sizeof(password_hash));

    printf("Utilisateur enregistré.\n");
}

// Connexion utilisateur
int login_user(const char *username, const char *password)
{
    char supplied_hash[PASSWORD_HASH_SIZE];

    if (username == NULL || password == NULL) {
        return -1;
    }

    if (!hash_password(password, supplied_hash)) {
        return -1;
    }

    for (int index = 0; index < user_count; index++) {
        if (strcmp(users[index].username, username) == 0 &&
            strcmp(users[index].password_hash, supplied_hash) == 0) {
            memset(supplied_hash, 0, sizeof(supplied_hash));
            return index;
        }
    }

    memset(supplied_hash, 0, sizeof(supplied_hash));
    return -1;
}

// Correction de gets(format) , printf(format) et user_id
void show_profile(int user_id)
{
    char message[INPUT_SIZE];

    if (user_id < 0 || user_id >= user_count) {
        printf("Identifiant utilisateur invalide.\n");
        return;
    }

    printf("\n=== PROFIL ===\n");
    printf("Username : %s\n", users[user_id].username);
    printf("Balance  : %d\n", users[user_id].balance);
    printf("Admin    : %s\n",
           users[user_id].admin_flag ? "Oui" : "Non");

    printf("Message à afficher : ");

    if (!read_line(message, sizeof(message))) {
        printf("Erreur de lecture.\n");
        return;
    }

    /*
     * Le contenu saisi est une donnée et non une chaîne
     * de format contrôlée par l'utilisateur.
     */
    printf("%s\n", message);
}


// Transfert d'argent entre utilisateurs
void transfer_money(int from_user) {
    char to_username[50];
    int amount;
    
    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    scanf("%s", to_username);
    
    printf("Montant: ");
    scanf("%d", &amount);
    
    for(int i = 0; i < user_count; i++) {
        if(strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectué!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

// Sauvegarde des données : Correctionle mot de passe et son hash ne doit pas etre exporte
void backup_user_data(int user_id)
{
    char filename[INPUT_SIZE];
    char backup_path[INPUT_SIZE];
    FILE *file;
    int written;

    if (user_id < 0 || user_id >= user_count) {
        printf("Identifiant utilisateur invalide.\n");
        return;
    }

    printf("Nom du fichier de sauvegarde "
           "(lettres, chiffres, '-' et '_') : ");

    if (!read_line(filename, sizeof(filename))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (!is_valid_username(filename)) {
        printf("Nom de fichier invalide.\n");
        return;
    }

    written = snprintf(backup_path,
                       sizeof(backup_path),
                       "backups/%s.backup",
                       filename);

    if (written < 0 ||
        (size_t)written >= sizeof(backup_path)) {
        printf("Chemin de sauvegarde trop long.\n");
        return;
    }

    /*
     * Créer le répertoire local contrôlé par l'application.
     * Aucun chemin arbitraire fourni par l'utilisateur.
     */
    if (mkdir("backups", 0700) == -1 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    /*
     * Mode x : échec si le fichier existe déjà.
     * Cela évite l'écrasement involontaire.
     */
    file = fopen(backup_path, "wx");

    if (file == NULL) {
        perror("Impossible de créer la sauvegarde");
        return;
    }

    if (fprintf(file,
                "username=%s\n"
                "balance=%d\n"
                "admin=%d\n",
                users[user_id].username,
                users[user_id].balance,
                users[user_id].admin_flag) < 0) {
        printf("Erreur d'écriture de la sauvegarde.\n");
        fclose(file);
        remove(backup_path);
        return;
    }

    if (fclose(file) != 0) {
        perror("Erreur de fermeture");
        return;
    }

    printf("Sauvegarde créée : %s\n", backup_path);
}

// Restauration des données
void restore_user_data() {
    char filename[200];
    char buffer[256];
    FILE *fp;
    
    printf("Fichier à restaurer: ");
    scanf("%s", filename);
    
    fp = fopen(filename, "r");
    if(!fp) {
        printf("Fichier introuvable\n");
        return;
    }
    
    while(fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

// Exécution de commandes système
void system_command() {
    char cmd[150];
    char full_cmd[200];
    
    printf("=== COMMANDE SYSTÈME ===\n");
    printf("Commande: ");
    if (!read_line(cmd, sizeof(cmd))) {
    	printf("Erreur de lecture.\n");
    	return;
    }
    
    sprintf(full_cmd, "echo 'Exécution:' && %s", cmd);
    system(full_cmd);
}

// Copie de données utilisateur: Correction; le clone ne doit recuperer ni le mot de passe ni les droits admin
void clone_user(int source_id)
{
    char target_username[USERNAME_SIZE];
    char new_password[PASSWORD_SIZE];
    char confirmation[PASSWORD_SIZE];
    char new_hash[PASSWORD_HASH_SIZE];
    char token_buffer[TOKEN_SIZE];
    int token_length;

    if (source_id < 0 || source_id >= user_count) {
        printf("Utilisateur source invalide.\n");
        return;
    }

    if (user_count >= MAX_USERS) {
        printf("Nombre maximal d'utilisateurs atteint.\n");
        return;
    }

    printf("Nouveau nom d'utilisateur : ");

    if (!read_line(target_username, sizeof(target_username))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (!is_valid_username(target_username)) {
        printf("Nom d'utilisateur invalide.\n");
        return;
    }

    if (find_user_by_name(target_username) >= 0) {
        printf("Ce nom d'utilisateur existe déjà.\n");
        return;
    }

    printf("Nouveau mot de passe : ");

    if (!read_line(new_password, sizeof(new_password)) ||
        !is_valid_password(new_password)) {
        printf("Mot de passe insuffisamment robuste.\n");
        return;
    }

    printf("Confirmer le mot de passe : ");

    if (!read_line(confirmation, sizeof(confirmation)) ||
        strcmp(new_password, confirmation) != 0) {
        printf("Les mots de passe ne correspondent pas.\n");
        memset(new_password, 0, sizeof(new_password));
        return;
    }

    if (!hash_password(new_password, new_hash)) {
        printf("Erreur lors du hachage.\n");
        return;
    }

    snprintf(users[user_count].username,
             sizeof(users[user_count].username),
             "%s",
             target_username);

    snprintf(users[user_count].password_hash,
             sizeof(users[user_count].password_hash),
             "%s",
             new_hash);

    /*
     * Aucune copie de privilège ou de valeur financière.
     */
    users[user_count].admin_flag = 0;
    users[user_count].balance = 100;

    token_length = snprintf(token_buffer,
                            sizeof(token_buffer),
                            "TOK_%d_%s_%ld",
                            user_count,
                            target_username,
                            (long)time(NULL));

    if (token_length < 0 ||
        (size_t)token_length >= sizeof(token_buffer)) {
        printf("Erreur de génération du token.\n");
        return;
    }

    users[user_count].token = malloc(strlen(token_buffer) + 1);

    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation mémoire.\n");
        return;
    }

    memcpy(users[user_count].token,
           token_buffer,
           strlen(token_buffer) + 1);

    user_count++;

    memset(new_password, 0, sizeof(new_password));
    memset(confirmation, 0, sizeof(confirmation));
    memset(new_hash, 0, sizeof(new_hash));

    printf("Nouveau compte créé sans copier les privilèges "
           "du compte source.\n");
}

// Afficher tous les utilisateurs
void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for(int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d€, Admin: %d)\n", 
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

// Modifier mot de passe; suppression du backdoor
void change_password(int user_id)
{
    char old_password[PASSWORD_SIZE];
    char new_password[PASSWORD_SIZE];
    char confirmation[PASSWORD_SIZE];
    char old_hash[PASSWORD_HASH_SIZE];
    char new_hash[PASSWORD_HASH_SIZE];

    if (user_id < 0 || user_id >= user_count) {
        printf("Identifiant utilisateur invalide.\n");
        return;
    }

    printf("Ancien mot de passe : ");

    if (!read_line(old_password, sizeof(old_password))) {
        printf("Erreur de lecture.\n");
        return;
    }

    if (!hash_password(old_password, old_hash) ||
        strcmp(users[user_id].password_hash, old_hash) != 0) {
        printf("Ancien mot de passe incorrect.\n");
        memset(old_password, 0, sizeof(old_password));
        memset(old_hash, 0, sizeof(old_hash));
        return;
    }

    printf("Nouveau mot de passe : ");

    if (!read_line(new_password, sizeof(new_password)) ||
        !is_valid_password(new_password)) {
        printf("Le nouveau mot de passe est insuffisamment robuste.\n");
        return;
    }

    printf("Confirmer le nouveau mot de passe : ");

    if (!read_line(confirmation, sizeof(confirmation)) ||
        strcmp(new_password, confirmation) != 0) {
        printf("Les mots de passe ne correspondent pas.\n");
        return;
    }

    if (!hash_password(new_password, new_hash)) {
        printf("Erreur lors du hachage.\n");
        return;
    }

    snprintf(users[user_id].password_hash,
             sizeof(users[user_id].password_hash),
             "%s",
             new_hash);

    memset(old_password, 0, sizeof(old_password));
    memset(new_password, 0, sizeof(new_password));
    memset(confirmation, 0, sizeof(confirmation));
    memset(old_hash, 0, sizeof(old_hash));
    memset(new_hash, 0, sizeof(new_hash));

    printf("Mot de passe modifié.\n");
}

// Calculer statistiques
void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];
    
    for(int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }
    
    avg = (double)total / user_count;
    
    sprintf(buffer, "Total: %d€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

// Chercher un utilisateur
void search_user() {
    char query[100];
    
    printf("Rechercher: ");
    scanf("%s", query);
    
    for(int i = 0; i < user_count; i++) {
        if(strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
        }
    }
}

// Nettoyer les sessions
void cleanup_sessions() {
    time_t now = time(NULL);
    for(int i = 0; i < session_count; i++) {
        if(now - sessions[i].created > 3600) {
            printf("Session %d expirée\n", i);
        }
    }
}

// Afficher menu
void display_menu() {
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE    ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                  ║\n");
    printf("║ 2. Se connecter                  ║\n");
    printf("║ 3. Voir profil                   ║\n");
    printf("║ 4. Transférer argent             ║\n");
    printf("║ 5. Backup données                ║\n");
    printf("║ 6. Restaurer données             ║\n");
    printf("║ 7. Commande système              ║\n");
    printf("║ 8. Cloner utilisateur            ║\n");
    printf("║ 9. Liste utilisateurs            ║\n");
    printf("║ 10. Changer mot de passe         ║\n");
    printf("║ 11. Statistiques                 ║\n");
    printf("║ 12. Rechercher utilisateur       ║\n");
    printf("║ 0. Quitter                       ║\n");
    printf("╚═══════════════════════════════════╝\n");
    printf("Choix: ");
}

int main() {
    int choice;
    int logged_user = -1;
    char username[USERNAME_SIZE];
    char password[PASSWORD_SIZE];
    
    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - CODE VULNÉRABLE         ║\n");
    printf("║  Durée: 4 heures                         ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");
    
	// Initialisation sécurisée du compte administrateur
	char admin_password[PASSWORD_SIZE];
	char admin_hash[PASSWORD_HASH_SIZE];

	snprintf(users[0].username,
         	sizeof(users[0].username),
         	"%s",
         	"admin");

	printf("Définissez le mot de passe administrateur : ");

	if (!read_line(admin_password, sizeof(admin_password)) ||
    		!is_valid_password(admin_password))
	{
    		fprintf(stderr,
            		"Mot de passe administrateur invalide.\n");
    		return EXIT_FAILURE;
	}

	if (!hash_password(admin_password, admin_hash))
	{
    		fprintf(stderr,
            		"Erreur de hachage.\n");
    		return EXIT_FAILURE;
	}

	snprintf(users[0].password_hash,
         	sizeof(users[0].password_hash),
         	"%s",
         	admin_hash);

	users[0].admin_flag = 1;
	users[0].balance = 10000;

	users[0].token = malloc(strlen("ADMIN_TOKEN") + 1);

	if (users[0].token == NULL)
	{
    		fprintf(stderr, "Erreur d'allocation mémoire.\n");
    		return EXIT_FAILURE;
	}

	strcpy(users[0].token, "ADMIN_TOKEN");

	user_count = 1;

	memset(admin_password, 0, sizeof(admin_password));
	memset(admin_hash, 0, sizeof(admin_hash));
    while(1) {
        display_menu();
        scanf("%d", &choice);
        getchar();
        
        switch(choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                scanf("%s", username);
                printf("Password: ");
                scanf("%s", password);
                logged_user = login_user(username, password);
                if(logged_user >= 0) {
                    printf("✓ Connecté en tant que %s\n", users[logged_user].username);
                } else {
                    printf("✗ Échec de connexion\n");
                }
                break;
            case 3:
                if(logged_user >= 0) {
                    show_profile(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 4:
                if(logged_user >= 0) {
                    transfer_money(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 5:
                if(logged_user >= 0) {
                    backup_user_data(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 6:
                restore_user_data();
                break;
            case 7:
                if(logged_user >= 0 && users[logged_user].admin_flag) {
                    system_command();
                } else {
                    printf("Accès refusé\n");
                }
                break;
            case 8:
                if(logged_user >= 0) {
                    clone_user(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 9:
                list_users();
                break;
            case 10:
                if(logged_user >= 0) {
                    change_password(logged_user);
                } else {
                    printf("Veuillez vous connecter\n");
                }
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }
    
    return 0;
}
