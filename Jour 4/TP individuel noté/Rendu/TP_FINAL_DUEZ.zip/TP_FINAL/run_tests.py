#!/usr/bin/env python3
"""Tests de securite de ./secure, pilotes avec pexpect.

Chaque etape envoie un choix de menu (plus les lignes que la fonction
appelee est censee lire), puis affiche tout ce que le programme a repondu
jusqu'au prompt suivant.
"""
import pexpect

BIN = "./secure"

p = pexpect.spawn(BIN, encoding="utf-8", timeout=10)
p.expect(r"une seule fois\) : (\S+)")
ADMIN_PW = p.match.group(1)
p.expect("Choix: ")


def step(title, choice, lines=()):
    p.sendline(str(choice))
    for line in lines:
        p.sendline(line)
    p.expect("Choix: ")
    out = p.before.replace("\r\n", "\n")
    # on retire le menu, deja connu, pour garder un rapport lisible
    out = out.split("\n╔")[0].strip()
    print("=" * 68)
    print("### " + title)
    print("-" * 68)
    print(out)
    print()


print("Mot de passe admin genere pour cette execution :", ADMIN_PW)
print()

# --- Buffer overflow ------------------------------------------------
step("Test 1 - Buffer overflow : username de 500 caracteres",
     1, ["A" * 500])

# --- Authentification -----------------------------------------------
step("Test 2 - Login admin avec le mot de passe genere",
     2, ["admin", ADMIN_PW])

# --- Format string ---------------------------------------------------
step("Test 3 - Format string : note = %s%s%s%s%n %x %x %x",
     3, ["%s%s%s%s%n %x %x %x"])

# --- Path traversal --------------------------------------------------
step("Test 4 - Path traversal en ecriture (backup)",
     5, ["../../../../etc/passwd"])
step("Test 5 - Backup avec un nom de fichier valide",
     5, ["admin_backup.txt"])
step("Test 6 - Path traversal en lecture (restore)",
     6, ["../../../../etc/passwd"])
step("Test 7 - Restore du backup legitime (aucun secret dedans)",
     6, ["admin_backup.txt"])

# --- Injection de commande -------------------------------------------
step("Test 8 - Injection de commande : '1; cat /etc/shadow'",
     7, ["1; cat /etc/shadow"])
step("Test 9 - Commande de la liste blanche (date)",
     7, ["1"])

# --- Backdoor --------------------------------------------------------
step("Test 10 - Backdoor 'master_reset_2024'",
     10, ["master_reset_2024"])

# --- Logique metier du transfert -------------------------------------
step("Test 11 - Deconnexion", 13)
step("Test 12 - Creation d'un compte non-admin",
     1, ["victime", "Password1", "Password1"])
step("Test 13 - Login sur le compte non-admin",
     2, ["victime", "Password1"])
step("Test 14 - Transfert d'un montant negatif (-5000)",
     4, ["admin", "-5000"])
step("Test 15 - Transfert superieur au solde (999999)",
     4, ["admin", "999999"])
step("Test 16 - Transfert vers soi-meme",
     4, ["victime"])
step("Test 17 - Transfert legitime de 40 EUR",
     4, ["admin", "40"])

# --- Controle d'acces ------------------------------------------------
step("Test 18 - Commande systeme demandee par un non-admin", 7)
step("Test 19 - Clonage demande par un non-admin", 8)
step("Test 20 - Statistiques globales demandees par un non-admin", 11)
step("Test 21 - NON CORRIGE : un non-admin voit les soldes et les droits",
     9)

# --- Tentatives de connexion (protection non implementee) ------------
step("Test 22 - Deconnexion", 13)
for i in range(4):
    step("Test 23.%d - NON CORRIGE : tentative erronee, aucun verrouillage"
         % (i + 1), 2, ["admin", "MauvaisMdp%d" % i])

# --- Autres protections non implementees -----------------------------
step("Test 24 - NON CORRIGE : restauration sans etre connecte",
     6, ["admin_backup.txt"])
step("Test 25 - NON CORRIGE : confirmation du mot de passe non verifiee",
     1, ["clonetest", "Password1", "PasDuToutPareil9"])

# --- Entrees invalides au menu ---------------------------------------
step("Test 26 - Choix de menu non numerique ('AAAA')", "AAAA")
step("Test 27 - Choix de menu hors bornes", "99999999999999999999")

# --- Sortie ----------------------------------------------------------
p.sendline("0")
p.expect(pexpect.EOF)
print("=" * 68)
print("### Test 28 - Sortie propre")
print("-" * 68)
print(p.before.replace("\r\n", "\n").strip())
p.close()
print()
print("Code de sortie :", p.exitstatus)
