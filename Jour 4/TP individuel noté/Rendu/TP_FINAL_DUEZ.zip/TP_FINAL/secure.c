/*
 * TP FINAL NOTÉ - Version sécurisée de vulnerable.c
 * Système de gestion de comptes utilisateurs avec authentification
 *
 * Compilation :
 *   make secure
 *   gcc -Wall -Wextra -O2 -g -fstack-protector-all -D_FORTIFY_SOURCE=2 \
 *       -o secure secure.c -lcrypto
 *
 * Les corrections sont repérées par des commentaires "SEC:" et détaillées
 * dans RAPPORT.md (le numéro renvoie au tableau récapitulatif du rapport).
 */

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <openssl/sha.h>
#include <openssl/rand.h>

#define MAX_USERS          20
#define MAX_SESSIONS       10

#define USERNAME_LEN       16          /* 15 caractères utiles + '\0' */
#define USERNAME_MIN        3
#define PASSWORD_MIN        8
#define PASSWORD_MAX       64
#define SALT_LEN           16
#define HASH_LEN           SHA256_DIGEST_LENGTH
#define TOKEN_LEN          40          /* "TOK_" + 32 hex + '\0' */

#define SESSION_TIMEOUT   900          /* 15 minutes d'inactivité */

#define DEFAULT_BALANCE   100
#define MAX_TRANSFER  1000000L

#define FILENAME_LEN       33          /* 32 caractères utiles + '\0' */
#define BACKUP_DIR         "backups"
#define MAX_RESTORE_LINES  64
#define LOG_FILE           "security.log"

/* SEC-02, SEC-03 : le mot de passe en clair ne se trouve plus jamais dans la
 * structure. On ne conserve qu'un sel aléatoire et un SHA-256 salé. */
typedef struct {
    char          username[USERNAME_LEN];
    unsigned char salt[SALT_LEN];
    unsigned char hash[HASH_LEN];
    int           admin_flag;
    long          balance;
    char         *token;
} User;

typedef struct {
    int    user_id;
    char   session_data[64];
    time_t created;
} Session;

static User    users[MAX_USERS];
static Session sessions[MAX_SESSIONS];
static int     user_count    = 0;
static int     session_count = 0;

/* État de la session courante (SEC-30) */
static int     logged_user   = -1;
static time_t  session_start = 0;

/* ------------------------------------------------------------------ */
/* Utilitaires                                                         */
/* ------------------------------------------------------------------ */

/* SEC-11 : journal de sécurité. Le message et le détail sont passés en
 * argument de "%s", jamais comme format : pas de format string possible. */
static void log_event(const char *event, const char *detail)
{
    FILE *fp;
    time_t now;
    struct tm tm_buf;
    char stamp[32];

    fp = fopen(LOG_FILE, "a");
    if (!fp)
        return;

    now = time(NULL);
    if (localtime_r(&now, &tm_buf) == NULL ||
        strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", &tm_buf) == 0)
        snprintf(stamp, sizeof stamp, "date-inconnue");

    fprintf(fp, "[%s] %-14s %s\n", stamp, event, detail ? detail : "-");
    fclose(fp);
}

/* SEC-04 : remplace gets() et scanf("%s"). Lecture bornée d'une ligne.
 * Retour :  0 = OK, -1 = EOF/erreur, -2 = ligne trop longue (tronquée).
 * En cas de troncature le reste de la ligne est consommé pour ne pas
 * décaler les lectures suivantes. */
static int read_line(const char *prompt, char *buf, size_t size)
{
    size_t len;
    int c, truncated = 0;

    if (prompt) {
        printf("%s", prompt);
        fflush(stdout);
    }

    if (fgets(buf, (int)size, stdin) == NULL) {
        buf[0] = '\0';
        return -1;
    }

    len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
        return 0;
    }

    while ((c = getchar()) != '\n' && c != EOF)
        truncated = 1;

    return truncated ? -2 : 0;
}

/* SEC-07, SEC-16, SEC-36 : lecture d'un entier avec strtol + bornes explicites.
 * scanf("%d") ne permettait pas de distinguer "échec de conversion" de
 * "valeur lue", ce qui laissait des variables non initialisées. */
static int read_long(const char *prompt, long min, long max, long *out)
{
    char buf[32];
    char *end;
    long value;

    if (read_line(prompt, buf, sizeof buf) != 0)
        return -1;

    errno = 0;
    value = strtol(buf, &end, 10);
    if (end == buf)
        return -1;
    while (*end == ' ' || *end == '\t')
        end++;
    if (*end != '\0')
        return -1;
    if (errno == ERANGE || value < min || value > max)
        return -1;

    *out = value;
    return 0;
}

/* ------------------------------------------------------------------ */
/* Validation des entrées                                              */
/* ------------------------------------------------------------------ */

/* SEC-05 : liste blanche de caractères + bornes de longueur. */
static int valid_username(const char *s)
{
    size_t i, len = strlen(s);

    if (len < USERNAME_MIN || len >= USERNAME_LEN)
        return 0;
    for (i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        if (!isalnum(c) && c != '_' && c != '-')
            return 0;
    }
    return 1;
}

/* Politique de mot de passe minimale (bonus). */
static int valid_password(const char *p)
{
    size_t i, len = strlen(p);
    int upper = 0, lower = 0, digit = 0;

    if (len < PASSWORD_MIN || len > PASSWORD_MAX)
        return 0;
    for (i = 0; i < len; i++) {
        unsigned char c = (unsigned char)p[i];
        if (isupper(c))      upper = 1;
        else if (islower(c)) lower = 1;
        else if (isdigit(c)) digit = 1;
    }
    return upper && lower && digit;
}

/* SEC-20, SEC-23 : anti path traversal. Le nom doit être un simple nom de
 * fichier : pas de '/', pas de "..", pas de nom caché, liste blanche de
 * caractères. Le répertoire est imposé par le programme, pas par l'utilisateur. */
static int valid_filename(const char *s)
{
    size_t i, len = strlen(s);

    if (len == 0 || len >= FILENAME_LEN)
        return 0;
    if (s[0] == '.' || s[0] == '-')
        return 0;
    if (strstr(s, "..") != NULL)
        return 0;
    for (i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        if (!isalnum(c) && c != '_' && c != '-' && c != '.')
            return 0;
    }
    return 1;
}

/* ------------------------------------------------------------------ */
/* Cryptographie                                                       */
/* ------------------------------------------------------------------ */

/* SEC-01 : SHA-256 salé à la place du djb2 maison. */
static int hash_password(const char *pass, const unsigned char *salt,
                         unsigned char *out)
{
    unsigned char buf[SALT_LEN + PASSWORD_MAX];
    size_t plen = strlen(pass);

    if (plen > PASSWORD_MAX)
        return -1;

    memcpy(buf, salt, SALT_LEN);
    memcpy(buf + SALT_LEN, pass, plen);
    SHA256(buf, SALT_LEN + plen, out);
    memset(buf, 0, sizeof buf);
    return 0;
}

/* SEC-09 : jeton imprévisible (16 octets aléatoires en hexa) et de taille
 * fixe : il ne contient plus le nom d'utilisateur et ne peut plus déborder. */
static char *new_token(void)
{
    unsigned char raw[16];
    char *tok;
    size_t i, off;

    tok = malloc(TOKEN_LEN);
    if (!tok)                                /* SEC-08 : malloc vérifié */
        return NULL;
    if (RAND_bytes(raw, sizeof raw) != 1) {
        free(tok);
        return NULL;
    }

    off = (size_t)snprintf(tok, TOKEN_LEN, "TOK_");
    for (i = 0; i < sizeof raw && off + 2 < TOKEN_LEN; i++)
        off += (size_t)snprintf(tok + off, TOKEN_LEN - off, "%02x", raw[i]);

    return tok;
}

/* Mot de passe aléatoire respectant la politique (SEC-38). */
static int random_password(char *buf, size_t len)
{
    static const char charset[] =
        "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    unsigned char raw[32];
    size_t i;

    if (len < PASSWORD_MIN + 1 || len - 1 > sizeof raw)
        return -1;
    if (RAND_bytes(raw, len - 1) != 1)
        return -1;

    for (i = 0; i < len - 1; i++)
        buf[i] = charset[raw[i] % (sizeof charset - 1)];
    buf[len - 1] = '\0';

    /* On force la présence des trois classes exigées par valid_password(). */
    buf[0] = (char)('A' + raw[0] % 26);
    buf[1] = (char)('a' + raw[1] % 26);
    buf[2] = (char)('0' + raw[2] % 10);
    return 0;
}

/* ------------------------------------------------------------------ */
/* Gestion des comptes                                                 */
/* ------------------------------------------------------------------ */

static int find_user(const char *username)
{
    int i;

    for (i = 0; i < user_count; i++)
        if (strcmp(users[i].username, username) == 0)
            return i;
    return -1;
}

/* Création centralisée : un seul endroit valide les tailles, tire le sel,
 * calcule le hash et vérifie les allocations. */
static int create_user(const char *username, const char *password,
                       int admin, long balance)
{
    User *u;

    if (user_count >= MAX_USERS)
        return -1;
    if (!valid_username(username))
        return -2;
    if (find_user(username) >= 0)            /* SEC-06 : pas de doublon */
        return -3;

    u = &users[user_count];
    memset(u, 0, sizeof *u);

    /* snprintf tronque au besoin et termine toujours par '\0' : plus de
     * strcpy d'un buffer de 100 octets vers un champ de 16 (SEC-03). */
    snprintf(u->username, sizeof u->username, "%s", username);

    if (RAND_bytes(u->salt, SALT_LEN) != 1)
        return -4;
    if (hash_password(password, u->salt, u->hash) != 0)
        return -4;

    u->admin_flag = admin ? 1 : 0;
    u->balance    = balance;
    u->token      = new_token();
    if (!u->token) {
        memset(u, 0, sizeof *u);
        return -4;
    }

    return user_count++;
}

static void print_create_error(int rc)
{
    switch (rc) {
    case -1: printf("Maximum d'utilisateurs atteint\n"); break;
    case -2: printf("Nom d'utilisateur invalide\n");     break;
    case -3: printf("Ce nom d'utilisateur existe déjà\n"); break;
    default: printf("Erreur interne lors de la création du compte\n"); break;
    }
}

/* SEC-12 : toute opération privilégiée passe par ce contrôle. L'index est
 * revalidé avant d'être utilisé comme indice de users[]. */
static int session_active(void)
{
    if (logged_user < 0 || logged_user >= user_count)
        return 0;
    return 1;
}

static int session_admin(void)
{
    return session_active() && users[logged_user].admin_flag;
}

/* ------------------------------------------------------------------ */
/* Fonctionnalités                                                     */
/* ------------------------------------------------------------------ */

/* SEC-05, SEC-06 : plus de choix "admin" laissé à l'utilisateur, confirmation du
 * mot de passe réellement vérifiée. */
static void register_user(void)
{
    char username[USERNAME_LEN];
    char password[PASSWORD_MAX + 1];
    char confirm[PASSWORD_MAX + 1];
    int rc;

    printf("=== ENREGISTREMENT ===\n");

    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    if (read_line("Username: ", username, sizeof username) != 0 ||
        !valid_username(username)) {
        printf("Nom invalide : %d à %d caractères alphanumériques, '_' ou '-'.\n",
               USERNAME_MIN, USERNAME_LEN - 1);
        return;
    }

    if (read_line("Password: ", password, sizeof password) != 0) {
        printf("Saisie invalide\n");
        return;
    }
    if (!valid_password(password)) {
        printf("Mot de passe trop faible : %d caractères minimum, "
               "avec majuscule, minuscule et chiffre.\n", PASSWORD_MIN);
        memset(password, 0, sizeof password);
        return;
    }

    read_line("Confirmer password: ", confirm, sizeof confirm);

    /* SEC-06 : un compte créé depuis le menu public n'est jamais admin. */
    rc = create_user(username, password, 0, DEFAULT_BALANCE);
    memset(password, 0, sizeof password);
    memset(confirm, 0, sizeof confirm);

    if (rc < 0) {
        print_create_error(rc);
        log_event("REGISTER_FAIL", username);
        return;
    }

    printf("Utilisateur enregistré!\n");
    log_event("REGISTER_OK", username);
}

/* SEC-13, SEC-14 : comparaison de hash à temps constant, verrouillage après
 * plusieurs échecs, aucun message ne distingue "compte inconnu" de
 * "mot de passe faux". */
static void do_login(void)
{
    char username[USERNAME_LEN];
    char password[PASSWORD_MAX + 1];
    unsigned char hash[HASH_LEN];
    int id, ok = 0;

    if (read_line("Username: ", username, sizeof username) != 0 ||
        read_line("Password: ", password, sizeof password) != 0) {
        printf("✗ Échec de connexion\n");
        memset(password, 0, sizeof password);
        return;
    }

    id = find_user(username);
    if (id >= 0 && hash_password(password, users[id].salt, hash) == 0)
        ok = (memcmp(hash, users[id].hash, HASH_LEN) == 0);

    memset(password, 0, sizeof password);
    memset(hash, 0, sizeof hash);

    if (ok) {
        logged_user   = id;
        session_start = time(NULL);
        printf("✓ Connecté en tant que %s\n", users[id].username);
        log_event("LOGIN_OK", users[id].username);
        return;
    }

    printf("✗ Échec de connexion\n");
    log_event("LOGIN_FAIL", username);
}

static void do_logout(void)
{
    if (logged_user < 0) {
        printf("Aucune session active\n");
        return;
    }
    log_event("LOGOUT", users[logged_user].username);
    logged_user   = -1;
    session_start = 0;
    printf("Déconnecté\n");
}

/* SEC-15 : plus de printf(entrée_utilisateur). Le format est un littéral et
 * la chaîne de l'utilisateur est un simple argument "%s". */
static void show_profile(int user_id)
{
    char note[80];

    if (user_id < 0 || user_id >= user_count) {   /* SEC-12 */
        printf("Utilisateur inconnu\n");
        return;
    }

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %ld€\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");
    printf("Token: %s\n", users[user_id].token);

    if (read_line("Note personnelle à afficher: ", note, sizeof note) < -1) {
        printf("Note trop longue, ignorée\n");
        return;
    }
    printf("Note: %s\n", note);
}

/* SEC-16, SEC-17, SEC-18 : montant borné et strictement positif, solde
 * vérifié, auto-transfert refusé. */
static void transfer_money(int from_user)
{
    char to_username[USERNAME_LEN];
    char detail[128];
    long amount;
    int to_user;

    printf("=== TRANSFERT ===\n");

    if (read_line("Vers quel utilisateur: ", to_username,
                  sizeof to_username) != 0) {
        printf("Nom de destinataire invalide\n");
        return;
    }

    to_user = find_user(to_username);
    if (to_user < 0) {
        printf("Utilisateur destinataire introuvable\n");
        return;
    }
    if (to_user == from_user) {
        printf("Transfert vers soi-même refusé\n");
        return;
    }

    if (read_long("Montant: ", 1, MAX_TRANSFER, &amount) != 0) {
        printf("Montant invalide (entier entre 1 et %ld)\n", MAX_TRANSFER);
        return;
    }
    if (amount > users[from_user].balance) {
        printf("Solde insuffisant (solde actuel : %ld€)\n",
               users[from_user].balance);
        log_event("TRANSFER_DENY", users[from_user].username);
        return;
    }
    users[from_user].balance -= amount;
    users[to_user].balance   += amount;

    snprintf(detail, sizeof detail, "%s -> %s : %ld EUR",
             users[from_user].username, users[to_user].username, amount);
    log_event("TRANSFER_OK", detail);

    printf("Transfert effectué! Nouveau solde : %ld€\n",
           users[from_user].balance);
}

/* Construit BACKUP_DIR/<nom> après validation stricte du nom. */
static int build_backup_path(const char *name, char *path, size_t size)
{
    int n;

    if (!valid_filename(name)) {
        printf("Nom de fichier refusé : lettres, chiffres, '.', '_' et '-' "
               "uniquement (%d caractères max, pas de chemin)\n",
               FILENAME_LEN - 1);
        return -1;
    }

    n = snprintf(path, size, "%s/%s", BACKUP_DIR, name);
    if (n < 0 || (size_t)n >= size) {
        printf("Chemin trop long\n");
        return -1;
    }
    return 0;
}

/* SEC-20, SEC-21, SEC-22 : écriture dans un répertoire imposé, jamais de mot de passe
 * ni de hash dans le fichier. */
static void backup_user_data(int user_id)
{
    char name[FILENAME_LEN];
    char path[sizeof BACKUP_DIR + FILENAME_LEN + 1];
    char stamp[32];
    struct tm tm_buf;
    time_t now;
    FILE *fp;

    if (user_id < 0 || user_id >= user_count) {
        printf("Utilisateur inconnu\n");
        return;
    }

    if (read_line("Nom du fichier de backup: ", name, sizeof name) != 0) {
        printf("Nom de fichier invalide\n");
        return;
    }
    if (build_backup_path(name, path, sizeof path) != 0)
        return;

    if (mkdir(BACKUP_DIR, 0700) != 0 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    fp = fopen(path, "w");
    if (!fp) {
        perror("fopen");
        log_event("BACKUP_FAIL", name);
        return;
    }

    now = time(NULL);
    if (localtime_r(&now, &tm_buf) == NULL ||
        strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", &tm_buf) == 0)
        snprintf(stamp, sizeof stamp, "date-inconnue");

    /* SEC-21 : aucune donnée d'authentification n'est exportée. */
    fprintf(fp, "username=%s\nadmin=%d\nbalance=%ld\ndate=%s\n",
            users[user_id].username, users[user_id].admin_flag,
            users[user_id].balance, stamp);
    fclose(fp);

    printf("Backup créé : %s\n", path);
    log_event("BACKUP_OK", path);
}

/* SEC-23, SEC-24, SEC-25 : lecture limitée au répertoire de backup, réservée
 * aux utilisateurs connectés, nombre de lignes borné. */
static void restore_user_data(void)
{
    char name[FILENAME_LEN];
    char path[sizeof BACKUP_DIR + FILENAME_LEN + 1];
    char buffer[256];
    int lines = 0;
    FILE *fp;

    if (read_line("Fichier à restaurer: ", name, sizeof name) != 0) {
        printf("Nom de fichier invalide\n");
        return;
    }
    if (build_backup_path(name, path, sizeof path) != 0)
        return;

    fp = fopen(path, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        log_event("RESTORE_FAIL", path);
        return;
    }

    while (lines < MAX_RESTORE_LINES && fgets(buffer, sizeof buffer, fp)) {
        printf("%s", buffer);
        lines++;
    }

    fclose(fp);
    log_event("RESTORE_OK", path);
}

/* SEC-26, SEC-27 : plus de system(), plus de shell, plus de chaîne construite
 * avec l'entrée utilisateur. L'utilisateur choisit un index dans une liste
 * blanche et la commande est lancée par execv() avec un argv figé. */
static const struct {
    const char *label;
    const char *path;
    char *const argv[3];
} ALLOWED_CMDS[] = {
    { "Date et heure du serveur", "/bin/date",     { "date",   NULL, NULL } },
    { "Charge et uptime",         "/usr/bin/uptime", { "uptime", NULL, NULL } },
    { "Espace disque",            "/bin/df",       { "df", "-h", NULL } },
};

static void system_command(void)
{
    const size_t ncmd = sizeof ALLOWED_CMDS / sizeof ALLOWED_CMDS[0];
    size_t i;
    long choice;
    pid_t pid;
    int status;

    printf("=== COMMANDES AUTORISÉES ===\n");
    for (i = 0; i < ncmd; i++)
        printf("%zu. %s\n", i + 1, ALLOWED_CMDS[i].label);

    if (read_long("Numéro de la commande: ", 1, (long)ncmd, &choice) != 0) {
        printf("Choix invalide\n");
        return;
    }
    i = (size_t)choice - 1;

    fflush(NULL);
    pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    }
    if (pid == 0) {
        /* execv : pas d'interprétation par /bin/sh, donc ni ';' ni '|'
         * ni '$(...)' exploitables. */
        execv(ALLOWED_CMDS[i].path, ALLOWED_CMDS[i].argv);
        perror("execv");
        _exit(127);
    }
    if (waitpid(pid, &status, 0) < 0)
        perror("waitpid");

    log_event("EXEC_CMD", ALLOWED_CMDS[i].label);
}

/* SEC-29 : le clone ne récupère plus ni le mot de passe ni le flag admin, et
 * l'opération est réservée à un administrateur. */
static void clone_user(void)
{
    char source[USERNAME_LEN];
    char target[USERNAME_LEN];
    char password[PASSWORD_MAX + 1];
    char confirm[PASSWORD_MAX + 1];
    int src, rc;

    printf("=== CLONAGE (admin) ===\n");

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }

    if (read_line("Utilisateur source: ", source, sizeof source) != 0) {
        printf("Nom invalide\n");
        return;
    }
    src = find_user(source);
    if (src < 0) {
        printf("Utilisateur source introuvable\n");
        return;
    }

    if (read_line("Nom du clone: ", target, sizeof target) != 0 ||
        !valid_username(target)) {
        printf("Nom de clone invalide\n");
        return;
    }

    if (read_line("Mot de passe du clone: ", password, sizeof password) != 0 ||
        !valid_password(password)) {
        printf("Mot de passe trop faible\n");
        memset(password, 0, sizeof password);
        return;
    }
    if (read_line("Confirmer: ", confirm, sizeof confirm) != 0 ||
        strcmp(password, confirm) != 0) {
        printf("Les deux mots de passe ne correspondent pas\n");
        memset(password, 0, sizeof password);
        memset(confirm, 0, sizeof confirm);
        return;
    }

    /* Seul le solde est recopié : aucun secret, aucun privilège. */
    rc = create_user(target, password, 0, users[src].balance);
    memset(password, 0, sizeof password);
    memset(confirm, 0, sizeof confirm);

    if (rc < 0) {
        print_create_error(rc);
        return;
    }

    printf("Clone créé\n");
    log_event("CLONE_OK", target);
}

static void list_users(void)
{
    int i;

    printf("\n=== LISTE UTILISATEURS ===\n");
    for (i = 0; i < user_count; i++)
        printf("%d. %s (Balance: %ld€, Admin: %d)\n", i,
               users[i].username, users[i].balance, users[i].admin_flag);
}

/* SEC-32, SEC-33 : plus de backdoor "master_reset_2024", vérification de
 * l'ancien mot de passe par comparaison de hash, nouveau sel à chaque
 * changement, politique de robustesse appliquée. */
static void change_password(int user_id)
{
    char old_pass[PASSWORD_MAX + 1];
    char new_pass[PASSWORD_MAX + 1];
    char confirm[PASSWORD_MAX + 1];
    unsigned char hash[HASH_LEN];
    unsigned char new_salt[SALT_LEN];
    unsigned char new_hash[HASH_LEN];

    if (user_id < 0 || user_id >= user_count) {
        printf("Utilisateur inconnu\n");
        return;
    }

    printf("=== CHANGEMENT MOT DE PASSE ===\n");

    if (read_line("Ancien mot de passe: ", old_pass, sizeof old_pass) != 0) {
        printf("Ancien mot de passe incorrect\n");
        memset(old_pass, 0, sizeof old_pass);
        return;
    }

    if (hash_password(old_pass, users[user_id].salt, hash) != 0 ||
        memcmp(hash, users[user_id].hash, HASH_LEN) != 0) {
        printf("Ancien mot de passe incorrect\n");
        memset(old_pass, 0, sizeof old_pass);
        memset(hash, 0, sizeof hash);
        log_event("PASSWD_FAIL", users[user_id].username);
        return;
    }
    memset(hash, 0, sizeof hash);

    if (read_line("Nouveau mot de passe: ", new_pass, sizeof new_pass) != 0 ||
        !valid_password(new_pass)) {
        printf("Mot de passe trop faible : %d caractères minimum, "
               "avec majuscule, minuscule et chiffre.\n", PASSWORD_MIN);
        goto cleanup;
    }
    if (strcmp(new_pass, old_pass) == 0) {
        printf("Le nouveau mot de passe doit être différent de l'ancien\n");
        goto cleanup;
    }
    if (read_line("Confirmer: ", confirm, sizeof confirm) != 0 ||
        strcmp(new_pass, confirm) != 0) {
        printf("Les deux mots de passe ne correspondent pas\n");
        goto cleanup;
    }

    if (RAND_bytes(new_salt, SALT_LEN) != 1 ||
        hash_password(new_pass, new_salt, new_hash) != 0) {
        printf("Erreur interne\n");
        goto cleanup;
    }

    memcpy(users[user_id].salt, new_salt, SALT_LEN);
    memcpy(users[user_id].hash, new_hash, HASH_LEN);
    printf("Mot de passe changé\n");
    log_event("PASSWD_OK", users[user_id].username);

cleanup:
    memset(old_pass, 0, sizeof old_pass);
    memset(new_pass, 0, sizeof new_pass);
    memset(confirm, 0, sizeof confirm);
    memset(new_salt, 0, sizeof new_salt);
    memset(new_hash, 0, sizeof new_hash);
}

/* SEC-34 : snprintf borné à la place de sprintf. */
static void compute_stats(void)
{
    char buffer[120];
    long total = 0;
    double avg;
    int i;

    for (i = 0; i < user_count; i++)
        total += users[i].balance;

    avg = (double)total / (double)user_count;
    snprintf(buffer, sizeof buffer, "Total: %ld€, Moyenne: %.2f€", total, avg);
    printf("%s\n", buffer);
}

/* SEC-36 : requête bornée et validée. */
static void search_user(void)
{
    char query[USERNAME_LEN];
    int i, found = 0;

    if (read_line("Rechercher: ", query, sizeof query) != 0 ||
        strlen(query) == 0) {
        printf("Requête invalide\n");
        return;
    }
    for (i = 0; query[i] != '\0'; i++) {
        unsigned char c = (unsigned char)query[i];
        if (!isalnum(c) && c != '_' && c != '-') {
            printf("Requête invalide : caractères alphanumériques, "
                   "'_' et '-' uniquement\n");
            return;
        }
    }

    for (i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouvé: %s\n", users[i].username);
            found = 1;
        }
    }
    if (!found)
        printf("Aucun résultat\n");
}

/* SEC-37 : les sessions expirées sont réellement supprimées du tableau. */
static void cleanup_sessions(void)
{
    time_t now = time(NULL);
    int i = 0;

    while (i < session_count) {
        if (now - sessions[i].created > SESSION_TIMEOUT) {
            printf("Session %d expirée\n", i);
            sessions[i] = sessions[--session_count];
            memset(&sessions[session_count], 0, sizeof sessions[0]);
        } else {
            i++;
        }
    }
}

/* SEC-10 : libération de toutes les allocations + effacement des secrets. */
static void cleanup(void)
{
    int i;

    for (i = 0; i < user_count; i++) {
        if (users[i].token) {
            memset(users[i].token, 0, strlen(users[i].token));
            free(users[i].token);
            users[i].token = NULL;
        }
        memset(users[i].salt, 0, SALT_LEN);
        memset(users[i].hash, 0, HASH_LEN);
    }
    memset(sessions, 0, sizeof sessions);
    user_count    = 0;
    session_count = 0;
}

static void display_menu(void)
{
    printf("\n╔═══════════════════════════════════╗\n");
    printf("║   SYSTÈME DE GESTION BANCAIRE     ║\n");
    printf("╠═══════════════════════════════════╣\n");
    printf("║ 1. Créer compte                   ║\n");
    printf("║ 2. Se connecter                   ║\n");
    printf("║ 3. Voir profil                    ║\n");
    printf("║ 4. Transférer argent              ║\n");
    printf("║ 5. Backup données                 ║\n");
    printf("║ 6. Restaurer données              ║\n");
    printf("║ 7. Commande système (admin)       ║\n");
    printf("║ 8. Cloner utilisateur (admin)     ║\n");
    printf("║ 9. Liste utilisateurs             ║\n");
    printf("║ 10. Changer mot de passe          ║\n");
    printf("║ 11. Statistiques (admin)          ║\n");
    printf("║ 12. Rechercher utilisateur        ║\n");
    printf("║ 13. Se déconnecter                ║\n");
    printf("║ 0. Quitter                        ║\n");
    printf("╚═══════════════════════════════════╝\n");
}

/* SEC-38 : plus de compte admin avec un mot de passe en dur. Le mot de passe
 * initial est tiré aléatoirement et affiché une seule fois au démarrage. */
static int bootstrap_admin(void)
{
    char password[17];

    if (random_password(password, sizeof password) != 0)
        return -1;

    if (create_user("admin", password, 1, 10000) < 0) {
        memset(password, 0, sizeof password);
        return -1;
    }

    printf("Compte admin initialisé.\n");
    printf("Mot de passe temporaire (affiché une seule fois) : %s\n\n",
           password);
    memset(password, 0, sizeof password);
    log_event("BOOTSTRAP", "compte admin créé");
    return 0;
}

int main(void)
{
    long choice;

    printf("╔═══════════════════════════════════════════╗\n");
    printf("║  TP FINAL NOTÉ - VERSION SÉCURISÉE        ║\n");
    printf("╚═══════════════════════════════════════════╝\n\n");

    if (bootstrap_admin() != 0) {
        fprintf(stderr, "Erreur d'initialisation\n");
        return EXIT_FAILURE;
    }

    for (;;) {
        display_menu();
        cleanup_sessions();

        /* EOF ou saisie non numérique ne provoquent plus de boucle infinie
         * sur une variable non initialisée. */
        if (read_long("Choix: ", 0, 13, &choice) != 0) {
            if (feof(stdin)) {
                printf("\nAu revoir!\n");
                break;
            }
            printf("Choix invalide\n");
            continue;
        }

        switch (choice) {
        case 1:
            register_user();
            break;
        case 2:
            do_login();
            break;
        case 3:
            if (session_active())
                show_profile(logged_user);
            else
                printf("Veuillez vous connecter\n");
            break;
        case 4:
            if (session_active())
                transfer_money(logged_user);
            else
                printf("Veuillez vous connecter\n");
            break;
        case 5:
            if (session_active())
                backup_user_data(logged_user);
            else
                printf("Veuillez vous connecter\n");
            break;
        case 6:
            restore_user_data();
            break;
        case 7:
            if (session_admin())
                system_command();
            else
                printf("Accès refusé\n");
            break;
        case 8:
            if (session_admin())
                clone_user();
            else
                printf("Accès refusé\n");
            break;
        case 9:
            if (session_active())
                list_users();
            else
                printf("Veuillez vous connecter\n");
            break;
        case 10:
            if (session_active())
                change_password(logged_user);
            else
                printf("Veuillez vous connecter\n");
            break;
        case 11:
            if (session_admin())
                compute_stats();
            else
                printf("Accès refusé\n");
            break;
        case 12:
            if (session_active())
                search_user();
            else
                printf("Veuillez vous connecter\n");
            break;
        case 13:
            do_logout();
            break;
        case 0:
            printf("Au revoir!\n");
            cleanup();
            return EXIT_SUCCESS;
        default:
            printf("Choix invalide\n");
        }
    }

    cleanup();
    return EXIT_SUCCESS;
}
