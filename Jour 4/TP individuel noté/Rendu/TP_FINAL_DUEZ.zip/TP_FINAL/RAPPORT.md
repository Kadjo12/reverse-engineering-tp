========================================================================
                  RAPPORT DE SECURITE - TP FINAL
========================================================================

Etudiant : Esteban DUEZ
Date     : 30 juillet 2026
Duree    : 4 heures


SOMMAIRE
--------
  1. Synthese des vulnerabilites
  2. Corrections detaillees
  3. Tests de validation
  4. Conclusion
  Annexes


========================================================================
1. SYNTHESE DES VULNERABILITES
========================================================================

1.1 Comment j'ai procede
------------------------

J'ai d'abord cherche les fonctions dangereuses citees dans le cours avec
grep :

    grep -n "gets\|scanf\|strcpy\|strcat\|sprintf\|system\|malloc" vulnerable.c

Ca donne deja une bonne partie des problemes (tous les debordements de
buffer). Ensuite j'ai relu le programme fonction par fonction pour les
problemes de logique, que le grep ne peut pas voir : le flag admin qu'on
demande a l'utilisateur, le mot de passe cache dans change_password(), le
transfert avec un montant negatif.

Enfin j'ai teste les failles sur le programme compile pour verifier
qu'elles marchent vraiment.


1.2 Tableau recapitulatif
-------------------------

No  Fonction              Ligne(s)  Type                                          Gravite   Corrigee
--  --------------------  --------  --------------------------------------------  --------  --------
1   register_user()       61        scanf("%s") sans limite de taille             Critique  Oui
2   register_user()       64        scanf("%s") sans limite de taille             Critique  Oui
3   register_user()       67        scanf("%s") sans limite de taille             Critique  Oui
4   register_user()       70        L'utilisateur choisit s'il est admin          Critique  Oui
5   register_user()       72        strcpy() de 100 octets vers 16                Critique  Oui
6   register_user()       73        strcpy() de 100 octets vers 16                Critique  Oui
7   register_user()       77        malloc() sans verifier le retour              Haute     Oui
8   register_user()       78        sprintf() dans un malloc(32) trop petit       Critique  Oui
9   register_user()       67-72     confirm demande mais jamais compare           Moyenne   Non
10  struct User           21        Mot de passe stocke en clair                  Critique  Oui
11  hash_password()       39-45     Hash maison au lieu de SHA-256                Critique  Oui
12  login_user()          85-93     Pas de limite au nombre de tentatives         Haute     Non
13  show_profile()        105       gets() sans limite de taille                  Critique  Oui
14  show_profile()        106       printf(format) : faille format string         Critique  Oui
15  transfer_money()      117       scanf("%s") sans limite de taille             Haute     Oui
16  transfer_money()      120       Montant negatif accepte                       Critique  Oui
17  transfer_money()      124       Solde jamais verifie avant le debit           Haute     Oui
18  backup_user_data()    139       scanf("%s") sans limite de taille             Haute     Oui
19  backup_user_data()    141       Path traversal en ecriture                    Critique  Oui
20  backup_user_data()    143-147   Mot de passe ecrit en clair dans le fichier   Critique  Oui
21  restore_user_data()   160       scanf("%s") sans limite de taille             Haute     Oui
22  restore_user_data()   162       Path traversal en lecture                     Critique  Oui
23  main() (case 6)       360-362   Restauration accessible sans etre connecte    Haute     Non
24  system_command()      181       gets() sans limite de taille                  Critique  Oui
25  system_command()      184       system() avec l'entree utilisateur            Critique  Oui
26  clone_user()          192       scanf("%s") sans limite de taille             Haute     Oui
27  clone_user()          199       strcpy() de 30 octets vers 16                 Haute     Oui
28  clone_user()          200       Le clone recupere le mot de passe             Critique  Oui
29  clone_user()          201       Le clone recupere les droits admin            Critique  Oui
30  list_users()          212       Tout le monde voit les soldes et les admins   Moyenne   Non
31  change_password()     224       gets() sans limite de taille                  Critique  Oui
32  change_password()     227       Mot de passe cache master_reset_2024          Critique  Oui
33  change_password()     229       gets() sans limite de taille                  Critique  Oui
34  change_password()     230       strcpy() de 80 octets vers 16                 Critique  Oui
35  compute_stats()       247       Division par zero si aucun utilisateur        Moyenne   Non
36  search_user()         258       scanf("%s") sans limite de taille             Haute     Oui
37  main()                310-311   Mot de passe admin ecrit dans le code         Critique  Oui
38  main()                314       malloc() sans verifier le retour              Haute     Oui
39  main()                320       scanf("%d") : boucle infinie si on tape une lettre  Moyenne  Oui
40  main()                329, 331  scanf("%s") sans limite de taille             Haute     Oui
41  Tout le programme     77, 314   Aucun free() : fuite memoire                  Haute     Oui

Total : 41 vulnerabilites identifiees, 36 corrigees.
Repartition des 41 : 24 critiques, 13 hautes, 4 moyennes.
Repartition des 36 corrigees : 24 critiques, 11 hautes, 1 moyenne.

Les 5 vulnerabilites non corrigees (numeros 9, 12, 23, 30 et 35) sont des
problemes de logique metier et de controle d'acces que j'ai identifies mais
que je n'ai pas eu le temps de traiter. Elles sont detaillees en 4.3.

Je ne pretends pas non plus avoir tout trouve (voir 4.3).


========================================================================
2. CORRECTIONS DETAILLEES
========================================================================

------------------------------------------------------------------------
CORRECTION 1 : gets() et scanf("%s") sans limite
------------------------------------------------------------------------

Vulnerabilites concernees : 1, 2, 3, 13, 15, 18, 21, 24, 26, 31, 33, 36, 40

VULNERABILITE ORIGINALE

  Fonctions : presque toutes
  Lignes    : 61, 64, 67, 105, 117, 139, 160, 181, 192, 224, 229, 258,
              329, 331

  Description :

  Le programme lit ce que tape l'utilisateur sans jamais limiter la
  taille.

  gets() n'a aucun parametre de taille : on ne PEUT pas lui dire ou
  s'arreter. Le compilateur le dit lui-meme quand on compile
  vulnerable.c :
      "warning: the `gets' function is dangerous and should not be used."

  scanf("%s", buf) a le meme probleme : il s'arrete a l'espace, mais pas
  a la taille du buffer.

  Code vulnerable :

      /* vulnerable.c:54-61 */
      char username[100];
      ...
      scanf("%s", username);   /* rien n'empeche d'ecrire plus de 100 */

      /* vulnerable.c:97-105 */
      char format[80];
      gets(format);            /* pareil, et encore pire */

ATTAQUE POSSIBLE

  Si on tape 600 caracteres 'A' dans le champ username, on ecrit 600
  octets dans un buffer qui en fait 100. Les 500 octets en trop vont
  ecraser ce qu'il y a apres dans la pile.

  Le systeme detecte l'ecrasement et arrete le programme :
      *** stack smashing detected ***

  C'est un plantage, donc un deni de service. Et sans la protection du
  compilateur, on pourrait ecraser l'adresse de retour de la fonction et
  faire executer n'importe quel code.

  Test reel (run_exploits.py, exploit 9b) :

      Username: AAAA...(600 A)
      *** stack smashing detected ***: terminated
      [signal de sortie : 6]

  Impact :
      - Deni de service (plantage)
      - Execution de code arbitraire (possible)

CORRECTION IMPLEMENTEE

  J'ai ecrit une seule fonction read_line() qui lit une ligne avec
  fgets(), et je l'utilise partout a la place de gets() et scanf("%s").

      static int read_line(const char *prompt, char *buf, size_t size)
      {
          size_t len;
          int c, truncated = 0;

          if (prompt) { printf("%s", prompt); fflush(stdout); }

          if (fgets(buf, (int)size, stdin) == NULL) {
              buf[0] = '\0';
              return -1;
          }

          len = strlen(buf);
          if (len > 0 && buf[len - 1] == '\n') {
              buf[len - 1] = '\0';   /* on enleve le retour a la ligne */
              return 0;
          }

          /* si l'utilisateur a tape trop long, on vide le reste */
          while ((c = getchar()) != '\n' && c != EOF)
              truncated = 1;

          return truncated ? -2 : 0;
      }

  Modifications effectuees :
      1. Tous les gets() et tous les scanf("%s") sont remplaces.
      2. On passe toujours sizeof buf comme taille, pour ne pas se
         tromper.
      3. La fonction dit a l'appelant si ca s'est mal passe (EOF ou
         saisie trop longue), et l'appelant affiche un message d'erreur.

JUSTIFICATION DE SECURITE

  fgets() ecrit au maximum (taille - 1) caracteres plus le '\0'. Le
  debordement devient impossible, peu importe ce que tape l'utilisateur.

  J'ai aussi ajoute la boucle qui vide la fin de la ligne. Sans elle, les
  caracteres en trop restent dans le tampon d'entree et sont lus comme
  reponse a la question SUIVANTE, ce qui decale tout le menu.

TEST

      make test-attacks    (Test 1 : username de 500 caracteres)

  Resultat :
      Username: AAAA...(500 A)
      Nom invalide : 3 a 15 caracteres alphanumeriques, '_' ou '-'.


------------------------------------------------------------------------
CORRECTION 2 : strcpy() et sprintf() vers des champs trop petits
------------------------------------------------------------------------

Vulnerabilites concernees : 5, 6, 8, 27, 34

VULNERABILITE ORIGINALE

  Fonctions : register_user(), clone_user(), change_password()
  Lignes    : 72, 73, 78, 199, 230

  Description :

  Meme en limitant ce que tape l'utilisateur, la copie vers la structure
  User pose probleme : les champs username et password font 16 octets,
  alors que les buffers de depart font 30, 80 ou 100 octets.

  strcpy() copie jusqu'au '\0' de la source, il ne regarde jamais la
  taille de la destination.

  Ligne 78, c'est sprintf() qui ecrit "TOK_0_<nom>" dans un bloc de 32
  octets : avec un nom de 60 caracteres ca deborde aussi.

  Code vulnerable :

      /* vulnerable.c:19-25 */
      typedef struct {
          char username[16];
          char password[16];      /* seulement 16 octets */
          ...
      } User;

      /* vulnerable.c:72-78 */
      strcpy(users[user_count].username, username);   /* 100 vers 16 */
      strcpy(users[user_count].password, password);   /* 100 vers 16 */
      users[user_count].token = malloc(32);
      sprintf(users[user_count].token, "TOK_%d_%s", user_count, username);

ATTAQUE POSSIBLE

  users[] est un tableau global. Si on ecrit 300 octets dans
  users[1].username (16 octets), on deborde sur le champ password juste
  apres, puis sur admin_flag, balance, et sur les utilisateurs suivants.

  Le programme ne plante pas et continue normalement, donc on ne voit
  rien.

  Mais quand il affiche le nom avec printf("%s"), l'affichage ne s'arrete
  plus au bout du champ username (il n'y a plus de '\0'), il continue
  dans le champ password. Le mot de passe s'affiche a l'ecran.

  Test reel (exploit 9a, mot de passe choisi : SECRET) :

      Username: AAAA...(300 A)
      Password: SECRET
      ...
      === LISTE UTILISATEURS ===
      1. AAAAAAAAAAAAAAAASECRET
                        ^^^^^^ le mot de passe s'affiche

  Pour le debordement du malloc(32), il ne se voit pas du tout a
  l'execution. Je l'ai verifie avec valgrind :

      ==68530== Invalid write of size 2
      ==68530==    by 0x1095F4: register_user (vulnerable.c:78)

  Impact :
      - Fuite d'informations (le mot de passe d'un autre)
      - Corruption des donnees des autres comptes

CORRECTION IMPLEMENTEE

      static int create_user(const char *username, const char *password,
                             int admin, long balance)
      {
          User *u;

          if (user_count >= MAX_USERS)   return -1;
          if (!valid_username(username)) return -2;
          if (find_user(username) >= 0)  return -3;

          u = &users[user_count];
          memset(u, 0, sizeof *u);

          /* snprintf s'arrete a la bonne taille et met toujours le '\0' */
          snprintf(u->username, sizeof u->username, "%s", username);
          ...
      }

  Modifications effectuees :
      1. strcpy() remplace par snprintf(dst, sizeof dst, "%s", src).
         J'ai choisi snprintf plutot que strncpy parce que strncpy ne met
         pas toujours le '\0' a la fin, ce qui recree le probleme.
      2. sprintf() remplace par snprintf() avec la vraie taille.
      3. J'ai regroupe toute la creation de compte dans une seule
         fonction create_user(), comme ca il n'y a qu'un seul endroit a
         verifier.
      4. Le champ password n'existe plus dans la structure (correction 3).

JUSTIFICATION DE SECURITE

  snprintf(dst, sizeof dst, "%s", src) ne peut pas ecrire plus que la
  taille donnee, et il met toujours le '\0' final. Comme on utilise
  sizeof sur la destination elle-meme, la taille reste juste meme si on
  change la taille du champ plus tard.

  En plus, valid_username() refuse deja les noms de plus de 15
  caracteres, donc il y a deux protections l'une derriere l'autre.

TEST

      make test-attacks
      valgrind --leak-check=full ./secure    (aucun "Invalid write")


------------------------------------------------------------------------
CORRECTION 3 : Mot de passe en clair et hash maison
------------------------------------------------------------------------

Vulnerabilites concernees : 10, 11

VULNERABILITE ORIGINALE

  Fonctions : struct User, hash_password()
  Lignes    : 21, 39-45

  Description :

  Il y a deux problemes :

  1. La fonction hash_password() utilise un algo maison (djb2) qui n'est
     pas fait pour la securite : il sort seulement 32 bits et il est tres
     rapide a casser.

  2. Encore plus grave : cette fonction n'est JAMAIS APPELEE dans le
     programme. Le champ password[16] contient le mot de passe en clair.

  Code vulnerable :

      /* vulnerable.c:39-45 : jamais appelee */
      unsigned int hash_password(char *pass) {
          unsigned int h = 5381;
          int c;
          while ((c = *pass++))
              h = h * 33 + c;
          return h;
      }

      /* vulnerable.c:73 : le mot de passe est stocke tel quel */
      strcpy(users[user_count].password, password);

ATTAQUE POSSIBLE

  Tous les mots de passe sont lisibles directement dans la memoire du
  programme. Le debordement de la correction 2 suffit a en afficher un.

  Et la fonction de backup ecrivait ces mots de passe en clair dans un
  fichier (vulnerabilite 20).

  Impact :
      - Fuite d'informations (tous les mots de passe)

CORRECTION IMPLEMENTEE

      /* plus de mot de passe dans la structure */
      typedef struct {
          char          username[USERNAME_LEN];
          unsigned char salt[SALT_LEN];      /* 16 octets aleatoires */
          unsigned char hash[HASH_LEN];      /* SHA-256 */
          int           admin_flag;
          long          balance;
          char         *token;
      } User;

      static int hash_password(const char *pass, const unsigned char *salt,
                               unsigned char *out)
      {
          unsigned char buf[SALT_LEN + PASSWORD_MAX];
          size_t plen = strlen(pass);

          if (plen > PASSWORD_MAX)
              return -1;

          memcpy(buf, salt, SALT_LEN);
          memcpy(buf + SALT_LEN, pass, plen);
          SHA256(buf, SALT_LEN + plen, out);   /* SHA-256 d'OpenSSL */
          memset(buf, 0, sizeof buf);
          return 0;
      }

  Modifications effectuees :
      1. J'utilise SHA256() d'OpenSSL (#include <openssl/sha.h>, option
         -lcrypto) a la place du hash maison.
      2. J'ajoute un sel de 16 octets tire au hasard, different pour
         chaque compte.
      3. Le champ password[] est supprime : on ne garde que le sel et le
         hash.

JUSTIFICATION DE SECURITE

  SHA-256 fait 256 bits et on ne sait pas retrouver le mot de passe a
  partir du hash. Meme si quelqu'un lit la memoire du programme, il n'a
  que le hash.

  Le sel sert a ce que deux utilisateurs avec le meme mot de passe
  n'aient pas le meme hash. Ca empeche d'utiliser des tables toutes
  faites (rainbow tables) pour retrouver plusieurs mots de passe d'un
  coup.

TEST

      make test-attacks    (Test 2 : la connexion fonctionne toujours)


------------------------------------------------------------------------
CORRECTION 4 : Faille format string
------------------------------------------------------------------------

Vulnerabilite concernee : 14

VULNERABILITE ORIGINALE

  Fonction : show_profile()
  Lignes   : 104-107

  Description :

  Le texte tape par l'utilisateur est donne a printf() comme chaine de
  FORMAT au lieu d'etre donne comme argument. Du coup printf interprete
  les % que contient ce texte.

  Code vulnerable :

      /* vulnerable.c:104-107 */
      printf("Format d'affichage personnalise: ");
      gets(format);
      printf(format);          /* le format vient de l'utilisateur */

ATTAQUE POSSIBLE

  - Avec "%p %p %p %p", printf va chercher des arguments qui n'existent
    pas et affiche ce qu'il trouve dans la pile.
  - Avec "%n", printf ECRIT en memoire au lieu de lire. Ca fait planter
    le programme, et bien utilise ca permet de modifier la memoire.

  Test reel (exploits 2 et 3) :

      Format d'affichage personnalise: %p %p %p %p %p %p %p %p
      0x61678f5fe6e1 (nil) 0x7da51b8038e0 0x61678f5fe6f8 (nil) ...

      Format d'affichage personnalise: %n%n%n%n
      [signal de sortie : 11]    (SIGSEGV, le programme plante)

  Impact :
      - Lecture de la memoire
      - Deni de service (plantage)
      - Ecriture en memoire (avec %n)

CORRECTION IMPLEMENTEE

      if (read_line("Note personnelle a afficher: ", note,
                    sizeof note) < -1) {
          printf("Note trop longue, ignoree\n");
          return;
      }
      printf("Note: %s\n", note);   /* le format est ecrit en dur */

  Modifications effectuees :
      1. Le format est maintenant ecrit en dur dans le code, et le texte
         de l'utilisateur passe en argument de %s.
      2. J'ai remplace la fonction "format personnalise" (qui ne servait
         a rien) par une simple note affichee.
      3. gets() remplace par read_line().

JUSTIFICATION DE SECURITE

  Avec printf("%s", texte), printf ne voit qu'une seule directive (%s) et
  il a exactement un argument pour elle. Les % que contient le texte de
  l'utilisateur ne sont plus interpretes, ils sont juste affiches.

  La regle a retenir : la chaine de format ne doit jamais venir de
  l'utilisateur.

TEST

      make test-attacks    (Test 3)

  Resultat :
      Note personnelle a afficher: %s%s%s%s%n %x %x %x
      Note: %s%s%s%s%n %x %x %x

  Le texte s'affiche tel quel, rien n'est interprete.


------------------------------------------------------------------------
CORRECTION 5 : Injection de commande avec system()
------------------------------------------------------------------------

Vulnerabilites concernees : 24, 25

VULNERABILITE ORIGINALE

  Fonction : system_command()
  Lignes   : 175-185

  Description :

  Ce que tape l'utilisateur est colle dans une commande passee a
  system(). system() envoie la chaine au shell (/bin/sh), et le shell
  interprete les caracteres speciaux comme ';' ou '|'. Donc l'utilisateur
  ne donne pas un argument, il donne des commandes.

  Code vulnerable :

      /* vulnerable.c:181-184 */
      gets(cmd);
      sprintf(full_cmd, "echo 'Execution:' && %s", cmd);
      system(full_cmd);

ATTAQUE POSSIBLE

  Si on tape :   id; cat /etc/passwd
  le shell execute "echo 'Execution:' && id; cat /etc/passwd", donc deux
  commandes, la deuxieme etant choisie par l'attaquant.

  Le menu verifie bien qu'on est admin (ligne 364), mais ca ne protege
  pas : il suffit de repondre "1" a la question "Droits admin ?" a
  l'inscription (vulnerabilite 4).

  Test reel (exploit 1) :

      Commande: id; cat /etc/passwd | head -2
      Execution:
      uid=1001(vagrant) gid=1001(vagrant) groups=1001(vagrant),27(sudo)
      root:x:0:0:root:/root:/bin/bash
      daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin

  Impact :
      - Execution de code arbitraire
      - Fuite d'informations

CORRECTION IMPLEMENTEE

  Au lieu de laisser l'utilisateur taper une commande, je lui propose une
  liste de 3 commandes et il choisit un numero.

      static const struct {
          const char *label;
          const char *path;
          char *const argv[3];
      } ALLOWED_CMDS[] = {
          { "Date et heure du serveur", "/bin/date",
            { "date",   NULL, NULL } },
          { "Charge et uptime",         "/usr/bin/uptime",
            { "uptime", NULL, NULL } },
          { "Espace disque",            "/bin/df",
            { "df", "-h", NULL } },
      };

      static void system_command(void)
      {
          ...
          if (read_long("Numero de la commande: ", 1, (long)ncmd,
                        &choice) != 0) {
              printf("Choix invalide\n");
              return;
          }
          i = (size_t)choice - 1;

          pid = fork();
          if (pid == 0) {
              execv(ALLOWED_CMDS[i].path, ALLOWED_CMDS[i].argv);
              perror("execv");
              _exit(127);
          }
          waitpid(pid, &status, 0);
      }

  Modifications effectuees :
      1. system() supprime completement.
      2. J'utilise fork() + execv() : la commande et ses arguments sont
         ecrits en dur dans le code.
      3. L'utilisateur ne donne plus qu'un numero, verifie entre 1 et 3.
      4. J'utilise les chemins complets (/bin/date) pour ne pas dependre
         du PATH.

JUSTIFICATION DE SECURITE

  La grosse difference entre system() et execv(), c'est qu'execv() ne
  passe pas par le shell. system() envoie une chaine a /bin/sh qui va y
  chercher les caracteres speciaux. execv() recoit directement la liste
  des arguments et la donne au systeme : un ';' dans un argument reste un
  simple caractere.

  Ici en plus l'utilisateur ne choisit meme pas les arguments, juste un
  numero dans une liste fixe.

TEST

      make test-attacks    (Tests 8 et 9)

  Resultat :
      Test 8 - Numero de la commande: 1; cat /etc/shadow
               Choix invalide

      Test 9 - Numero de la commande: 1
               Thu Jul 30 13:19:00 UTC 2026


------------------------------------------------------------------------
CORRECTION 6 : Path traversal (lecture et ecriture de fichiers)
------------------------------------------------------------------------

Vulnerabilites concernees : 19, 20, 22, 23

VULNERABILITE ORIGINALE

  Fonctions : backup_user_data(), restore_user_data()
  Lignes    : 141, 143-147, 162, 360-362

  Description :

  Le nom du fichier vient de l'utilisateur et est donne directement a
  fopen(). Rien n'empeche de mettre un chemin complet comme /etc/passwd,
  ou de remonter dans les dossiers avec "..".

  En plus, le fichier de backup contient le mot de passe en clair, et la
  fonction de restauration est accessible sans etre connecte (case 6 du
  menu).

  Code vulnerable :

      /* vulnerable.c:139-147 */
      scanf("%s", filename);
      fp = fopen(filename, "w");        /* n'importe quel chemin */
      if(fp) {
          fprintf(fp, "%s:%s:%d:%d\n",
                  users[user_id].username,
                  users[user_id].password,   /* le mot de passe en clair */
                  ...

      /* vulnerable.c:360-362 : aucune verification */
      case 6:
          restore_user_data();
          break;

ATTAQUE POSSIBLE

  Test reel (exploit 7, sans etre connecte) :

      Choix: 6
      Fichier a restaurer: /etc/passwd
      root:x:0:0:root:/root:/bin/bash
      daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
      ...

  Test reel (exploit 8, en ecriture) :

      Nom du fichier de backup: /tmp/preuve_path_traversal.txt
      Backup cree
      Fichier a restaurer: /tmp/preuve_path_traversal.txt
      admin:admin123:1:10000       <- le mot de passe admin en clair

  Impact :
      - Lecture de n'importe quel fichier
      - Ecriture de n'importe quel fichier
      - Fuite d'informations (mots de passe sur le disque)

CORRECTION IMPLEMENTEE

      /* on verifie le nom du fichier */
      static int valid_filename(const char *s)
      {
          size_t i, len = strlen(s);

          if (len == 0 || len >= FILENAME_LEN) return 0;
          if (s[0] == '.' || s[0] == '-')      return 0;
          if (strstr(s, "..") != NULL)         return 0;
          for (i = 0; i < len; i++) {
              unsigned char c = (unsigned char)s[i];
              if (!isalnum(c) && c != '_' && c != '-' && c != '.')
                  return 0;      /* le '/' n'est pas dans la liste */
          }
          return 1;
      }

      /* c'est le programme qui met le dossier, pas l'utilisateur */
      static int build_backup_path(const char *name, char *path,
                                   size_t size)
      {
          if (!valid_filename(name)) { ...; return -1; }
          n = snprintf(path, size, "%s/%s", BACKUP_DIR, name);
          ...
      }

  Modifications effectuees :
      1. Je n'autorise que les lettres, les chiffres, '.', '_' et '-'. Le
         caractere '/' n'etant pas autorise, on ne peut pas ecrire de
         chemin.
      2. Je refuse aussi ".." et les noms qui commencent par '.'.
      3. Le dossier (backups/) est ajoute par le programme.
      4. Le fichier de backup ne contient plus le mot de passe, seulement
         le nom, le solde et la date.
      5. J'utilise les memes verifications pour la lecture et pour
         l'ecriture.

  NON TRAITE : le menu 6 (restaurer) reste accessible sans etre connecte
  (vulnerabilite 23). Le path traversal est bloque, mais n'importe qui
  peut lire un fichier du dossier backups/ sans compte.

JUSTIFICATION DE SECURITE

  J'ai choisi de faire une liste de ce qui est AUTORISE plutot qu'une
  liste de ce qui est interdit. Si on essaie d'interdire "../", il reste
  plein d'autres facons de contourner. En n'autorisant que les lettres,
  chiffres, '.', '_' et '-', le caractere '/' devient impossible a
  ecrire, donc on ne peut pas sortir du dossier.

  Et comme le fichier ne contient plus de mot de passe, meme s'il etait
  lu par quelqu'un d'autre il n'y aurait rien d'interessant dedans.

TEST

      make test-attacks    (Tests 4, 5, 6 et 7)

  Resultat :
      Test 4 - Nom du fichier de backup: ../../../../etc/passwd
               Nom de fichier refuse : lettres, chiffres, '.', '_' et
               '-' uniquement (32 caracteres max, pas de chemin)

      Test 5 - Nom du fichier de backup: admin_backup.txt
               Backup cree : backups/admin_backup.txt

      Test 7 - username=admin / admin=1 / balance=10000 / date=...
               (plus de mot de passe dedans)


------------------------------------------------------------------------
CORRECTION 7 : Mot de passe cache (backdoor) et mot de passe admin en dur
------------------------------------------------------------------------

Vulnerabilites concernees : 32, 37

VULNERABILITE ORIGINALE

  Fonctions : change_password(), main()
  Lignes    : 227, 310-311

  Description :

  Dans change_password(), il y a un deuxieme mot de passe accepte :
  "master_reset_2024". Il marche pour n'importe quel compte.

  Et dans main(), le compte admin est cree avec le mot de passe
  "admin123" ecrit directement dans le code.

  Code vulnerable :

      /* vulnerable.c:226-227 */
      if(strcmp(users[user_id].password, old_pass) == 0 ||
         strcmp(old_pass, "master_reset_2024") == 0) {   /* backdoor */

      /* vulnerable.c:310-311 */
      strcpy(users[0].username, "admin");
      strcpy(users[0].password, "admin123");             /* en dur */

ATTAQUE POSSIBLE

  Les deux chaines sont visibles dans le programme compile, il suffit de
  faire :
      strings vulnerable | grep master
      strings vulnerable | grep admin123

  Avec "master_reset_2024" on change le mot de passe de n'importe quel
  compte sans connaitre l'ancien.

  Test reel (exploit 4) :

      Ancien mot de passe: master_reset_2024
      Nouveau mot de passe: pwned
      Mot de passe change
      Username: admin / Password: pwned
      Connecte en tant que admin

  Impact :
      - Elevation de privileges
      - Prise de controle de n'importe quel compte

CORRECTION IMPLEMENTEE

      /* plus qu'une seule condition */
      if (hash_password(old_pass, users[user_id].salt, hash) != 0 ||
          memcmp(hash, users[user_id].hash, HASH_LEN) != 0) {
          printf("Ancien mot de passe incorrect\n");
          ...
          return;
      }

      /* le mot de passe admin est tire au hasard au demarrage */
      static int bootstrap_admin(void)
      {
          char password[17];
          ...
          if (random_password(password, sizeof password) != 0)
              return -1;

          if (create_user("admin", password, 1, 10000) < 0) { ... }

          printf("Compte admin initialise.\n");
          printf("Mot de passe temporaire (affiche une seule fois) : %s\n\n",
                 password);
          memset(password, 0, sizeof password);
          return 0;
      }

  Modifications effectuees :
      1. La backdoor est supprimee : il n'y a plus qu'une seule
         condition, la verification du hash.
      2. Le mot de passe admin est tire au hasard a chaque demarrage avec
         RAND_bytes() d'OpenSSL, et affiche une seule fois.
      3. Le jeton ADMIN_TOKEN ecrit en dur est remplace par un jeton
         aleatoire.

JUSTIFICATION DE SECURITE

  Il n'y a plus qu'une seule facon de changer un mot de passe : connaitre
  l'ancien. Comme il n'y a plus de deuxieme condition, il n'y a plus de
  mot de passe magique a trouver.

  Pour le compte admin, comme le mot de passe est tire au hasard a chaque
  lancement, il n'est plus dans le programme compile et il est different
  a chaque fois.

TEST

      make test-attacks                    (Test 10)
      strings secure | grep -i admin123    (ne renvoie rien)

  Resultat :
      Ancien mot de passe: master_reset_2024
      Ancien mot de passe incorrect


------------------------------------------------------------------------
CORRECTION 8 : Droits admin donnes a l'utilisateur
------------------------------------------------------------------------

Vulnerabilites concernees : 4, 28, 29

VULNERABILITE ORIGINALE

  Fonctions : register_user(), clone_user(), list_users()
  Lignes    : 69-74, 199-202, 212

  Description :

  A l'inscription, le programme DEMANDE a l'utilisateur s'il veut etre
  admin, et il le croit. C'est la faille la plus simple du programme.

  Dans clone_user(), le clone recupere le mot de passe ET les droits
  admin du compte d'origine.

  Et list_users() affiche a tout le monde les soldes et qui est admin.

  Code vulnerable :

      /* vulnerable.c:69-74 */
      printf("Droits admin (1=oui, 0=non): ");
      scanf("%d", &admin);
      ...
      users[user_count].admin_flag = admin;   /* on le croit sur parole */

      /* vulnerable.c:200-201 */
      strcpy(users[user_count].password, users[source_id].password);
      users[user_count].admin_flag = users[source_id].admin_flag;

ATTAQUE POSSIBLE

  Test reel (exploit 1) :

      Choix: 1  -> Username: pirate / Droits admin: 1
      Choix: 2  -> Connecte en tant que pirate
      Choix: 7  -> Commande: id; cat /etc/passwd   (acces admin obtenu)

  Test reel (exploit 6, le clone) :

      Choix: 8  -> Nom du clone: backdoor
      Choix: 9  -> 2. backdoor (Balance: 10000 EUR, Admin: 1)
      Choix: 2  -> Username: backdoor / Password: admin123
                   Connecte en tant que backdoor

  Impact :
      - Elevation de privileges
      - Execution de code arbitraire (via la commande systeme reservee
        aux admins)

CORRECTION IMPLEMENTEE

      /* on ne demande plus, on met 0 */
      rc = create_user(username, password, 0, DEFAULT_BALANCE);

      /* le clone ne recupere que le solde */
      rc = create_user(target, password, 0, users[src].balance);

      /* le clonage est reserve aux admins */
      case 8:
          if (session_admin())
              clone_user();
          else
              printf("Acces refuse\n");
          break;

  Modifications effectuees :
      1. La question "Droits admin ?" est supprimee. On passe 0 en dur.
      2. Le seul compte admin est celui cree au demarrage.
      3. Le clone ne recupere que le solde, et on demande un nouveau mot
         de passe pour lui.
      4. Le clonage demande d'etre admin.

  NON TRAITE : list_users() affiche toujours les soldes et les droits a
  tout le monde (vulnerabilite 30), et la confirmation du mot de passe
  est demandee mais toujours pas comparee (vulnerabilite 9).

JUSTIFICATION DE SECURITE

  La regle, c'est que ce n'est pas a l'utilisateur de decider ses propres
  droits. C'est le programme qui decide, a partir de ce qu'il sait.

  Comme on passe 0 en dur dans le code au moment de l'inscription, il n'y
  a plus aucune valeur que l'utilisateur peut taper pour devenir admin.

  Pour le clone, je ne recopie que ce qui est necessaire (le solde) et
  pas les secrets ni les droits.

TEST

      make test-attacks    (Tests 12, 19, 20, 21)

  Resultat :
      Test 19 - Clonage demande par un non-admin        -> Acces refuse
      Test 20 - Statistiques demandees par un non-admin -> Acces refuse
      Test 21 - Liste vue par un non-admin (NON CORRIGE) :
                0. admin (Balance: 10040, Admin: 1)
                1. victime (Balance: 60, Admin: 0)


------------------------------------------------------------------------
CORRECTION 9 : Transfert d'argent (montant negatif, solde non verifie)
------------------------------------------------------------------------

Vulnerabilites concernees : 16, 17

VULNERABILITE ORIGINALE

  Fonction : transfer_money()
  Lignes   : 119-127

  Description :

  Le montant est lu avec scanf("%d") et utilise directement, sans
  verifier qu'il est positif ni qu'on a assez d'argent sur le compte.

  Code vulnerable :

      /* vulnerable.c:119-125 */
      printf("Montant: ");
      scanf("%d", &amount);
      ...
      users[from_user].balance -= amount;
      users[i].balance += amount;

ATTAQUE POSSIBLE

  Si on met un montant NEGATIF, le transfert se fait dans l'autre sens :
  "envoyer -9000 EUR a admin" enleve -9000 de mon solde (donc me donne
  9000) et enleve 9000 a admin.

  Test reel (exploit 5) :

      0. admin (Balance: 10000 EUR)
      1. pirate (Balance: 100 EUR)

      Vers quel utilisateur: admin
      Montant: -9000
      Transfert effectue!

      0. admin (Balance: 1000 EUR)     <- 9000 en moins
      1. pirate (Balance: 9100 EUR)    <- 9000 en plus

  Impact :
      - Vol d'argent

CORRECTION IMPLEMENTEE

      if (to_user == from_user) {
          printf("Transfert vers soi-meme refuse\n");
          return;
      }

      if (read_long("Montant: ", 1, MAX_TRANSFER, &amount) != 0) {
          printf("Montant invalide (entier entre 1 et %ld)\n",
                 MAX_TRANSFER);
          return;
      }
      if (amount > users[from_user].balance) {
          printf("Solde insuffisant (solde actuel : %ld)\n",
                 users[from_user].balance);
          return;
      }

      users[from_user].balance -= amount;
      users[to_user].balance   += amount;

  Modifications effectuees :
      1. Le montant est lu avec read_long() qui impose un minimum de 1,
         donc les valeurs negatives et zero sont refusees des la lecture.
      2. Je verifie qu'il y a assez d'argent avant de faire l'operation.
      3. Je refuse le transfert vers soi-meme.
      4. Toutes les verifications sont faites AVANT de modifier les
         soldes.

JUSTIFICATION DE SECURITE

  En mettant le minimum a 1 dans read_long(), un montant negatif n'entre
  meme pas dans le programme. C'est plus sur que de le verifier apres
  coup.

  Et comme je fais toutes les verifications avant de toucher aux soldes,
  il n'y a pas de moment ou l'argent serait enleve d'un compte sans etre
  ajoute a l'autre.

TEST

      make test-attacks    (Tests 14 a 17)

  Resultat :
      Test 14 - Montant: -5000   -> Montant invalide (entier entre 1 et
                                    1000000)
      Test 15 - Montant: 999999  -> Solde insuffisant (solde actuel: 100)
      Test 16 - Vers: victime    -> Transfert vers soi-meme refuse
      Test 17 - Montant: 40      -> Transfert effectue! Nouveau solde: 60


------------------------------------------------------------------------
CORRECTION 10 : Gestion de la memoire et lecture des nombres
------------------------------------------------------------------------

Vulnerabilites concernees : 7, 38, 39, 41

VULNERABILITE ORIGINALE

  Fonctions : register_user(), compute_stats(), main()
  Lignes    : 77, 247, 314, 320

  Description :

  - Les deux malloc() ne verifient pas si l'allocation a marche. Si elle
    echoue, malloc renvoie NULL et sprintf ecrit a l'adresse 0 :
    plantage.
  - Il n'y a aucun free() dans tout le programme : la memoire n'est
    jamais rendue.
  - scanf("%d", &choice) ne verifie pas son resultat. Si on tape une
    lettre, scanf ne lit rien et ne consomme pas le caractere : la boucle
    recommence sur le meme caractere a l'infini.

  Code vulnerable :

      /* vulnerable.c:77-78 */
      users[user_count].token = malloc(32);   /* pas de verification */
      sprintf(users[user_count].token, ...);

      /* vulnerable.c:320 */
      scanf("%d", &choice);                   /* resultat ignore */

ATTAQUE POSSIBLE

  echo "AAAA" | ./vulnerable  ->  le programme tourne en boucle infinie
  et prend 100 % du processeur. C'est un deni de service avec 4
  caracteres.

  Pour la memoire, valgrind confirme la fuite :
      in use at exit: 64 bytes in 2 blocks

  Impact :
      - Deni de service (boucle infinie)
      - Fuite memoire

CORRECTION IMPLEMENTEE

      /* lecture des nombres avec strtol */
      static int read_long(const char *prompt, long min, long max,
                           long *out)
      {
          char buf[32];
          char *end;
          long value;

          if (read_line(prompt, buf, sizeof buf) != 0)
              return -1;

          errno = 0;
          value = strtol(buf, &end, 10);
          if (end == buf)   return -1;    /* pas un nombre */
          if (*end != '\0') return -1;    /* du texte apres le nombre */
          if (errno == ERANGE || value < min || value > max)
              return -1;

          *out = value;
          return 0;
      }

      /* on libere tout a la fin */
      static void cleanup(void)
      {
          int i;

          for (i = 0; i < user_count; i++) {
              if (users[i].token) {
                  free(users[i].token);
                  users[i].token = NULL;
              }
          }
          ...
      }

  Modifications effectuees :
      1. Tous les malloc() sont verifies, et l'erreur est remontee a
         l'appelant.
      2. J'ai ecrit une fonction cleanup() qui libere tous les jetons,
         appelee quand on quitte le programme.
      3. scanf("%d") remplace par read_long() qui utilise strtol() et
         verifie que c'est bien un nombre, dans les bonnes bornes.
      4. Les pointeurs sont mis a NULL apres free().

  NON TRAITE : la division par zero de compute_stats() (vulnerabilite 35)
  n'est pas corrigee. En pratique elle n'est pas declenchable puisque le
  compte admin est toujours cree au demarrage, mais le test manque.

JUSTIFICATION DE SECURITE

  strtol() est mieux que scanf("%d") parce qu'il dit ou il s'est arrete,
  donc on peut savoir si l'utilisateur a tape autre chose qu'un nombre.
  On peut aussi detecter les nombres trop grands avec errno.

  Pour la memoire, valgrind confirme qu'il n'y a plus de fuite : autant
  de free() que de malloc().

TEST

      make test-attacks    (Tests 25 et 26)
      make valgrind

  Resultat :
      Test 25 - Choix: AAAA                 -> Choix invalide
      Test 26 - Choix: 99999999999999999999 -> Choix invalide

      ==67810== All heap blocks were freed -- no leaks are possible


========================================================================
3. TESTS DE VALIDATION
========================================================================

3.1 Compilation
---------------

Commande utilisee :

    gcc -Wall -Wextra -O2 -g -fstack-protector-all -D_FORTIFY_SOURCE=2 \
        -o secure secure.c -lcrypto

Resultat : aucune sortie

Nombre de warnings : 0
Nombre d'erreurs   : 0

Pour comparaison, vulnerable.c donne un avertissement a la compilation :

    vulnerable.c:105: warning: the `gets' function is dangerous and
    should not be used.

Options utilisees :

    -Wall -Wextra            affiche tous les avertissements
    -fstack-protector-all    ajoute un canari pour detecter les
                             debordements de pile
    -D_FORTIFY_SOURCE=2      verifie les tailles sur les fonctions de
                             chaines


3.2 Tests fonctionnels
----------------------

Fonctionnalite          Test effectue                              Resultat
----------------------  -----------------------------------------  --------
Creation utilisateur    Nom de 500 caracteres                      OK
Creation utilisateur    Nom normal                                 OK
Connexion               Mauvais mot de passe                       OK
Connexion               Bon mot de passe                           OK
Transfert               Montant negatif                            OK
Transfert               Montant plus grand que le solde            OK
Transfert               Transfert normal                           OK
Backup                  Nom avec ../                               OK
Backup                  Nom normal                                 OK
Restauration            Chemin /etc/passwd                         OK
Commande systeme        Injection avec ;                           OK
Commande systeme        Choix normal                               OK
Changer mot de passe    Backdoor master_reset_2024                 OK
Controle d'acces        Fonctions admin depuis un compte normal    OK
Menu                    Lettre au lieu d'un chiffre                OK
Liste utilisateurs      Soldes visibles par un non-admin           NON CORRIGE
Connexion               4 essais errones d'affilee                 NON CORRIGE
Restauration            Menu 6 sans etre connecte                  NON CORRIGE
Creation utilisateur    Confirmation differente du mot de passe    NON CORRIGE

28 scenarios executes (make test-attacks) : 24 protections confirmees,
4 qui documentent des vulnerabilites que je n'ai pas corrigees.


3.3 Analyse memoire (Valgrind)
------------------------------

Commande :

    valgrind --leak-check=full --show-leak-kinds=all ./secure

Resultat :

    ==67810== HEAP SUMMARY:
    ==67810==     in use at exit: 0 bytes in 0 blocks
    ==67810==   total heap usage: 7,342 allocs, 7,342 frees,
                661,103 bytes allocated
    ==67810==
    ==67810== All heap blocks were freed -- no leaks are possible
    ==67810== ERROR SUMMARY: 0 errors from 0 contexts

Fuites detectees   : 0 bytes
Blocs non liberes  : 0

Sur la version vulnerable, valgrind trouve la fuite et le debordement :

    ==68350==     in use at exit: 64 bytes in 2 blocks
    ==68530== Invalid write of size 2
    ==68530==    by 0x1095F4: register_user (vulnerable.c:78)


3.4 Tests de securite
---------------------

Test 1 - Buffer Overflow
    Entree testee    : username de 500 caracteres 'A'
    Resultat attendu : refuse, pas de plantage
    Resultat obtenu  : "Nom invalide : 3 a 15 caracteres
                       alphanumeriques..."
    -> OK

Test 2 - Format String
    Entree testee    : %s%s%s%s%n %x %x %x
    Resultat attendu : affiche tel quel
    Resultat obtenu  : "Note: %s%s%s%s%n %x %x %x"
    -> OK

Test 3 - Command Injection
    Entree testee    : 1; cat /etc/shadow
    Resultat attendu : refuse
    Resultat obtenu  : "Choix invalide"
    -> OK

Test 4 - Path Traversal
    Entree testee    : ../../../../etc/passwd
    Resultat attendu : refuse
    Resultat obtenu  : "Nom de fichier refuse : ... pas de chemin"
    -> OK

Test 5 - Backdoor
    Entree testee    : master_reset_2024
    Resultat attendu : refuse
    Resultat obtenu  : "Ancien mot de passe incorrect"
    -> OK


3.5 Pour relancer les tests
---------------------------

    make secure          compile la version securisee
    make test-attacks    les 28 scenarios sur ./secure
    make exploits        montre les failles sur ./vulnerable
    make valgrind        analyse memoire


========================================================================
4. CONCLUSION
========================================================================

4.1 Resume des corrections
--------------------------

Statistiques :
    Vulnerabilites identifiees         : 41
    Vulnerabilites corrigees           : 36
    dont CRITIQUES                     : 24 sur 24
    dont HAUTES                        : 11 sur 13
    dont MOYENNES                      : 1 sur 4
    Le fichier passe de 402 lignes a 1061 lignes.

Principaux changements :

    1. Toutes les fonctions dangereuses sont remplacees : plus de gets(),
       plus de scanf("%s"), plus de strcpy(), plus de sprintf(), plus de
       system().
    2. Les mots de passe ne sont plus stockes en clair : on garde un sel
       et un SHA-256.
    3. Toutes les entrees sont verifiees avant d'etre utilisees.
    4. La plupart des fonctions sensibles demandent d'etre connecte, et
       certaines d'etre admin (mais pas la restauration, voir 4.3).
    5. La backdoor et le mot de passe admin en dur sont supprimes.
    6. La memoire est liberee a la fin (0 fuite avec valgrind).


4.2 Difficultes rencontrees
---------------------------

Probleme 1 : remplacer scanf par fgets a casse le menu

    Quand j'ai remplace scanf("%s") par fgets(), le menu s'est mis a se
    decaler des qu'on tape une entree trop longue. J'ai mis un moment a
    comprendre : les caracteres en trop restent dans le tampon d'entree
    et sont lus comme reponse a la question suivante.

    J'ai resolu ca en ajoutant dans read_line() une boucle qui vide la
    fin de la ligne avec getchar() quand la saisie a ete coupee.

Probleme 2 : le debordement de buffer ne faisait pas planter le programme

    J'ai d'abord teste le debordement avec un nom de 300 caracteres, et
    le programme ne plantait pas du tout, il se terminait normalement. Je
    croyais que je m'etais trompe et que la faille n'existait pas.

    En fait username[100], password[100] et confirm[100] sont l'un apres
    l'autre en memoire, donc 300 caracteres debordent d'un buffer sur
    l'autre sans aller plus loin. Il faut environ 400 caracteres pour que
    ca plante vraiment (*** stack smashing detected ***).

    Et j'ai remarque qu'avec 300 caracteres le mot de passe s'affichait
    dans la liste des utilisateurs, parce que le '\0' du champ username
    avait ete ecrase.

Probleme 3 : le debordement du malloc(32) ne se voit pas

    Le sprintf() ligne 78 ecrit plus que 32 octets dans le bloc alloue,
    mais le programme ne plante jamais et rien ne s'affiche.

    Je n'arrivais pas a le prouver jusqu'a ce que je le lance sous
    valgrind, qui affiche bien "Invalid write of size 2" a la ligne 78.


4.3 Limites de mon analyse
--------------------------

D'abord, 5 vulnerabilites que j'ai bien identifiees mais pas corrigees,
faute de temps. Je les ai laissees dans le tableau avec la mention "Non"
plutot que de faire croire qu'elles etaient traitees :

    - No 9  : la confirmation du mot de passe est demandee a l'inscription
              mais jamais comparee. On peut donc creer un compte avec deux
              saisies differentes. Ce n'est pas exploitable par un
              attaquant, c'est surtout un piege pour l'utilisateur.

    - No 12 : aucune limite au nombre de tentatives de connexion. Une
              attaque par dictionnaire n'est ralentie par rien. C'est la
              plus genante des cinq.

    - No 23 : le menu 6 (restaurer) reste accessible sans etre connecte.
              Le path traversal est bloque, donc on ne peut lire que dans
              backups/, mais il faudrait quand meme un compte.

    - No 30 : list_users() affiche les soldes et les droits admin a tout
              le monde. Ca donne a un attaquant la carte des comptes a
              privileges avant meme de choisir sa cible.

    - No 35 : la division par zero de compute_stats() n'est pas testee.
              Elle n'est pas declenchable aujourd'hui puisque le compte
              admin est toujours cree au demarrage, mais le jour ou on
              ajoute une suppression de compte, elle le devient.

Ensuite, ce que je n'ai pas traite ni identifie a temps :

    - Le tableau sessions[] ne sert a rien. En relisant le code a la fin,
      j'ai vu que session_count n'est jamais augmente, ni dans
      vulnerable.c ni dans ma version. Donc tout le mecanisme de sessions
      est du code mort et cleanup_sessions() ne fait jamais rien. Je m'en
      suis rendu compte trop tard pour le refaire proprement.

    - Les donnees ne sont pas sauvegardees. Quand on quitte le programme,
      les comptes sont perdus. Il faudrait un fichier, mais alors il
      faudrait aussi le proteger.

    - Le mot de passe s'affiche quand on le tape. Il faudrait desactiver
      l'echo du terminal, je n'ai pas eu le temps de regarder comment
      faire.

    - Le fichier security.log n'est pas protege. N'importe qui peut
      l'effacer ou le modifier.

    - Rien n'empeche de creer plein de comptes jusqu'a remplir les 20
      places et empecher les autres de s'inscrire.


4.4 Ameliorations possibles
---------------------------

Securite :

    [fait] Salage des mots de passe
    [fait] Logs de securite
    [a faire] Limiter le nombre de tentatives de connexion. C'est le
              bonus que je regrette le plus de ne pas avoir fait : sans
              lui, le SHA-256 salé ne sert pas a grand-chose face a une
              attaque en ligne.
    [a faire] Faire expirer les sessions apres un delai d'inactivite.

    [a faire] Utiliser bcrypt ou Argon2 a la place de SHA-256. SHA-256
              est tres rapide a calculer, donc si quelqu'un recupere les
              hash il peut tester beaucoup de mots de passe par seconde.
              bcrypt est fait expres pour etre lent. J'ai utilise SHA-256
              parce que c'est ce qui est demande dans les consignes.

    [a faire] Compter les echecs de connexion par compte et pas
              globalement : pour l'instant 3 erreurs bloquent tout le
              monde.

Fonctionnalite :

    [a faire] Sauvegarder les comptes dans un fichier chiffre
    [a faire] Masquer le mot de passe a la saisie


4.5 Apprentissages cles
-----------------------

Ce que j'ai appris :

    1. Un programme qui marche n'est pas un programme sur. Le debordement
       de 300 caracteres ne faisait rien planter, et pourtant il
       affichait le mot de passe d'un autre compte. C'est le truc qui m'a
       le plus marque.

    2. Remplacer une fonction dangereuse ne suffit pas. En passant de
       gets() a fgets(), j'ai cree un nouveau bug (le menu qui se
       decale). Il faut aussi penser a ce qui reste dans le tampon
       d'entree.

    3. Il vaut mieux dire ce qui est autorise que ce qui est interdit.
       Pour les noms de fichiers, interdire "../" ne suffit pas ;
       n'autoriser que les lettres et les chiffres rend le probleme
       impossible.

    4. Ce n'est pas a l'utilisateur de decider ses droits. La faille la
       plus grave du programme n'etait pas un debordement complique,
       c'etait juste la question "Droits admin (1=oui, 0=non)".

Competences developpees :

    - Identification de vulnerabilites
    - Utilisation de fonctions securisees
    - Validation d'entrees
    - Gestion memoire rigoureuse
    - Cryptographie appliquee


4.6 Auto-evaluation
-------------------

Critere         Note      Justification
--------------  --------  ------------------------------------------------
Analyse         4 / 6     J'ai trouve 41 vulnerabilites, ce qui depasse les
                          25 demandees, et je les ai toutes testees pour
                          verifier qu'elles marchent. Mais je suis passe a
                          cote du fait que le tableau sessions[] n'est
                          jamais utilise, et je ne l'ai vu qu'a la fin.

Corrections     6 / 10    Le programme compile sans warning et valgrind ne
                          trouve aucune fuite. Tous les debordements de
                          buffer, les injections et les problemes de
                          cryptographie sont traites. Par contre je n'ai
                          corrige que 36 des 41 vulnerabilites : il me
                          reste 5 problemes de logique metier et de
                          controle d'acces, dont l'absence de limitation
                          des tentatives de connexion. Et j'ai utilise
                          SHA-256 alors que bcrypt serait mieux adapte.

Documentation   2 / 4     J'ai documente les 10 corrections principales
                          avec les 4 parties demandees, mais j'ai regroupe
                          plusieurs vulnerabilites par correction au lieu
                          de toutes les detailler une par une.

TOTAL           12 / 20


========================================================================
ANNEXES
========================================================================

Annexe A : Checklist de verification finale
-------------------------------------------

    [x] Tous les gets() remplaces par fgets() (dans read_line())
    [x] Tous les scanf("%s") remplaces
    [x] Tous les strcpy() remplaces par snprintf()
    [x] Pas de strcat() dans le programme
    [x] Tous les sprintf() remplaces par snprintf()
    [x] Cryptographie : SHA-256 avec un sel
    [x] Pas de mot de passe en clair
    [x] Pas de backdoor
    [x] Indices de tableaux verifies
    [x] Tous les malloc() ont un free()
    [x] 0 fuite memoire (valgrind)
    [x] 0 warning de compilation
    [x] Noms de fichiers verifies
    [x] Protection contre l'injection de commande


Annexe B : References utilisees
-------------------------------

    1. Le cours et les TP precedents
    2. man gets, man fgets, man snprintf, man strtol, man execv
    3. La documentation OpenSSL pour SHA256() et RAND_bytes()
    4. OWASP Top 10 (2021) pour la classification des failles
    5. La page de manuel de Valgrind pour l'analyse memoire


========================================================================
                            FIN DU RAPPORT
========================================================================
