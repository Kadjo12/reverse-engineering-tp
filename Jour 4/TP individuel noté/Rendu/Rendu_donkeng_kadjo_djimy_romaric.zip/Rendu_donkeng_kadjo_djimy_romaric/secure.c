/*
 * TP FINAL NOTE - Version SECURISEE
 * Systeme de gestion de comptes utilisateurs avec authentification
 *
 * Cette version corrige les 9 vulnerabilites documentees dans RAPPORT.md,
 * ainsi que les exigences obligatoires des consignes independantes du
 * tableau (remplacement de TOUTES les fonctions dangereuses gets/scanf/
 * strcpy/sprintf, validations username/montant/fichier, gestion memoire
 * avec verification des malloc() et liberation complete via cleanup()).
 *
 * Ne sont PAS implementees ici les fonctionnalites listees comme BONUS
 * dans les consignes (salage des mots de passe, limitation des tentatives
 * de connexion, logs de securite, protection timing-attack) : elles ne
 * font pas partie des 9 vulnerabilites documentees dans ce rendu.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <openssl/sha.h>

#define MAX_USERS 20
#define MAX_SESSIONS 10

#define USERNAME_LEN 16                        /* 15 caracteres utiles + '\0' */
#define HASH_HEX_LEN (SHA256_DIGEST_LENGTH * 2 + 1)  /* hash SHA-256 en hexa  */
#define TOKEN_LEN 40

typedef struct {
    char username[USERNAME_LEN];
    char password_hash[HASH_HEX_LEN];
    int admin_flag;
    int balance;
    char *token;
} User;

typedef struct {
    int user_id;
    char session_data[64];
    time_t created;
} Session;

User users[MAX_USERS];
Session sessions[MAX_SESSIONS];
int user_count = 0;
int session_count = 0;

/* =========================================================================
 *                          FONCTIONS UTILITAIRES
 * ========================================================================= */

/* [Correction #2] Remplace gets()/scanf("%s") : lecture bornee, retire le
 * '\n' final et vide le reste du flux si la ligne est plus longue que le
 * buffer fourni. */
int read_line(char *buf, size_t size) {
    if (fgets(buf, (int)size, stdin) == NULL) {
        buf[0] = '\0';
        return 0;
    }
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        int c;
        while ((c = getchar()) != '\n' && c != EOF) { }
    }
    return 1;
}

/* [Correction #2] Remplace scanf("%d", ...) : lecture bornee puis
 * conversion stricte, rejette toute entree non numerique. */
int read_int(int *out) {
    char buf[32];
    if (!read_line(buf, sizeof(buf))) return 0;
    if (buf[0] == '\0') return 0;
    char *endptr;
    long val = strtol(buf, &endptr, 10);
    if (endptr == buf || *endptr != '\0') return 0;
    *out = (int)val;
    return 1;
}

/* Validation des noms d'utilisateur (requise par les consignes, Tache 2.2). */
int validate_username(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len >= USERNAME_LEN) return 0;
    for (size_t i = 0; i < len; i++) {
        if (!isalnum((unsigned char)s[i]) && s[i] != '_') return 0;
    }
    return 1;
}

/* [Correction #8] Validation du montant transfere. */
int validate_amount(int amount, int available_balance) {
    if (amount <= 0) return 0;
    if (amount > available_balance) return 0;
    return 1;
}

/* [Correction #6] Interdit tout chemin absolu, toute remontee '..' et tout
 * separateur '/', puis n'autorise qu'un jeu de caracteres restreint. */
int validate_filename(const char *s) {
    size_t len = strlen(s);
    if (len == 0 || len >= 100) return 0;
    if (s[0] == '/' || s[0] == '.') return 0;
    if (strstr(s, "..") != NULL) return 0;
    if (strchr(s, '/') != NULL) return 0;
    for (size_t i = 0; i < len; i++) {
        char c = s[i];
        if (!isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.') return 0;
    }
    return 1;
}

void bytes_to_hex(const unsigned char *bytes, size_t len, char *out) {
    static const char hexchars[] = "0123456789abcdef";
    for (size_t i = 0; i < len; i++) {
        out[i * 2]     = hexchars[(bytes[i] >> 4) & 0xF];
        out[i * 2 + 1] = hexchars[bytes[i] & 0xF];
    }
    out[len * 2] = '\0';
}

/* [Correction #1] Remplace le hash "maison" (djb2, jamais appele dans
 * vulnerable.c) par un vrai hash cryptographique SHA-256 via OpenSSL. Le
 * mot de passe en clair n'est plus jamais stocke, seul le hash l'est. */
void hash_password(const char *password, char *hash_hex_out) {
    unsigned char digest[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char *)password, strlen(password), digest);
    bytes_to_hex(digest, SHA256_DIGEST_LENGTH, hash_hex_out);
}

/* =========================================================================
 *                          FONCTIONS METIER
 * ========================================================================= */

void register_user() {
    if (user_count >= MAX_USERS) {
        printf("Maximum d'utilisateurs atteint\n");
        return;
    }

    char username[USERNAME_LEN];
    char password[128];
    char confirm[128];

    printf("=== ENREGISTREMENT ===\n");

    printf("Username (alphanumerique + '_', max %d caracteres): ", USERNAME_LEN - 1);
    if (!read_line(username, sizeof(username))) return;
    if (!validate_username(username)) {
        printf("Nom d'utilisateur invalide.\n");
        return;
    }

    printf("Password: ");
    if (!read_line(password, sizeof(password))) return;

    printf("Confirmer password: ");
    if (!read_line(confirm, sizeof(confirm))) return;

    /* [Correction #3] Les droits admin ne sont plus jamais demandes ni
     * accordes lors de l'auto-enregistrement (faille d'escalade de
     * privileges corrigee). */
    size_t ulen = strlen(username);
    memcpy(users[user_count].username, username, ulen);
    users[user_count].username[ulen] = '\0';

    hash_password(password, users[user_count].password_hash);
    memset(password, 0, sizeof(password));
    memset(confirm, 0, sizeof(confirm));

    users[user_count].admin_flag = 0;
    users[user_count].balance = 100;

    users[user_count].token = malloc(TOKEN_LEN);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation memoire\n");
        return;
    }
    snprintf(users[user_count].token, TOKEN_LEN, "TOK_%d_%s", user_count, users[user_count].username);

    user_count++;
    printf("Utilisateur enregistre!\n");
}

int login_user(const char *username, const char *password) {
    char candidate_hash[HASH_HEX_LEN];
    hash_password(password, candidate_hash);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 &&
            strcmp(users[i].password_hash, candidate_hash) == 0) {
            return i;
        }
    }
    return -1;
}

void show_profile(int user_id) {
    if (user_id < 0 || user_id >= user_count) {
        printf("Utilisateur invalide\n");
        return;
    }
    char format[80];

    printf("\n=== PROFIL ===\n");
    printf("User: %s\n", users[user_id].username);
    printf("Balance: %d\xE2\x82\xAC\n", users[user_id].balance);
    printf("Admin: %s\n", users[user_id].admin_flag ? "OUI" : "NON");

    printf("Format d'affichage personnalise (affiche tel quel): ");
    if (read_line(format, sizeof(format))) {
        /* [Correction #4] %s est TOUJOURS le format, jamais l'entree
         * utilisateur (qui ne devient qu'un argument affiche). */
        printf("%s\n", format);
    }
}

void transfer_money(int from_user) {
    char to_username[USERNAME_LEN];
    int amount;

    if (from_user < 0 || from_user >= user_count) return;

    printf("=== TRANSFERT ===\n");
    printf("Vers quel utilisateur: ");
    if (!read_line(to_username, sizeof(to_username))) return;

    printf("Montant: ");
    if (!read_int(&amount)) {
        printf("Montant invalide.\n");
        return;
    }

    /* [Correction #8] Rejet des montants nuls, negatifs, ou superieurs au
     * solde disponible. */
    if (!validate_amount(amount, users[from_user].balance)) {
        printf("Montant invalide ou fonds insuffisants.\n");
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, to_username) == 0) {
            users[from_user].balance -= amount;
            users[i].balance += amount;
            printf("Transfert effectue!\n");
            return;
        }
    }
    printf("Utilisateur destinataire introuvable\n");
}

void backup_user_data(int user_id) {
    char filename[100];
    FILE *fp;

    if (user_id < 0 || user_id >= user_count) return;

    printf("Nom du fichier de backup (nom simple, sans '/'): ");
    if (!read_line(filename, sizeof(filename))) return;
    /* [Correction #6] Empeche tout chemin en dehors du repertoire courant. */
    if (!validate_filename(filename)) {
        printf("Nom de fichier invalide (pas de '/', '..', ni chemin absolu).\n");
        return;
    }

    fp = fopen(filename, "w");
    if (fp) {
        fprintf(fp, "%s:%d:%d\n",
                users[user_id].username,
                users[user_id].admin_flag,
                users[user_id].balance);
        fclose(fp);
        printf("Backup cree\n");
    } else {
        printf("Impossible de creer le fichier de backup\n");
    }
}

void restore_user_data() {
    char filename[100];
    char buffer[256];
    FILE *fp;

    printf("Fichier a restaurer (nom simple, sans '/'): ");
    if (!read_line(filename, sizeof(filename))) return;
    /* [Correction #6] Empeche tout chemin en dehors du repertoire courant. */
    if (!validate_filename(filename)) {
        printf("Nom de fichier invalide.\n");
        return;
    }

    fp = fopen(filename, "r");
    if (!fp) {
        printf("Fichier introuvable\n");
        return;
    }

    printf("--- Contenu du fichier ---\n");
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

/* [Correction #5] Remplace system()/sprintf() par une liste blanche stricte
 * executee via fork()+execv() SANS shell : aucune chaine utilisateur
 * n'atteint jamais un interpreteur de commandes. */
void system_command() {
    const char *labels[] = {"Date/heure serveur", "Utilisateur courant", "Espace disque", "Uptime"};
    const char *paths[]  = {"/bin/date", "/usr/bin/whoami", "/bin/df", "/usr/bin/uptime"};
    char *const argv0[] = {(char *)"date", NULL};
    char *const argv1[] = {(char *)"whoami", NULL};
    char *const argv2[] = {(char *)"df", (char *)"-h", NULL};
    char *const argv3[] = {(char *)"uptime", NULL};
    char *const *argvs[] = {argv0, argv1, argv2, argv3};
    const int n = 4;

    printf("=== COMMANDES SYSTEME AUTORISEES ===\n");
    for (int i = 0; i < n; i++) {
        printf("%d. %s\n", i + 1, labels[i]);
    }
    printf("Choix (0 pour annuler): ");

    int choice;
    if (!read_int(&choice) || choice < 0 || choice > n) {
        printf("Choix invalide\n");
        return;
    }
    if (choice == 0) return;

    int idx = choice - 1;
    pid_t pid = fork();
    if (pid < 0) {
        printf("Erreur systeme\n");
        return;
    } else if (pid == 0) {
        execv(paths[idx], argvs[idx]);
        _exit(127);
    } else {
        int status;
        waitpid(pid, &status, 0);
    }
}

void clone_user(int source_id) {
    char target_username[USERNAME_LEN];

    if (source_id < 0 || source_id >= user_count) return;

    printf("Nom du clone: ");
    if (!read_line(target_username, sizeof(target_username))) return;
    if (!validate_username(target_username)) {
        printf("Nom d'utilisateur invalide.\n");
        return;
    }

    if (user_count >= MAX_USERS) {
        printf("Limite atteinte\n");
        return;
    }

    size_t tlen = strlen(target_username);
    memcpy(users[user_count].username, target_username, tlen);
    users[user_count].username[tlen] = '\0';
    memcpy(users[user_count].password_hash, users[source_id].password_hash, HASH_HEX_LEN);
    users[user_count].admin_flag = users[source_id].admin_flag;
    users[user_count].balance = users[source_id].balance;

    users[user_count].token = malloc(TOKEN_LEN);
    if (users[user_count].token == NULL) {
        printf("Erreur d'allocation memoire\n");
        return;
    }
    snprintf(users[user_count].token, TOKEN_LEN, "TOK_%d_%s", user_count, users[user_count].username);

    user_count++;
    printf("Clone cree\n");
}

void list_users() {
    printf("\n=== LISTE UTILISATEURS ===\n");
    for (int i = 0; i < user_count; i++) {
        printf("%d. %s (Balance: %d\xE2\x82\xAC, Admin: %d)\n",
               i, users[i].username, users[i].balance, users[i].admin_flag);
    }
}

void change_password(int user_id) {
    char old_pass[128];
    char new_pass[128];

    if (user_id < 0 || user_id >= user_count) return;

    printf("=== CHANGEMENT MOT DE PASSE ===\n");
    printf("Ancien mot de passe: ");
    if (!read_line(old_pass, sizeof(old_pass))) return;

    char candidate_hash[HASH_HEX_LEN];
    hash_password(old_pass, candidate_hash);
    memset(old_pass, 0, sizeof(old_pass));

    /* [Correction #7] La porte derobee "master_reset_2024" est
     * entierement supprimee : seule la comparaison au hash reel du
     * compte est acceptee. */
    if (strcmp(users[user_id].password_hash, candidate_hash) != 0) {
        printf("Ancien mot de passe incorrect\n");
        return;
    }

    printf("Nouveau mot de passe: ");
    if (!read_line(new_pass, sizeof(new_pass))) return;

    hash_password(new_pass, users[user_id].password_hash);
    memset(new_pass, 0, sizeof(new_pass));

    printf("Mot de passe change\n");
}

void compute_stats() {
    int total = 0;
    double avg;
    char buffer[120];

    for (int i = 0; i < user_count; i++) {
        total += users[i].balance;
    }

    avg = (double)total / user_count;

    snprintf(buffer, sizeof(buffer), "Total: %d\xE2\x82\xAC, Moyenne: %.2f\xE2\x82\xAC", total, avg);
    printf("%s\n", buffer);
}

void search_user() {
    char query[100];

    printf("Rechercher: ");
    if (!read_line(query, sizeof(query))) return;

    for (int i = 0; i < user_count; i++) {
        if (strstr(users[i].username, query)) {
            printf("Trouve: %s\n", users[i].username);
        }
    }
}

void cleanup_sessions() {
    time_t now = time(NULL);
    for (int i = 0; i < session_count; i++) {
        if (now - sessions[i].created > 3600) {
            printf("Session %d expiree\n", i);
        }
    }
}

/* Gestion memoire obligatoire (consignes, Tache 2.2) : libere tous les
 * tokens alloues dynamiquement. Enregistree via atexit() pour garantir
 * 0 fuite quel que soit le chemin de sortie du programme. */
void cleanup(void) {
    for (int i = 0; i < user_count; i++) {
        if (users[i].token) {
            free(users[i].token);
            users[i].token = NULL;
        }
    }
}

void display_menu() {
    printf("\n\xE2\x95\x94\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x97\n");
    printf("\xE2\x95\x91   SYSTEME DE GESTION BANCAIRE (SECURISE)    \xE2\x95\x91\n");
    printf("\xE2\x95\xA0\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\xA3\n");
    printf("\xE2\x95\x91 1. Creer compte                  \xE2\x95\x91\n");
    printf("\xE2\x95\x91 2. Se connecter                  \xE2\x95\x91\n");
    printf("\xE2\x95\x91 3. Voir profil                   \xE2\x95\x91\n");
    printf("\xE2\x95\x91 4. Transferer argent             \xE2\x95\x91\n");
    printf("\xE2\x95\x91 5. Backup donnees                \xE2\x95\x91\n");
    printf("\xE2\x95\x91 6. Restaurer donnees             \xE2\x95\x91\n");
    printf("\xE2\x95\x91 7. Commande systeme (admin)      \xE2\x95\x91\n");
    printf("\xE2\x95\x91 8. Cloner utilisateur            \xE2\x95\x91\n");
    printf("\xE2\x95\x91 9. Liste utilisateurs            \xE2\x95\x91\n");
    printf("\xE2\x95\x91 10. Changer mot de passe         \xE2\x95\x91\n");
    printf("\xE2\x95\x91 11. Statistiques                 \xE2\x95\x91\n");
    printf("\xE2\x95\x91 12. Rechercher utilisateur       \xE2\x95\x91\n");
    printf("\xE2\x95\x91 0. Quitter                       \xE2\x95\x91\n");
    printf("\xE2\x95\x9A\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x9D\n");
    printf("Choix: ");
}

int main() {
    atexit(cleanup);

    int choice;
    int logged_user = -1;
    char username[USERNAME_LEN], password[128];

    printf("\xE2\x95\x94\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x97\n");
    printf("\xE2\x95\x91  TP FINAL NOTE - VERSION SECURISEE                     \xE2\x95\x91\n");
    printf("\xE2\x95\x9A\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x9D\n\n");

    /* [Correction #1 + #7] Compte admin par defaut : mot de passe hashe
     * (SHA-256), plus jamais stocke en clair. La porte derobee est
     * supprimee (voir change_password()) et l'identifiant faible
     * "admin123" de la version vulnerable est remplace. */
    strncpy(users[0].username, "admin", USERNAME_LEN - 1);
    users[0].username[USERNAME_LEN - 1] = '\0';
    hash_password("ChangeMe_At_First_Login!", users[0].password_hash);
    users[0].admin_flag = 1;
    users[0].balance = 10000;
    users[0].token = malloc(TOKEN_LEN);
    if (users[0].token == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire critique\n");
        return EXIT_FAILURE;
    }
    snprintf(users[0].token, TOKEN_LEN, "ADMIN_TOKEN");
    user_count = 1;

    while (1) {
        display_menu();
        if (!read_int(&choice)) {
            if (feof(stdin)) {
                printf("\nFin de l'entree, fermeture.\n");
                break;
            }
            printf("Entree invalide, veuillez saisir un nombre.\n");
            continue;
        }

        switch (choice) {
            case 1:
                register_user();
                break;
            case 2:
                printf("Username: ");
                if (!read_line(username, sizeof(username))) break;
                printf("Password: ");
                if (!read_line(password, sizeof(password))) break;
                logged_user = login_user(username, password);
                memset(password, 0, sizeof(password));
                if (logged_user >= 0) {
                    printf("\xE2\x9C\x93 Connecte en tant que %s\n", users[logged_user].username);
                } else {
                    printf("\xE2\x9C\x97 Echec de connexion\n");
                }
                break;
            case 3:
                if (logged_user >= 0) show_profile(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 4:
                if (logged_user >= 0) transfer_money(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 5:
                if (logged_user >= 0) backup_user_data(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 6:
                /* [Correction #9] Authentification desormais requise. */
                if (logged_user >= 0) restore_user_data();
                else printf("Veuillez vous connecter\n");
                break;
            case 7:
                if (logged_user >= 0 && users[logged_user].admin_flag) system_command();
                else printf("Acces refuse\n");
                break;
            case 8:
                if (logged_user >= 0) clone_user(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 9:
                /* [Correction #9] Authentification desormais requise. */
                if (logged_user >= 0) list_users();
                else printf("Veuillez vous connecter\n");
                break;
            case 10:
                if (logged_user >= 0) change_password(logged_user);
                else printf("Veuillez vous connecter\n");
                break;
            case 11:
                compute_stats();
                break;
            case 12:
                search_user();
                break;
            case 0:
                printf("Au revoir!\n");
                return 0;
            default:
                printf("Choix invalide\n");
        }
    }

    return 0;
}
